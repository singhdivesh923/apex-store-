-- ==========================================================
-- E-Commerce Seed Data
-- ==========================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------
-- Settings
-- ----------------------------------------------------------
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_group`, `description`) VALUES
('store_name', 'ApexStore', 'general', 'Public storefront branding name'),
('store_tagline', 'Curated Premium Electronics & Lifestyle Essentials', 'general', 'Store slogan'),
('store_email', 'support@apexstore.com', 'contact', 'Customer support email'),
('store_phone', '+1 (800) 555-0199', 'contact', 'Support telephone number'),
('store_address', '100 Innovation Boulevard, Suite 400, San Francisco, CA 94105, USA', 'contact', 'Physical headquarters address'),
('currency_code', 'USD', 'localization', 'Primary ISO currency code'),
('currency_symbol', '$', 'localization', 'Currency display symbol'),
('tax_rate_percent', '8.50', 'tax', 'Standard sales tax percentage rate'),
('flat_shipping_rate', '15.00', 'shipping', 'Standard flat rate shipping fee'),
('free_shipping_threshold', '150.00', 'shipping', 'Minimum cart subtotal to qualify for free shipping'),
('enable_reviews', '1', 'storefront', 'Allow verified customers to submit product reviews'),
('enable_cod', '1', 'payment', 'Enable Cash on Delivery payment option'),
('enable_razorpay', '0', 'payment', 'Enable Razorpay payment gateway'),
('razorpay_key_id', 'rzp_test_YourKeyHere', 'payment', 'Razorpay public Key ID'),
('razorpay_key_secret', 'YourKeySecretHere', 'payment', 'Razorpay secret key')
ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`);

-- ----------------------------------------------------------
-- Initial Users (Passwords: Admin@12345 & Customer@12345)
-- Admin:    admin@apexstore.com    / Admin@12345
-- Customer: customer@apexstore.com / Customer@12345
-- ----------------------------------------------------------
INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `phone`, `role`, `status`, `email_verified_at`, `created_at`) VALUES
(1, 'System Administrator', 'admin@apexstore.com', '$2y$10$T7I7RasTmO9up5N7aMbtOOzBmEMIyYdHLaPd9JsmuB5YSldh9mjL6', '+1 (800) 555-0100', 'admin', 'active', NOW(), NOW()),
(2, 'Sarah Jenkins', 'customer@apexstore.com', '$2y$10$.h7uduhncOaMfSvJa10s1ebov3tyJrJOhKTKyylDdgGNj1xCQRhvy', '+1 (415) 555-0182', 'customer', 'active', NOW(), NOW())
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- ----------------------------------------------------------
-- Categories
-- ----------------------------------------------------------
INSERT INTO `categories` (`id`, `parent_id`, `name`, `slug`, `description`, `image_url`, `is_active`, `display_order`) VALUES
(1, NULL, 'Electronics & Gadgets', 'electronics-gadgets', 'High-performance audio, premium computing, and smart accessories', 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80', 1, 1),
(2, NULL, 'Fashion & Apparel', 'fashion-apparel', 'Minimalist, sustainable, and tailored everyday garments', 'https://images.unsplash.com/photo-1445205170230-053b83016050?auto=format&fit=crop&w=600&q=80', 1, 2),
(3, NULL, 'Home & Living', 'home-living', 'Modern home accents, ergonomic furniture, and artisanal goods', 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80', 1, 3),
(4, NULL, 'Beauty & Wellness', 'beauty-wellness', 'Clean skincare, restorative fragrances, and organic rituals', 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=600&q=80', 1, 4),
(5, 1, 'Audio & Acoustics', 'audio-acoustics', 'Audiophile wireless headphones, studio monitors, and portable speakers', 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=600&q=80', 1, 1),
(6, 1, 'Wearable Tech', 'wearable-tech', 'Smart biometric health monitors and titanium smartwatches', 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80', 1, 2),
(7, 2, 'Luxury Timepieces', 'luxury-timepieces', 'Automatic mechanical watches and Italian leather bands', 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=600&q=80', 1, 1)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- ----------------------------------------------------------
-- Products
-- ----------------------------------------------------------
INSERT INTO `products` (`id`, `category_id`, `name`, `slug`, `sku`, `short_description`, `description`, `price`, `discount_price`, `stock_quantity`, `low_stock_threshold`, `is_featured`, `is_bestseller`, `is_new_arrival`, `status`, `rating_avg`, `rating_count`) VALUES
(1, 5, 'Apex Pro ANC Wireless Headphones', 'apex-pro-anc-wireless-headphones', 'APX-AUD-001', 'Active noise cancelling wireless headphones with 40-hour playback and lossless beryllium drivers.', '<p>Immerse yourself in pristine acoustic clarity with the <strong>Apex Pro Wireless Headphones</strong>. Engineered with 40mm custom beryllium dynamic drivers, adaptive hybrid active noise cancellation, and ultra-plush memory foam lambskin earcups, these headphones deliver studio-grade acoustics wherever you journey.</p><ul><li>Up to 40 hours continuous battery runtime</li><li>Bluetooth 5.3 with LDAC, aptX Adaptive, and AAC codecs</li><li>Dual beamforming ENC microphones for crystal-clear calls</li><li>USB-C rapid charging (10 mins = 5 hours play)</li></ul>', 349.00, 299.00, 45, 5, 1, 1, 0, 'active', 4.90, 24),

(2, 6, 'Vanguard Chrono Smartwatch Titanium', 'vanguard-chrono-smartwatch-titanium', 'APX-WRB-002', 'Aerospace grade titanium chassis, sapphire crystal display, ECG biometric sensors, and 14-day battery.', '<p>The <strong>Vanguard Chrono Smartwatch</strong> effortlessly fuses heritage horology with cutting-edge health tracking. Encased in sculpted Grade 5 aerospace titanium with an ultra-bright AMOLED display protected by synthetic sapphire crystal.</p><ul><li>Continuous optical heart rate, ECG, and SpO2 sensors</li><li>Dual-band multi-constellation GPS</li><li>50-meter water resistance (5 ATM)</li><li>Sapphire glass touch panel with anti-fingerprint coating</li></ul>', 499.00, 449.00, 28, 4, 1, 0, 1, 'active', 4.85, 18),

(3, 5, 'SonicBloom Hi-Fi Desktop Speaker', 'sonicbloom-hi-fi-desktop-speaker', 'APX-AUD-003', 'Handcrafted walnut enclosure with dedicated silk dome tweeters and dual passive radiators.', '<p>Elevate your workspace acoustics with the <strong>SonicBloom Hi-Fi Desktop Speaker</strong>. Featuring acoustic-grade solid American walnut, high-resolution DAC integration, and custom DSP tuning that delivers deep, authoritative bass and crystalline highs.</p>', 220.00, NULL, 60, 8, 1, 1, 0, 'active', 4.70, 12),

(4, 7, 'Minimalist Automatic Leather Watch', 'minimalist-automatic-leather-watch', 'APX-WAT-004', '24-jewel automatic Japanese movement with full-grain Horween calfskin leather strap.', '<p>Designed for understated refinement. The watch features an exhibition case back showcasing the intricate self-winding mechanical movement, Bauhaus-inspired dial markers, and vegetable-tanned leather that patinas gracefully over time.</p>', 280.00, 235.00, 15, 3, 0, 1, 0, 'active', 4.92, 31),

(5, 3, 'ErgoLuxe Sculpted Task Chair', 'ergoluxe-sculpted-task-chair', 'APX-FUR-005', 'Synchronous tilt mechanism, dynamic lumbar support, and breathable Italian mesh fabric.', '<p>Engineered for ergonomic excellence. The ErgoLuxe provides seamless posture realignment throughout intensive focus sessions, featuring 4D armrests, pneumatic height adjustment, and certified Class-4 gas lift.</p>', 620.00, 579.00, 12, 2, 1, 0, 1, 'active', 4.65, 9),

(6, 1, 'MagPulse Wireless MagSafe Power Bank', 'magpulse-wireless-magsafe-power-bank', 'APX-ACC-006', '10,000mAh portable charger with 15W Qi2 wireless snap-on charging and anodized aluminum body.', '<p>Ultra-slim, pocket-sized magnetic power. MagPulse snaps onto Qi2/MagSafe devices effortlessly, maintaining safe thermal thresholds while charging your smartphone from 0 to 60% in 35 minutes.</p>', 79.00, 65.00, 120, 15, 0, 1, 1, 'active', 4.80, 42),

(7, 4, 'Botanical Restore Eau De Parfum 50ml', 'botanical-restore-eau-de-parfum', 'APX-FRG-007', 'Notes of Haitian vetiver, bergamot rind, cracked black pepper, and smokey cedarwood.', '<p>An evocative artisanal fragrance distilled in small batches in Grasse, France. Featuring 100% sustainably harvested botanicals with a warm, magnetic sillage that lingers delicately for over 12 hours.</p>', 145.00, NULL, 50, 10, 0, 0, 1, 'active', 5.00, 8),

(8, 2, 'Merino Wool Structured Overshirt', 'merino-wool-structured-overshirt', 'APX-CLO-008', '100% fine Australian merino wool with horn buttons and tailored chest pockets.', '<p>Naturally temperature regulating and odor resistant. The Structured Overshirt transitions smoothly from brisk outdoor commutes to polished executive presentations.</p>', 195.00, 165.00, 35, 5, 0, 0, 1, 'active', 4.75, 14)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- ----------------------------------------------------------
-- Product Images
-- ----------------------------------------------------------
INSERT INTO `product_images` (`product_id`, `image_path`, `alt_text`, `is_primary`, `display_order`) VALUES
(1, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1000&q=80', 'Apex Pro ANC Wireless Headphones Angle View', 1, 1),
(1, 'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=1000&q=80', 'Apex Pro ANC Studio Lifestyle', 0, 2),
(2, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1000&q=80', 'Vanguard Chrono Smartwatch Titanium Front', 1, 1),
(2, 'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=1000&q=80', 'Vanguard Chrono on Wrist Lifestyle', 0, 2),
(3, 'https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=1000&q=80', 'SonicBloom Hi-Fi Desktop Speaker Walnut', 1, 1),
(4, 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=1000&q=80', 'Minimalist Automatic Leather Watch', 1, 1),
(5, 'https://images.unsplash.com/photo-1580481077195-731da01f3799?auto=format&fit=crop&w=1000&q=80', 'ErgoLuxe Sculpted Task Chair Workspace', 1, 1),
(6, 'https://images.unsplash.com/photo-1609081219090-a6d81d3085bf?auto=format&fit=crop&w=1000&q=80', 'MagPulse Wireless MagSafe Power Bank', 1, 1),
(7, 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1000&q=80', 'Botanical Restore Eau De Parfum Bottle', 1, 1),
(8, 'https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?auto=format&fit=crop&w=1000&q=80', 'Merino Wool Structured Overshirt Front', 1, 1)
ON DUPLICATE KEY UPDATE `image_path` = VALUES(`image_path`);

-- ----------------------------------------------------------
-- Coupons
-- ----------------------------------------------------------
INSERT INTO `coupons` (`id`, `code`, `type`, `discount_value`, `min_order_amount`, `max_discount_amount`, `usage_limit`, `usage_count`, `is_active`, `start_date`, `end_date`) VALUES
(1, 'WELCOME10', 'percentage', 10.00, 50.00, 50.00, 500, 5, 1, '2025-01-01 00:00:00', '2030-12-31 23:59:59'),
(2, 'SAVE25', 'fixed', 25.00, 150.00, NULL, 200, 12, 1, '2025-01-01 00:00:00', '2030-12-31 23:59:59'),
(3, 'VIP20', 'percentage', 20.00, 200.00, 100.00, 100, 2, 1, '2025-01-01 00:00:00', '2030-12-31 23:59:59')
ON DUPLICATE KEY UPDATE `code` = VALUES(`code`);

-- ----------------------------------------------------------
-- Customer Addresses
-- ----------------------------------------------------------
INSERT INTO `addresses` (`id`, `user_id`, `type`, `recipient_name`, `phone`, `address_line1`, `address_line2`, `city`, `state`, `postal_code`, `country`, `is_default`) VALUES
(1, 2, 'both', 'Sarah Jenkins', '+1 (415) 555-0182', '742 Evergreen Terrace', 'Apt 4B', 'San Francisco', 'CA', '94110', 'US', 1)
ON DUPLICATE KEY UPDATE `recipient_name` = VALUES(`recipient_name`);

-- ----------------------------------------------------------
-- Product Reviews
-- ----------------------------------------------------------
INSERT INTO `reviews` (`product_id`, `user_id`, `rating`, `title`, `comment`, `status`) VALUES
(1, 2, 5, 'Unrivaled noise cancellation and comfort', 'I wear these for 8 hours daily during remote engineering shifts. Battery life is extraordinary and ANC easily cancels metro transit noise.', 'approved'),
(2, 2, 5, 'Stunning titanium finish', 'The sapphire glass has resisted every scratch. Beautiful watch face options and heart rate tracking matches my chest strap monitor perfectly.', 'approved')
ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);

SET FOREIGN_KEY_CHECKS = 1;
