<?php
declare(strict_types=1);

/**
 * ApexStore Database Setup & Migration Script
 * Usage: php database/setup.php [--seed]
 */

define('ROOT_DIR', dirname(__DIR__));

require_once ROOT_DIR . '/app/helpers.php';
load_env(ROOT_DIR . '/.env');

echo "\n=======================================================\n";
echo "  ApexStore Database Setup & Migration Tool\n";
echo "=======================================================\n\n";

$dbHost = env('DB_HOST', '127.0.0.1');
$dbPort = (int) env('DB_PORT', 3306);
$dbName = env('DB_DATABASE', 'apexstore_db');
$dbUser = env('DB_USERNAME', 'root');
$dbPass = env('DB_PASSWORD', '');

echo "Connecting to MySQL server at {$dbHost}:{$dbPort}...\n";

try {
    // 1. Connect to MySQL server without db selected
    $pdo = new PDO("mysql:host={$dbHost};port={$dbPort};charset=utf8mb4", $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::MYSQL_ATTR_MULTI_STATEMENTS => true,
    ]);

    // 2. Create database if it doesn't exist
    echo "Ensuring database '{$dbName}' exists...\n";
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
    $pdo->exec("USE `{$dbName}`;");

    // 3. Execute schema.sql
    $schemaFile = ROOT_DIR . '/database/schema.sql';
    if (!file_exists($schemaFile)) {
        throw new RuntimeException("schema.sql not found at {$schemaFile}");
    }

    echo "Importing schema tables from schema.sql...\n";
    $schemaSql = file_get_contents($schemaFile);
    $pdo->exec($schemaSql);
    echo "  ✔ Schema imported successfully (20 InnoDB tables created).\n";

    // 4. Execute seed.sql if requested or default
    $seedFile = ROOT_DIR . '/database/seed.sql';
    if (file_exists($seedFile)) {
        echo "Importing seed data from seed.sql...\n";
        $seedSql = file_get_contents($seedFile);
        $pdo->exec($seedSql);
        echo "  ✔ Seed data imported successfully (products, categories, users, settings).\n";
    }

    echo "\n\033[32mDatabase setup completed successfully!\033[0m\n\n";
    echo "Default Credentials:\n";
    echo "  - Administrator: admin@apexstore.com / Admin@12345\n";
    echo "  - Customer:      customer@apexstore.com / Customer@12345\n\n";

} catch (PDOException $e) {
    echo "\n\033[31mDatabase Connection / Migration Failed:\033[0m\n";
    echo "  " . $e->getMessage() . "\n\n";
    echo "Tips:\n";
    echo "  1. Ensure your local MySQL/MariaDB service is running (e.g. XAMPP, Laragon, MySQL Server).\n";
    echo "  2. Verify DB_USERNAME and DB_PASSWORD in .env match your local MySQL configuration.\n\n";
    exit(1);
}
