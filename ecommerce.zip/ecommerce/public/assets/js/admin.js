/**
 * ApexStore Admin JavaScript Interactions
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Confirmation modal for state transitions & deletions
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', (e) => {
            const message = el.getAttribute('data-confirm') || 'Are you sure you want to proceed with this action?';
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });

    // 2. Sidebar mobile toggle
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.querySelector('.admin-sidebar');
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('show');
        });
    }

    // 3. Auto-calculate discount preview on coupon forms
    const couponTypeSelect = document.getElementById('couponType');
    const discountInput = document.getElementById('discountValue');
    if (couponTypeSelect && discountInput) {
        const updateSymbol = () => {
            const label = document.getElementById('discountUnitLabel');
            if (label) {
                label.textContent = couponTypeSelect.value === 'percentage' ? '%' : '$';
            }
        };
        couponTypeSelect.addEventListener('change', updateSymbol);
        updateSymbol();
    }
});
