/**
 * ApexStore Storefront Vanilla JavaScript Interactions
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. AJAX Add To Cart Forms
    document.querySelectorAll('.form-add-to-cart').forEach(form => {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            const btn = form.querySelector('button[type="submit"]');
            const originalText = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Adding...';

            const formData = new FormData(form);

            try {
                const response = await fetch(form.action, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });

                const data = await response.json();

                if (response.ok && data.success) {
                    showToast(data.message || 'Product added to cart!', 'success');
                    if (data.cart_count !== undefined) {
                        updateCartBadges(data.cart_count);
                    }
                } else {
                    showToast(data.error || 'Failed to add item to cart.', 'error');
                }
            } catch (err) {
                // Fallback to regular form submission if network or json issue
                form.submit();
                return;
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalText;
            }
        });
    });

    // 2. Wishlist Toggle Buttons
    document.querySelectorAll('.btn-wishlist-toggle').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.preventDefault();
            const productId = btn.getAttribute('data-product-id');
            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');

            if (!productId) return;

            const formData = new FormData();
            formData.append('product_id', productId);
            if (csrfToken) formData.append('csrf_token', csrfToken);

            try {
                const response = await fetch('/wishlist/toggle', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });

                if (response.status === 401) {
                    window.location.href = '/login';
                    return;
                }

                const data = await response.json();
                if (data.success) {
                    btn.classList.toggle('active', data.saved);
                    showToast(data.message, 'info');
                }
            } catch (err) {
                console.error('Wishlist toggle error:', err);
            }
        });
    });

    // 3. Cart Quantity Live Adjustments
    document.querySelectorAll('.cart-qty-input').forEach(input => {
        input.addEventListener('change', async () => {
            const form = input.closest('form');
            if (form) form.submit();
        });
    });

    // 4. Toast Notification Helper
    window.showToast = function(message, type = 'info') {
        const existingToast = document.querySelector('.apex-toast');
        if (existingToast) existingToast.remove();

        const toast = document.createElement('div');
        toast.className = 'apex-toast';
        
        let icon = 'bi-info-circle-fill text-primary';
        if (type === 'success') icon = 'bi-check-circle-fill text-success';
        if (type === 'error') icon = 'bi-exclamation-triangle-fill text-danger';

        toast.innerHTML = `
            <i class="bi ${icon} fs-5"></i>
            <div>${escapeHtml(message)}</div>
            <button type="button" class="btn-close btn-close-white ms-3" aria-label="Close" onclick="this.parentElement.remove()"></button>
        `;

        document.body.appendChild(toast);

        setTimeout(() => {
            if (toast.parentElement) toast.remove();
        }, 4000);
    };

    function updateCartBadges(count) {
        document.querySelectorAll('.cart-count-badge').forEach(badge => {
            badge.textContent = count;
            badge.style.display = count > 0 ? 'flex' : 'none';
        });
    }

    function escapeHtml(string) {
        const div = document.createElement('div');
        div.innerText = string;
        return div.innerHTML;
    }
});
