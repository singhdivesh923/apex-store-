<?php
declare(strict_types=1);

/**
 * ApexStore Front Controller
 */

// Define execution start time
define('APP_START', microtime(true));
define('ROOT_DIR', dirname(__DIR__));

// When using PHP built-in web server, let it serve static files directly, but block scripts in uploads or dotfiles
if (php_sapi_name() === 'cli-server') {
    $requestedPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
    if ($requestedPath && $requestedPath !== '/' && is_file(__DIR__ . $requestedPath)) {
        // Block dotfiles
        if (preg_match('/(^|\/)\./', $requestedPath)) {
            http_response_code(403);
            echo "403 Forbidden";
            exit;
        }
        // Block script execution inside uploads
        if (str_starts_with($requestedPath, '/uploads/') && preg_match('/\.(php|phtml|phar|inc|cgi|pl|py|sh|bash|exe|bat)$/i', $requestedPath)) {
            http_response_code(403);
            echo "403 Forbidden";
            exit;
        }
        return false;
    }
}

// Load Composer Autoloader if available, otherwise use custom PSR-4 autoloader
if (file_exists(ROOT_DIR . '/vendor/autoload.php')) {
    require_once ROOT_DIR . '/vendor/autoload.php';
} else {
    spl_autoload_register(function (string $class) {
        $prefix = 'App\\';
        $baseDir = ROOT_DIR . '/app/';

        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            return;
        }

        $relativeClass = substr($class, $len);
        $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

        if (file_exists($file)) {
            require_once $file;
        }
    });
}

// Load helper functions
require_once ROOT_DIR . '/app/helpers.php';

// Load environment variables from .env
load_env(ROOT_DIR . '/.env');

// Set error reporting based on APP_DEBUG
$debug = (bool) env('APP_DEBUG', false);
if ($debug) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    ini_set('error_log', ROOT_DIR . '/storage/logs/error.log');
}

// Global Security Headers for all responses
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-XSS-Protection: 1; mode=block');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');

    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https')
        || (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);

    if ($isHttps) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

// Initialize session and security middleware
\App\Services\Session::start();
\App\Middleware\CsrfMiddleware::handle();

// Initialize router and load routes
$router = new \App\Router();
require_once ROOT_DIR . '/routes/web.php';

// Dispatch request
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$uri = $_SERVER['REQUEST_URI'] ?? '/';

try {
    $router->dispatch($method, $uri);
} catch (\Throwable $e) {
    error_log("Unhandled Application Exception: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
    http_response_code(500);

    if ($debug) {
        echo "<!DOCTYPE html><html><head><title>500 Internal Error</title>";
        echo "<style>body{font-family:sans-serif;background:#0f172a;color:#f8fafc;padding:2rem;}pre{background:#1e293b;padding:1rem;border-radius:8px;overflow:auto;}</style></head><body>";
        echo "<h1>Application Error (Debug Mode Active)</h1>";
        echo "<p><strong>Message:</strong> " . e($e->getMessage()) . "</p>";
        echo "<p><strong>File:</strong> " . e($e->getFile()) . " on line " . $e->getLine() . "</p>";
        echo "<pre>" . e($e->getTraceAsString()) . "</pre>";
        echo "</body></html>";
    } else {
        $errorView = ROOT_DIR . '/app/Views/pages/500.php';
        if (file_exists($errorView)) {
            require $errorView;
        } else {
            echo "<h1>500 Internal Server Error</h1><p>An unexpected error occurred. Our team has been notified.</p>";
        }
    }
}
