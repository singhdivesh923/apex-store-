<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Services\CSRF;
use App\Services\Session;

class CsrfMiddleware
{
    public static function handle(): void
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        if (in_array(strtoupper($method), ['POST', 'PUT', 'DELETE', 'PATCH'], true)) {
            // Exclude webhook routes if any
            $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
            if (str_starts_with($uri, '/api/webhook') || str_starts_with($uri, '/webhook')) {
                return;
            }

            $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;
            if (!$token || !CSRF::validate($token)) {
                $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
                error_log("CSRF verification failed for {$method} {$uri} from " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));

                if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
                    json_response(['success' => false, 'error' => 'CSRF verification failed. Please refresh the page.'], 403);
                }

                Session::flash('error', 'Your session has expired or the form security token was invalid. Please try again.');
                $referrer = $_SERVER['HTTP_REFERER'] ?? $uri ?? '/';
                redirect($referrer);
            }
        }
    }
}
