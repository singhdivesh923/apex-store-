<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Services\Auth;
use App\Services\Session;

class AdminMiddleware
{
    public static function handle(): void
    {
        if (!Auth::isAdmin()) {
            Session::flash('error', 'Administrator privileges required to access the dashboard.');
            redirect('/admin/login');
        }
    }
}
