<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Services\Auth;
use App\Services\Session;

class AuthMiddleware
{
    public static function handle(): void
    {
        if (!Auth::check() || !Auth::user()) {
            Session::flash('warning', 'Please sign in to access this page.');
            $redirectUrl = $_SERVER['REQUEST_URI'] ?? '/account/orders';
            Session::set('intended_url', $redirectUrl);
            redirect('/login');
        }
    }
}
