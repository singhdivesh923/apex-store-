<?php
declare(strict_types=1);

namespace App\Services;

use RuntimeException;

class FileUploader
{
    private const ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp'];
    private const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
    private const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB

    /**
     * Upload an image file securely
     */
    public static function uploadImage(array $file, string $subDirectory = 'products'): string
    {
        if (!isset($file['error']) || is_array($file['error'])) {
            throw new RuntimeException('Invalid file upload parameters.');
        }

        switch ($file['error']) {
            case UPLOAD_ERR_OK:
                break;
            case UPLOAD_ERR_NO_FILE:
                throw new RuntimeException('No file was uploaded.');
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                throw new RuntimeException('Uploaded file exceeded allowed size limit.');
            default:
                throw new RuntimeException('An error occurred during file upload.');
        }

        if ($file['size'] > self::MAX_FILE_SIZE) {
            throw new RuntimeException('File size must not exceed 5MB.');
        }

        // Validate MIME type strictly using finfo
        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($file['tmp_name']);

        if (!in_array($mime, self::ALLOWED_MIME_TYPES, true)) {
            throw new RuntimeException('Invalid image type. Only JPG, PNG, and WebP images are permitted.');
        }

        // Validate image dimensions
        $imageInfo = @getimagesize($file['tmp_name']);
        if ($imageInfo === false) {
            throw new RuntimeException('The uploaded file is not a valid image.');
        }

        // Extension allowlist check
        $originalExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($originalExt, self::ALLOWED_EXTENSIONS, true)) {
            throw new RuntimeException('Invalid file extension.');
        }

        // Map extension from MIME to prevent spoofing
        $extensionMap = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
        ];
        $safeExtension = $extensionMap[$mime] ?? 'jpg';

        // Generate high-entropy randomized filename
        $safeFilename = bin2hex(random_bytes(16)) . '.' . $safeExtension;

        // Enforce safe subdirectory allowlist against path traversal
        $safeSubDir = basename(trim($subDirectory, '/\\'));
        $allowedSubDirs = ['products', 'categories', 'avatars', 'general'];
        if (!in_array($safeSubDir, $allowedSubDirs, true)) {
            $safeSubDir = 'products';
        }

        $targetDir = ROOT_DIR . '/public/uploads/' . $safeSubDir;
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }

        $destination = $targetDir . '/' . $safeFilename;
        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            throw new RuntimeException('Failed to move uploaded file to target storage directory.');
        }

        return '/uploads/' . $safeSubDir . '/' . $safeFilename;
    }
}
