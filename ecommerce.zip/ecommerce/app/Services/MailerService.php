<?php
declare(strict_types=1);

namespace App\Services;

class MailerService
{
    public static function send(string $to, string $subject, string $htmlBody): bool
    {
        $configPath = ROOT_DIR . '/config/mail.php';
        $config = file_exists($configPath) ? require $configPath : [];

        $mailer = $config['default'] ?? 'log';
        $fromAddress = $config['from']['address'] ?? 'support@apexstore.com';
        $fromName = $config['from']['name'] ?? 'ApexStore';

        // Neutralize Email Header Injection by stripping CR/LF characters
        $to = str_replace(["\r", "\n"], '', trim($to));
        $subject = str_replace(["\r", "\n"], '', trim($subject));
        $fromAddress = str_replace(["\r", "\n"], '', trim($fromAddress));
        $fromName = str_replace(["\r", "\n"], '', trim($fromName));

        if ($mailer === 'smtp') {
            $smtp = $config['mailers']['smtp'] ?? [];
            if (!empty($smtp['host']) && !empty($smtp['username'])) {
                // If standard mail() or socket is available
                $headers = [
                    'MIME-Version: 1.0',
                    'Content-type: text/html; charset=utf-8',
                    "From: {$fromName} <{$fromAddress}>",
                    "Reply-To: {$fromAddress}",
                    'X-Mailer: PHP/' . phpversion(),
                ];

                return @mail($to, $subject, $htmlBody, implode("\r\n", $headers));
            }
        }

        // Fallback or dev mode: log to storage/logs/mail.log
        $logDir = ROOT_DIR . '/storage/logs';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }

        $logEntry = sprintf(
            "[%s] TO: %s | SUBJECT: %s\nBODY:\n%s\n%s\n",
            date('Y-m-d H:i:s'),
            $to,
            $subject,
            $htmlBody,
            str_repeat('-', 60)
        );

        file_put_contents($logDir . '/mail.log', $logEntry, FILE_APPEND);
        return true;
    }

    public static function sendOrderConfirmation(array $order): bool
    {
        $email = $order['guest_email'] ?? $order['shipping_address']['email'] ?? null;
        if (!$email && !empty($order['user_id'])) {
            $user = Database::fetchOne("SELECT `email` FROM `users` WHERE `id` = :id", [':id' => $order['user_id']]);
            $email = $user['email'] ?? null;
        }

        if (!$email) {
            return false;
        }

        $subject = "Order Confirmation - #{$order['order_number']}";
        $body = "<h2>Thank you for your order!</h2>";
        $body .= "<p>Your order <strong>#{$order['order_number']}</strong> has been received and is being processed.</p>";
        $body .= "<p>Total Amount: <strong>" . format_currency($order['total_amount']) . "</strong></p>";
        $body .= "<p>You can track the progress of your order anytime in your account dashboard.</p>";

        return self::send($email, $subject, $body);
    }
}
