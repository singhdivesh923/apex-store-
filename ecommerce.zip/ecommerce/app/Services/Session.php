<?php
declare(strict_types=1);

namespace App\Services;

class Session
{
    private static bool $started = false;

    /**
     * Start session with strict security settings
     */
    public static function start(): void
    {
        if (self::$started || session_status() === PHP_SESSION_ACTIVE) {
            self::$started = true;
            return;
        }

        $configPath = dirname(__DIR__, 2) . '/config/app.php';
        $config = file_exists($configPath) ? require $configPath : [];
        $sessionCfg = $config['session'] ?? [];

        $lifetime = $sessionCfg['lifetime'] ?? 7200;
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https')
            || (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);
        $secure = !empty($sessionCfg['secure']) || $isHttps;
        $httponly = $sessionCfg['httponly'] ?? true;
        $samesite = $sessionCfg['samesite'] ?? 'Lax';

        $cookieDomain = $sessionCfg['domain'] ?? '';
        if ($cookieDomain !== '') {
            $cookieDomain = preg_replace('/:\d+$/', '', (string)$cookieDomain);
            if (in_array(strtolower($cookieDomain), ['localhost', '127.0.0.1'], true)) {
                $cookieDomain = '';
            }
        }

        if (!headers_sent()) {
            ini_set('session.use_strict_mode', '1');
            ini_set('session.use_only_cookies', '1');
            ini_set('session.gc_maxlifetime', (string)$lifetime);

            session_set_cookie_params([
                'lifetime' => $lifetime,
                'path' => '/',
                'domain' => $cookieDomain,
                'secure' => $secure,
                'httponly' => $httponly,
                'samesite' => $samesite,
            ]);
        }

        if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
            session_start();
        }

        self::$started = true;
    }

    /**
     * Regenerate session ID to prevent session fixation
     */
    public static function regenerate(): void
    {
        self::start();
        session_regenerate_id(true);
    }

    /**
     * Set session variable
     */
    public static function set(string $key, mixed $value): void
    {
        self::start();
        $_SESSION[$key] = $value;
    }

    /**
     * Get session variable
     */
    public static function get(string $key, mixed $default = null): mixed
    {
        self::start();
        return $_SESSION[$key] ?? $default;
    }

    /**
     * Check if session variable exists
     */
    public static function has(string $key): bool
    {
        self::start();
        return isset($_SESSION[$key]);
    }

    /**
     * Remove session variable
     */
    public static function remove(string $key): void
    {
        self::start();
        unset($_SESSION[$key]);
    }

    /**
     * Destroy session
     */
    public static function destroy(): void
    {
        self::start();
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params["path"],
                $params["domain"],
                $params["secure"],
                $params["httponly"]
            );
        }
        session_destroy();
        self::$started = false;
    }

    /**
     * Flash a message for the next request
     */
    public static function flash(string $type, string $message): void
    {
        self::start();
        $_SESSION['_flashes'][$type][] = $message;
    }

    /**
     * Retrieve all flash messages and clear them
     */
    public static function getFlashes(): array
    {
        self::start();
        $flashes = $_SESSION['_flashes'] ?? [];
        unset($_SESSION['_flashes']);
        return $flashes;
    }
}
