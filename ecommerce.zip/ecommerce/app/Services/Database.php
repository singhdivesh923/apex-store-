<?php
declare(strict_types=1);

namespace App\Services;

use PDO;
use PDOException;
use RuntimeException;

class Database
{
    private static ?PDO $instance = null;
    private static ?string $connectionName = null;

    /**
     * Private constructor to prevent direct instantiation
     */
    private function __construct() {}

    /**
     * Get singleton PDO connection instance
     */
    public static function getConnection(?string $connection = null): PDO
    {
        if (self::$instance !== null && ($connection === null || $connection === self::$connectionName)) {
            return self::$instance;
        }

        $configPath = dirname(__DIR__, 2) . '/config/database.php';
        if (!file_exists($configPath)) {
            throw new RuntimeException("Database configuration file not found at {$configPath}");
        }

        $config = require $configPath;
        $connection = $connection ?? $config['default'] ?? 'mysql';
        self::$connectionName = $connection;

        if (!isset($config['connections'][$connection])) {
            throw new RuntimeException("Database connection '{$connection}' not defined in config.");
        }

        $connConfig = $config['connections'][$connection];

        try {
            if ($connConfig['driver'] === 'sqlite') {
                $dsn = "sqlite:{$connConfig['database']}";
                $dbDir = dirname($connConfig['database']);
                if (!is_dir($dbDir)) {
                    mkdir($dbDir, 0775, true);
                }
                $pdo = new PDO($dsn, null, null, $connConfig['options'] ?? []);
                // Enable foreign keys in SQLite
                $pdo->exec('PRAGMA foreign_keys = ON;');
            } else {
                $dsn = sprintf(
                    'mysql:host=%s;port=%d;dbname=%s;charset=%s',
                    $connConfig['host'],
                    $connConfig['port'],
                    $connConfig['database'],
                    $connConfig['charset']
                );
                $pdo = new PDO(
                    $dsn,
                    $connConfig['username'],
                    $connConfig['password'],
                    $connConfig['options'] ?? []
                );
            }

            self::$instance = $pdo;
            return self::$instance;
        } catch (PDOException $e) {
            error_log("Database Connection Error: " . $e->getMessage());
            $debug = env('APP_DEBUG', false);
            if ($debug) {
                throw new RuntimeException("Database Connection Error: " . $e->getMessage(), (int)$e->getCode(), $e);
            }
            throw new RuntimeException("Unable to connect to the database. Please check configuration.");
        }
    }

    /**
     * Manually set PDO instance (useful for testing or mocks)
     */
    public static function setConnection(PDO $pdo): void
    {
        self::$instance = $pdo;
    }

    /**
     * Execute a callback inside a database transaction
     */
    public static function transaction(callable $callback): mixed
    {
        $pdo = self::getConnection();
        $isExistingTransaction = $pdo->inTransaction();

        if (!$isExistingTransaction) {
            $pdo->beginTransaction();
        }

        try {
            $result = $callback($pdo);
            if (!$isExistingTransaction) {
                $pdo->commit();
            }
            return $result;
        } catch (\Throwable $e) {
            if (!$isExistingTransaction && $pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    /**
     * Execute prepared query and fetch single row
     */
    public static function fetchOne(string $sql, array $params = []): ?array
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch();
        return $result !== false ? $result : null;
    }

    /**
     * Execute prepared query and fetch all rows
     */
    public static function fetchAll(string $sql, array $params = []): array
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Execute prepared query and return affected rows
     */
    public static function execute(string $sql, array $params = []): int
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount();
    }

    /**
     * Insert row and return last inserted ID
     */
    public static function insert(string $table, array $data): int
    {
        $columns = array_keys($data);
        $fields = implode(', ', array_map(fn($col) => "`{$col}`", $columns));
        $placeholders = implode(', ', array_map(fn($col) => ":{$col}", $columns));

        $sql = "INSERT INTO `{$table}` ({$fields}) VALUES ({$placeholders})";
        $stmt = self::getConnection()->prepare($sql);

        $params = [];
        foreach ($data as $key => $value) {
            $params[":{$key}"] = $value;
        }

        $stmt->execute($params);
        return (int) self::getConnection()->lastInsertId();
    }
}
