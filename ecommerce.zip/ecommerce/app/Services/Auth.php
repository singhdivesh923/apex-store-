<?php
declare(strict_types=1);

namespace App\Services;

class Auth
{
    private const SESSION_USER_ID = '_auth_user_id';
    private const SESSION_USER_ROLE = '_auth_user_role';
    private static ?array $cachedUser = null;

    /**
     * Attempt login with email, password, and optional role check
     */
    public static function attempt(string $email, string $password, ?string $requiredRole = null): array
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $rateLimitKey = 'login_attempts_' . md5($ip . '_' . strtolower($email));

        if (self::isRateLimited($rateLimitKey)) {
            return [
                'success' => false,
                'error' => 'Too many failed login attempts. Please try again in 15 minutes.'
            ];
        }

        try {
            $user = Database::fetchOne(
                "SELECT * FROM `users` WHERE `email` = :email LIMIT 1",
                [':email' => strtolower(trim($email))]
            );
        } catch (\Throwable $e) {
            error_log("Authentication database query failure: " . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Unable to connect to database service. Please check configuration.'
            ];
        }

        if (!$user || !password_verify($password, $user['password_hash'])) {
            self::incrementRateLimit($rateLimitKey);
            error_log("Failed login attempt for user: {$email} from IP: {$ip}");
            return [
                'success' => false,
                'error' => 'Invalid email address or password.'
            ];
        }

        if ($user['status'] === 'suspended') {
            error_log("Login rejected for suspended account: {$email} from IP: {$ip}");
            return [
                'success' => false,
                'error' => 'Your account has been suspended. Please contact customer support.'
            ];
        }

        if ($requiredRole !== null && $user['role'] !== $requiredRole && $user['role'] !== 'admin') {
            error_log("Unauthorized login attempt: user {$email} (role: {$user['role']}) lacks required role {$requiredRole} from IP: {$ip}");
            return [
                'success' => false,
                'error' => 'Access denied. You do not have permission to access this area.'
            ];
        }

        // Clear rate limit on success
        self::clearRateLimit($rateLimitKey);
        error_log("Successful login for user: {$email} (role: {$user['role']}) from IP: {$ip}");

        // Prevent session fixation
        Session::regenerate();
        Session::set(self::SESSION_USER_ID, (int)$user['id']);
        Session::set(self::SESSION_USER_ROLE, $user['role']);
        self::$cachedUser = $user;

        // If admin, log the login event
        if ($user['role'] === 'admin') {
            try {
                Database::insert('admin_logs', [
                    'admin_id' => $user['id'],
                    'action' => 'admin_login',
                    'entity_type' => 'auth',
                    'entity_id' => $user['id'],
                    'details' => json_encode(['email' => $user['email'], 'time' => date('Y-m-d H:i:s')]),
                    'ip_address' => $ip,
                    'created_at' => date('Y-m-d H:i:s')
                ]);
            } catch (\Throwable $e) {
                error_log("Failed to write admin log: " . $e->getMessage());
            }
        }

        return ['success' => true, 'user' => $user];
    }

    /**
     * Check if current session is authenticated
     */
    public static function check(): bool
    {
        return Session::has(self::SESSION_USER_ID);
    }

    /**
     * Get current authenticated user array
     */
    public static function user(): ?array
    {
        if (!self::check()) {
            return null;
        }

        if (self::$cachedUser !== null) {
            return self::$cachedUser;
        }

        $userId = (int)Session::get(self::SESSION_USER_ID);
        $user = Database::fetchOne(
            "SELECT `id`, `name`, `email`, `phone`, `role`, `status`, `email_verified_at`, `created_at` FROM `users` WHERE `id` = :id LIMIT 1",
            [':id' => $userId]
        );

        if (!$user || $user['status'] === 'suspended') {
            self::logout();
            return null;
        }

        self::$cachedUser = $user;
        return self::$cachedUser;
    }

    /**
     * Get current authenticated user ID
     */
    public static function id(): ?int
    {
        return self::check() ? (int)Session::get(self::SESSION_USER_ID) : null;
    }

    /**
     * Check if user is an administrator
     */
    public static function isAdmin(): bool
    {
        $user = self::user();
        if (!$user || ($user['status'] ?? '') !== 'active') {
            return false;
        }
        return in_array($user['role'] ?? '', ['admin', 'manager'], true);
    }

    /**
     * Log user out and destroy session
     */
    public static function logout(): void
    {
        self::$cachedUser = null;
        Session::destroy();
    }

    /**
     * Storage path for persistent rate limiting
     */
    private static function getRateLimitFilePath(string $key): string
    {
        $dir = ROOT_DIR . '/storage/framework/cache';
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        return $dir . '/rl_' . md5($key) . '.json';
    }

    /**
     * Check rate limiting (both session and persistent disk to prevent cookie-dropping bypass)
     */
    public static function isRateLimited(string $key): bool
    {
        // 1. Session check
        $sessUntil = (int)Session::get($key . '_until', 0);
        if ($sessUntil > time()) {
            return true;
        }

        // 2. Persistent file check
        $filePath = self::getRateLimitFilePath($key);
        if (file_exists($filePath)) {
            $data = json_decode((string)@file_get_contents($filePath), true);
            if (is_array($data)) {
                $until = (int)($data['until'] ?? 0);
                if ($until > time()) {
                    return true;
                }
            }
        }

        return false;
    }

    public static function incrementRateLimit(string $key, int $maxAttempts = 5, int $decaySeconds = 900): void
    {
        $attempts = 0;
        $filePath = self::getRateLimitFilePath($key);

        if (file_exists($filePath)) {
            $data = json_decode((string)@file_get_contents($filePath), true);
            if (is_array($data) && ((int)($data['reset_at'] ?? 0)) > time()) {
                $attempts = (int)($data['attempts'] ?? 0);
            }
        }

        $attempts++;
        $lockoutUntil = 0;
        if ($attempts >= $maxAttempts) {
            $lockoutUntil = time() + $decaySeconds;
        }

        $payload = [
            'attempts' => $attempts,
            'reset_at' => time() + $decaySeconds,
            'until' => $lockoutUntil,
        ];
        @file_put_contents($filePath, json_encode($payload), LOCK_EX);

        Session::set($key . '_count', $attempts);
        if ($lockoutUntil > 0) {
            Session::set($key . '_until', $lockoutUntil);
        }
    }

    public static function clearRateLimit(string $key): void
    {
        Session::remove($key . '_count');
        Session::remove($key . '_until');
        $filePath = self::getRateLimitFilePath($key);
        if (file_exists($filePath)) {
            @unlink($filePath);
        }
    }
}
