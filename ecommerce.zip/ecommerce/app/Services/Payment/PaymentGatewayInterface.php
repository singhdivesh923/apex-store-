<?php
declare(strict_types=1);

namespace App\Services\Payment;

interface PaymentGatewayInterface
{
    /**
     * Prepare or initialize payment for an order
     */
    public function initializePayment(array $orderData): array;

    /**
     * Verify payment return/callback
     */
    public function verifyPayment(array $payload): array;

    /**
     * Process asynchronous payment webhook
     */
    public function processWebhook(string $payload, string $signature): array;
}
