<?php
declare(strict_types=1);

namespace App\Services\Payment;

use InvalidArgumentException;

class PaymentFactory
{
    public static function create(string $method): PaymentGatewayInterface
    {
        return match (strtolower($method)) {
            'cod' => new CodPaymentGateway(),
            'razorpay' => new RazorpayPaymentGateway(),
            default => throw new InvalidArgumentException("Unsupported payment gateway method: {$method}"),
        };
    }
}
