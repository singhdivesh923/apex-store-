<?php
declare(strict_types=1);

namespace App\Services\Payment;

use App\Models\Setting;
use App\Services\Database;
use RuntimeException;

class RazorpayPaymentGateway implements PaymentGatewayInterface
{
    private string $keyId;
    private string $keySecret;
    private string $webhookSecret;

    public function __construct()
    {
        $this->keyId = env('RAZORPAY_KEY_ID', (string)Setting::get('razorpay_key_id', ''));
        $this->keySecret = env('RAZORPAY_KEY_SECRET', (string)Setting::get('razorpay_key_secret', ''));
        $this->webhookSecret = env('RAZORPAY_WEBHOOK_SECRET', (string)Setting::get('razorpay_webhook_secret', ''));

        if (empty($this->keyId) || empty($this->keySecret) || str_contains($this->keyId, 'YourKey')) {
            throw new RuntimeException("Razorpay gateway is not configured with valid API credentials. Please configure RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in .env or the admin settings.");
        }
    }

    public function initializePayment(array $orderData): array
    {
        $amountInSubunits = (int)round(((float)$orderData['total_amount']) * 100);
        $currency = Setting::get('currency_code', 'USD');

        $url = 'https://api.razorpay.com/v1/orders';
        $payload = [
            'amount' => $amountInSubunits,
            'currency' => $currency,
            'receipt' => (string)$orderData['order_number'],
            'notes' => [
                'order_id' => (string)$orderData['order_id'],
                'order_number' => (string)$orderData['order_number'],
            ]
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, "{$this->keyId}:{$this->keySecret}");
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError || $httpCode !== 200) {
            $errData = json_decode((string)$response, true);
            $msg = $errData['error']['description'] ?? $curlError ?? 'Failed to create order on payment gateway.';
            throw new RuntimeException("Razorpay Order Creation Failed: {$msg}");
        }

        $orderRes = json_decode($response, true);
        $razorpayOrderId = $orderRes['id'];

        // Record initial payment record in database
        Database::insert('payments', [
            'order_id' => $orderData['order_id'],
            'payment_gateway' => 'razorpay',
            'gateway_order_id' => $razorpayOrderId,
            'amount' => $orderData['total_amount'],
            'currency' => $currency,
            'status' => 'pending',
            'payload_dump' => json_encode($orderRes),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return [
            'success' => true,
            'type' => 'online',
            'key_id' => $this->keyId,
            'gateway_order_id' => $razorpayOrderId,
            'amount' => $amountInSubunits,
            'currency' => $currency,
            'order_number' => $orderData['order_number'],
            'order_id' => $orderData['order_id'],
        ];
    }

    public function verifyPayment(array $payload): array
    {
        $razorpayPaymentId = $payload['razorpay_payment_id'] ?? '';
        $razorpayOrderId = $payload['razorpay_order_id'] ?? '';
        $razorpaySignature = $payload['razorpay_signature'] ?? '';

        if (empty($razorpayPaymentId) || empty($razorpayOrderId) || empty($razorpaySignature)) {
            return ['success' => false, 'error' => 'Missing payment verification parameters.'];
        }

        // Verify cryptographic signature: HMAC-SHA256(order_id + "|" + payment_id, secret)
        $expectedSignature = hash_hmac('sha256', "{$razorpayOrderId}|{$razorpayPaymentId}", $this->keySecret);

        if (!hash_equals($expectedSignature, $razorpaySignature)) {
            return ['success' => false, 'error' => 'Payment signature verification failed.'];
        }

        return Database::transaction(function () use ($razorpayOrderId, $razorpayPaymentId, $razorpaySignature, $payload) {
            // Find existing payment
            $payment = Database::fetchOne(
                "SELECT * FROM `payments` WHERE `gateway_order_id` = :g_oid LIMIT 1",
                [':g_oid' => $razorpayOrderId]
            );

            if (!$payment) {
                return ['success' => false, 'error' => 'Corresponding order payment record not found.'];
            }

            // Prevent duplicate fulfillment
            if ($payment['status'] === 'completed') {
                return ['success' => true, 'order_id' => $payment['order_id'], 'message' => 'Already confirmed.'];
            }

            // Update payment table
            Database::execute(
                "UPDATE `payments` SET 
                    `gateway_transaction_id` = :txn,
                    `gateway_signature` = :sig,
                    `status` = 'completed',
                    `payload_dump` = :dump,
                    `updated_at` = NOW()
                 WHERE `id` = :id",
                [
                    ':txn' => $razorpayPaymentId,
                    ':sig' => $razorpaySignature,
                    ':dump' => json_encode($payload),
                    ':id' => $payment['id']
                ]
            );

            // Update order status
            Database::execute(
                "UPDATE `orders` SET `payment_status` = 'paid', `status` = 'confirmed', `updated_at` = NOW() WHERE `id` = :id",
                [':id' => $payment['order_id']]
            );

            return [
                'success' => true,
                'order_id' => $payment['order_id'],
                'transaction_id' => $razorpayPaymentId
            ];
        });
    }

    public function processWebhook(string $payload, string $signature): array
    {
        if (empty($this->webhookSecret)) {
            return ['success' => false, 'error' => 'Webhook secret not configured.'];
        }

        // Verify webhook signature
        $expectedSignature = hash_hmac('sha256', $payload, $this->webhookSecret);
        if (!hash_equals($expectedSignature, $signature)) {
            return ['success' => false, 'error' => 'Invalid webhook signature.'];
        }

        $data = json_decode($payload, true);
        $event = $data['event'] ?? '';

        if ($event === 'payment.captured') {
            $paymentEntity = $data['payload']['payment']['entity'] ?? [];
            $razorpayPaymentId = $paymentEntity['id'] ?? '';
            $razorpayOrderId = $paymentEntity['order_id'] ?? '';

            // Idempotent processing
            $existing = Database::fetchOne(
                "SELECT * FROM `payments` WHERE `gateway_transaction_id` = :txn LIMIT 1",
                [':txn' => $razorpayPaymentId]
            );

            if ($existing && $existing['status'] === 'completed') {
                return ['success' => true, 'message' => 'Duplicate webhook ignored (already completed).'];
            }

            $payment = Database::fetchOne(
                "SELECT * FROM `payments` WHERE `gateway_order_id` = :g_oid LIMIT 1",
                [':g_oid' => $razorpayOrderId]
            );

            if ($payment) {
                Database::execute(
                    "UPDATE `payments` SET `gateway_transaction_id` = :txn, `status` = 'completed', `updated_at` = NOW() WHERE `id` = :id",
                    [':txn' => $razorpayPaymentId, ':id' => $payment['id']]
                );

                Database::execute(
                    "UPDATE `orders` SET `payment_status` = 'paid', `status` = 'confirmed', `updated_at` = NOW() WHERE `id` = :id",
                    [':id' => $payment['order_id']]
                );
            }

            return ['success' => true, 'message' => 'Payment webhook processed successfully.'];
        }

        return ['success' => true, 'message' => 'Event noted, no state change required.'];
    }
}
