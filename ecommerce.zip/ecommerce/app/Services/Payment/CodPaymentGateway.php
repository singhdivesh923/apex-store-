<?php
declare(strict_types=1);

namespace App\Services\Payment;

use App\Services\Database;

class CodPaymentGateway implements PaymentGatewayInterface
{
    public function initializePayment(array $orderData): array
    {
        return [
            'success' => true,
            'type' => 'offline',
            'order_id' => $orderData['order_id'],
            'redirect_url' => base_url("/checkout/success?order_number={$orderData['order_number']}"),
            'message' => 'Your order has been placed successfully via Cash on Delivery.'
        ];
    }

    public function verifyPayment(array $payload): array
    {
        return [
            'success' => true,
            'status' => 'unpaid',
            'transaction_id' => 'COD-' . time()
        ];
    }

    public function processWebhook(string $payload, string $signature): array
    {
        return ['success' => false, 'error' => 'Webhooks not applicable for COD'];
    }
}
