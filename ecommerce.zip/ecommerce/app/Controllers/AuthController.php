<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Cart;
use App\Models\User;
use App\Services\Auth;
use App\Services\Database;
use App\Services\MailerService;
use App\Services\Session;

class AuthController extends Controller
{
    public function showLogin(): void
    {
        if (Auth::check()) {
            redirect('/account/orders');
        }

        $this->render('auth/login', [
            'pageTitle' => 'Sign In to Your Account',
        ]);
    }

    public function login(): void
    {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $this->backWithError('Please provide both email address and password.', '/login');
        }

        $res = Auth::attempt($email, $password, 'customer');

        if (!$res['success']) {
            $this->backWithError($res['error'], '/login');
        }

        // Migrate guest cart if exists
        $user = $res['user'];
        Cart::getOrCreateCartId((int)$user['id']);

        $intended = Session::get('intended_url', '/account/orders');
        Session::remove('intended_url');

        $this->redirectWithSuccess($intended, "Welcome back, {$user['name']}!");
    }

    public function showRegister(): void
    {
        if (Auth::check()) {
            redirect('/account/orders');
        }

        $this->render('auth/register', [
            'pageTitle' => 'Create Customer Account',
        ]);
    }

    public function register(): void
    {
        $name = trim($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['password_confirmation'] ?? '';
        $phone = trim($_POST['phone'] ?? '');

        if (empty($name) || empty($email) || empty($password)) {
            $this->backWithError('Please complete all required fields.', '/register');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->backWithError('Please enter a valid email address.', '/register');
        }

        if (strlen($password) < 8) {
            $this->backWithError('Password must be at least 8 characters long.', '/register');
        }

        if ($password !== $confirmPassword) {
            $this->backWithError('Passwords do not match.', '/register');
        }

        $existing = User::findByEmail($email);
        if ($existing) {
            $this->backWithError('An account with this email address already exists. Please log in.', '/register');
        }

        $userId = User::create([
            'name' => $name,
            'email' => $email,
            'password' => $password,
            'phone' => $phone ?: null,
            'role' => 'customer',
            'status' => 'active',
            'email_verified_at' => date('Y-m-d H:i:s'),
        ]);

        // Auto login
        Auth::attempt($email, $password);
        Cart::getOrCreateCartId($userId);

        $this->redirectWithSuccess('/account/orders', 'Your account has been created successfully!');
    }

    public function logout(): void
    {
        Auth::logout();
        Session::flash('success', 'You have been signed out.');
        redirect('/login');
    }

    public function showForgotPassword(): void
    {
        $this->render('auth/forgot_password', [
            'pageTitle' => 'Reset Your Password',
        ]);
    }

    public function forgotPassword(): void
    {
        $email = strtolower(trim($_POST['email'] ?? ''));
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->backWithError('Please provide a valid email address.', '/forgot-password');
        }

        // Rate limit password reset requests (max 3 per 15 minutes)
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $rateLimitKey = 'forgot_pw_' . md5($ip . '_' . $email);
        if (Auth::isRateLimited($rateLimitKey)) {
            $this->backWithError('Too many password reset requests. Please try again in 15 minutes.', '/forgot-password');
        }
        Auth::incrementRateLimit($rateLimitKey, 3, 900);

        $user = User::findByEmail($email);
        // Generic message prevents account enumeration
        $genericMsg = 'If that email address exists in our system, you will receive password reset instructions shortly.';

        if (!$user) {
            $this->redirectWithSuccess('/forgot-password', $genericMsg);
        }

        // Generate token and hash
        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $expiresAt = date('Y-m-d H:i:s', time() + 3600); // 1 hour validity

        // Delete any existing token for this email
        Database::execute("DELETE FROM `password_reset_tokens` WHERE `email` = :email", [':email' => $email]);

        Database::insert('password_reset_tokens', [
            'email' => $email,
            'token_hash' => $tokenHash,
            'expires_at' => $expiresAt,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $resetUrl = base_url("/reset-password?token={$token}&email=" . urlencode($email));
        $subject = "Password Reset Request";
        $body = "<h2>Password Reset</h2><p>Click the link below to set a new password. This link is valid for 1 hour.</p>";
        $body .= "<p><a href='{$resetUrl}'>{$resetUrl}</a></p>";

        MailerService::send($email, $subject, $body);

        $this->redirectWithSuccess('/forgot-password', $genericMsg);
    }

    public function showResetPassword(): void
    {
        $token = $_GET['token'] ?? '';
        $email = $_GET['email'] ?? '';

        $this->render('auth/reset_password', [
            'pageTitle' => 'Choose New Password',
            'token' => $token,
            'email' => $email,
        ]);
    }

    public function resetPassword(): void
    {
        $token = $_POST['token'] ?? '';
        $email = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['password_confirmation'] ?? '';

        if (empty($token) || empty($email) || empty($password)) {
            $this->backWithError('All fields are required.', "/reset-password?token={$token}&email=" . urlencode($email));
        }

        if (strlen($password) < 8) {
            $this->backWithError('Password must be at least 8 characters.', "/reset-password?token={$token}&email=" . urlencode($email));
        }

        if ($password !== $confirmPassword) {
            $this->backWithError('Passwords do not match.', "/reset-password?token={$token}&email=" . urlencode($email));
        }

        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $resetLimitKey = 'reset_pw_attempts_' . md5($ip);
        if (Auth::isRateLimited($resetLimitKey)) {
            $this->backWithError('Too many password reset attempts. Please try again in 15 minutes.', '/forgot-password');
        }

        $tokenHash = hash('sha256', $token);
        $record = Database::fetchOne(
            "SELECT * FROM `password_reset_tokens` WHERE `email` = :email AND `token_hash` = :hash AND `expires_at` > NOW() LIMIT 1",
            [':email' => $email, ':hash' => $tokenHash]
        );

        if (!$record) {
            Auth::incrementRateLimit($resetLimitKey, 5, 900);
            $this->backWithError('This password reset token is invalid or has expired. Please request a new one.', '/forgot-password');
        }

        Auth::clearRateLimit($resetLimitKey);

        $user = User::findByEmail($email);
        if ($user) {
            User::update((int)$user['id'], ['password' => $password]);
        }

        Database::execute("DELETE FROM `password_reset_tokens` WHERE `email` = :email", [':email' => $email]);

        $this->redirectWithSuccess('/login', 'Your password has been reset successfully. You may now sign in.');
    }
}
