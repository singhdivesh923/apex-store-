<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Models\Category;
use App\Services\Auth;
use App\Services\Database;
use App\Services\FileUploader;

class CategoryController extends Controller
{
    public function index(): void
    {
        $categories = Category::all();

        $this->render('admin/categories/index', [
            'pageTitle' => 'Manage Categories',
            'categories' => $categories,
        ], 'layouts/admin_header');
    }

    public function create(): void
    {
        $categories = Category::all();
        $this->render('admin/categories/form', [
            'pageTitle' => 'Create New Category',
            'categories' => $categories,
            'category' => null,
        ], 'layouts/admin_header');
    }

    public function store(): void
    {
        $name = trim($_POST['name'] ?? '');
        $parentId = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;
        $description = trim($_POST['description'] ?? '');
        $displayOrder = (int)($_POST['display_order'] ?? 0);
        $imageUrl = trim($_POST['image_url'] ?? '');

        if (empty($name)) {
            $this->backWithError('Category name is required.', '/admin/categories/create');
        }

        // Upload image if provided
        if (!empty($_FILES['image']['name'])) {
            try {
                $imageUrl = FileUploader::uploadImage($_FILES['image'], 'categories');
            } catch (\Throwable $e) {
                $this->backWithError($e->getMessage(), '/admin/categories/create');
            }
        }

        $id = Category::create([
            'name' => $name,
            'parent_id' => $parentId,
            'description' => $description,
            'image_url' => $imageUrl,
            'display_order' => $displayOrder,
            'is_active' => !empty($_POST['is_active']),
        ]);

        Database::insert('admin_logs', [
            'admin_id' => Auth::id(),
            'action' => 'create_category',
            'entity_type' => 'category',
            'entity_id' => $id,
            'details' => json_encode(['name' => $name]),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $this->redirectWithSuccess('/admin/categories', "Category '{$name}' created successfully.");
    }

    public function edit(int $id): void
    {
        $category = Category::findById($id);
        if (!$category) {
            $this->backWithError('Category not found.', '/admin/categories');
        }

        $categories = Category::all();
        $this->render('admin/categories/form', [
            'pageTitle' => "Edit Category: {$category['name']}",
            'categories' => $categories,
            'category' => $category,
        ], 'layouts/admin_header');
    }

    public function update(int $id): void
    {
        $name = trim($_POST['name'] ?? '');
        $parentId = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;
        $description = trim($_POST['description'] ?? '');
        $displayOrder = (int)($_POST['display_order'] ?? 0);
        $imageUrl = trim($_POST['image_url'] ?? '');

        if (empty($name)) {
            $this->backWithError('Category name is required.', "/admin/categories/edit/{$id}");
        }

        if ($parentId === $id) {
            $this->backWithError('A category cannot be its own parent.', "/admin/categories/edit/{$id}");
        }

        if (!empty($_FILES['image']['name'])) {
            try {
                $imageUrl = FileUploader::uploadImage($_FILES['image'], 'categories');
            } catch (\Throwable $e) {
                $this->backWithError($e->getMessage(), "/admin/categories/edit/{$id}");
            }
        }

        Category::update($id, [
            'name' => $name,
            'parent_id' => $parentId,
            'description' => $description,
            'image_url' => $imageUrl ?: null,
            'display_order' => $displayOrder,
            'is_active' => !empty($_POST['is_active']),
        ]);

        $this->redirectWithSuccess('/admin/categories', "Category updated successfully.");
    }

    public function delete(int $id): void
    {
        try {
            Category::delete($id);
            $this->redirectWithSuccess('/admin/categories', 'Category deleted.');
        } catch (\Throwable $e) {
            $this->backWithError($e->getMessage(), '/admin/categories');
        }
    }
}
