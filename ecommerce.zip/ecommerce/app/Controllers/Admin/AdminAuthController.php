<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Services\Auth;
use App\Services\Session;

class AdminAuthController extends Controller
{
    public function showLogin(): void
    {
        if (Auth::isAdmin()) {
            redirect('/admin');
        }

        $this->render('admin/auth/login', [
            'pageTitle' => 'Admin Sign In',
        ], ''); // No public layout
    }

    public function login(): void
    {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $this->backWithError('Email and password are required.', '/admin/login');
        }

        $res = Auth::attempt($email, $password, 'admin');

        if (!$res['success']) {
            $this->backWithError($res['error'], '/admin/login');
        }

        $this->redirectWithSuccess('/admin', 'Welcome to the Administrator Management Center.');
    }

    public function logout(): void
    {
        Auth::logout();
        Session::flash('success', 'You have been logged out of the admin panel.');
        redirect('/admin/login');
    }
}
