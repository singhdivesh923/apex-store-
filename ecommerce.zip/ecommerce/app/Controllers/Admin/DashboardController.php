<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Services\Database;

class DashboardController extends Controller
{
    public function index(): void
    {
        // 1. Total Net Sales (Strictly excluding cancelled, refunded, and unpaid orders)
        $salesRow = Database::fetchOne(
            "SELECT COALESCE(SUM(`total_amount`), 0) as `total_sales` 
             FROM `orders` 
             WHERE `status` NOT IN ('cancelled', 'refunded') AND `payment_status` = 'paid'"
        );
        $totalSales = (float)($salesRow['total_sales'] ?? 0.0);

        // 2. Total Orders Count
        $ordersCountRow = Database::fetchOne("SELECT COUNT(*) as `cnt` FROM `orders`");
        $totalOrders = (int)($ordersCountRow['cnt'] ?? 0);

        // 3. Pending Orders
        $pendingOrdersRow = Database::fetchOne("SELECT COUNT(*) as `cnt` FROM `orders` WHERE `status` = 'pending'");
        $pendingOrders = (int)($pendingOrdersRow['cnt'] ?? 0);

        // 4. Total Active Customers
        $customersRow = Database::fetchOne("SELECT COUNT(*) as `cnt` FROM `users` WHERE `role` = 'customer' AND `status` = 'active'");
        $totalCustomers = (int)($customersRow['cnt'] ?? 0);

        // 5. Total Active Products
        $productsRow = Database::fetchOne("SELECT COUNT(*) as `cnt` FROM `products` WHERE `status` = 'active'");
        $totalProducts = (int)($productsRow['cnt'] ?? 0);

        // 6. Low-stock Products
        $lowStockProducts = Database::fetchAll(
            "SELECT `id`, `name`, `sku`, `stock_quantity`, `low_stock_threshold`
             FROM `products`
             WHERE `stock_quantity` <= `low_stock_threshold` AND `status` = 'active'
             ORDER BY `stock_quantity` ASC
             LIMIT 8"
        );

        // 7. Recent Orders
        $recentOrders = Database::fetchAll(
            "SELECT o.*, u.`name` as `customer_name`, u.`email` as `customer_email`
             FROM `orders` o
             LEFT JOIN `users` u ON o.`user_id` = u.`id`
             ORDER BY o.`id` DESC
             LIMIT 8"
        );

        // 8. Recent Admin Activity Logs
        $recentLogs = Database::fetchAll(
            "SELECT al.*, u.`name` as `admin_name`
             FROM `admin_logs` al
             JOIN `users` u ON al.`admin_id` = u.`id`
             ORDER BY al.`id` DESC
             LIMIT 6"
        );

        $this->render('admin/dashboard/index', [
            'pageTitle' => 'Admin Dashboard Overview',
            'totalSales' => $totalSales,
            'totalOrders' => $totalOrders,
            'pendingOrders' => $pendingOrders,
            'totalCustomers' => $totalCustomers,
            'totalProducts' => $totalProducts,
            'lowStockProducts' => $lowStockProducts,
            'recentOrders' => $recentOrders,
            'recentLogs' => $recentLogs,
        ], 'layouts/admin_header');
    }
}
