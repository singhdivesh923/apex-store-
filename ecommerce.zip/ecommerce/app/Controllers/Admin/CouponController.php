<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Models\Coupon;
use App\Services\Auth;
use App\Services\Database;

class CouponController extends Controller
{
    public function index(): void
    {
        $coupons = Coupon::all();

        $this->render('admin/coupons/index', [
            'pageTitle' => 'Coupon & Discount Codes',
            'coupons' => $coupons,
        ], 'layouts/admin_header');
    }

    public function create(): void
    {
        $this->render('admin/coupons/form', [
            'pageTitle' => 'Create Promotion Code',
            'coupon' => null,
        ], 'layouts/admin_header');
    }

    public function store(): void
    {
        $code = strtoupper(trim($_POST['code'] ?? ''));
        $type = $_POST['type'] ?? 'percentage';
        $discountValue = (float)($_POST['discount_value'] ?? 0);
        $minOrder = (float)($_POST['min_order_amount'] ?? 0);
        $maxDiscount = !empty($_POST['max_discount_amount']) ? (float)$_POST['max_discount_amount'] : null;
        $usageLimit = !empty($_POST['usage_limit']) ? (int)$_POST['usage_limit'] : null;
        $startDate = !empty($_POST['start_date']) ? $_POST['start_date'] : null;
        $endDate = !empty($_POST['end_date']) ? $_POST['end_date'] : null;

        if (empty($code) || $discountValue <= 0) {
            $this->backWithError('Coupon code and discount value are required.', '/admin/coupons/create');
        }

        $existing = Coupon::findByCode($code);
        if ($existing) {
            $this->backWithError("The coupon code '{$code}' already exists.", '/admin/coupons/create');
        }

        $couponId = Coupon::create([
            'code' => $code,
            'type' => $type,
            'discount_value' => $discountValue,
            'min_order_amount' => $minOrder,
            'max_discount_amount' => $maxDiscount,
            'usage_limit' => $usageLimit,
            'is_active' => !empty($_POST['is_active']),
            'start_date' => $startDate,
            'end_date' => $endDate,
        ]);

        Database::insert('admin_logs', [
            'admin_id' => Auth::id(),
            'action' => 'create_coupon',
            'entity_type' => 'coupon',
            'entity_id' => $couponId,
            'details' => json_encode(['code' => $code]),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $this->redirectWithSuccess('/admin/coupons', "Coupon '{$code}' created successfully.");
    }

    public function edit(int $id): void
    {
        $coupon = Coupon::findById($id);
        if (!$coupon) {
            $this->backWithError('Coupon not found.', '/admin/coupons');
        }

        $this->render('admin/coupons/form', [
            'pageTitle' => "Edit Promotion: {$coupon['code']}",
            'coupon' => $coupon,
        ], 'layouts/admin_header');
    }

    public function update(int $id): void
    {
        $code = strtoupper(trim($_POST['code'] ?? ''));
        $type = $_POST['type'] ?? 'percentage';
        $discountValue = (float)($_POST['discount_value'] ?? 0);
        $minOrder = (float)($_POST['min_order_amount'] ?? 0);
        $maxDiscount = !empty($_POST['max_discount_amount']) ? (float)$_POST['max_discount_amount'] : null;
        $usageLimit = !empty($_POST['usage_limit']) ? (int)$_POST['usage_limit'] : null;
        $startDate = !empty($_POST['start_date']) ? $_POST['start_date'] : null;
        $endDate = !empty($_POST['end_date']) ? $_POST['end_date'] : null;

        if (empty($code) || $discountValue <= 0) {
            $this->backWithError('Coupon code and discount value are required.', "/admin/coupons/edit/{$id}");
        }

        Coupon::update($id, [
            'code' => $code,
            'type' => $type,
            'discount_value' => $discountValue,
            'min_order_amount' => $minOrder,
            'max_discount_amount' => $maxDiscount,
            'usage_limit' => $usageLimit,
            'is_active' => !empty($_POST['is_active']),
            'start_date' => $startDate,
            'end_date' => $endDate,
        ]);

        $this->redirectWithSuccess('/admin/coupons', "Coupon updated successfully.");
    }

    public function delete(int $id): void
    {
        Coupon::delete($id);
        $this->redirectWithSuccess('/admin/coupons', 'Coupon deleted.');
    }
}
