<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Models\Setting;
use App\Services\Auth;
use App\Services\Database;

class SettingController extends Controller
{
    public function index(): void
    {
        $settings = Setting::all();

        $this->render('admin/settings/index', [
            'pageTitle' => 'Store & Gateway Settings',
            'settings' => $settings,
        ], 'layouts/admin_header');
    }

    public function update(): void
    {
        $fields = [
            'store_name' => 'general',
            'store_tagline' => 'general',
            'store_email' => 'contact',
            'store_phone' => 'contact',
            'store_address' => 'contact',
            'currency_code' => 'localization',
            'currency_symbol' => 'localization',
            'tax_rate_percent' => 'tax',
            'flat_shipping_rate' => 'shipping',
            'free_shipping_threshold' => 'shipping',
            'enable_cod' => 'payment',
            'enable_razorpay' => 'payment',
            'razorpay_key_id' => 'payment',
            'razorpay_key_secret' => 'payment',
        ];

        foreach ($fields as $key => $group) {
            $val = $_POST[$key] ?? '0';
            if ($key === 'enable_cod' || $key === 'enable_razorpay') {
                $val = !empty($_POST[$key]) ? '1' : '0';
            }
            Setting::set($key, (string)$val, $group);
        }

        Database::insert('admin_logs', [
            'admin_id' => Auth::id(),
            'action' => 'update_settings',
            'entity_type' => 'settings',
            'details' => json_encode(['updated_at' => date('Y-m-d H:i:s')]),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $this->redirectWithSuccess('/admin/settings', 'Store configuration updated successfully.');
    }
}
