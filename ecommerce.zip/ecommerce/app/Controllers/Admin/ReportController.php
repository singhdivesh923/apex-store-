<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Services\Database;

class ReportController extends Controller
{
    public function index(): void
    {
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-d');

        // Sales totals in date range
        $salesRow = Database::fetchOne(
            "SELECT COUNT(*) as `order_count`,
                    COALESCE(SUM(`total_amount`), 0) as `gross_sales`,
                    COALESCE(SUM(`discount_amount`), 0) as `total_discounts`,
                    COALESCE(SUM(`shipping_amount`), 0) as `total_shipping`,
                    COALESCE(SUM(`tax_amount`), 0) as `total_tax`
             FROM `orders`
             WHERE `created_at` >= :sdate AND `created_at` <= :edate
               AND `status` NOT IN ('cancelled', 'refunded') AND `payment_status` = 'paid'",
            [':sdate' => $startDate . ' 00:00:00', ':edate' => $endDate . ' 23:59:59']
        );

        // Daily breakdown
        $daily = Database::fetchAll(
            "SELECT DATE(`created_at`) as `sale_date`,
                    COUNT(*) as `orders`,
                    COALESCE(SUM(`total_amount`), 0) as `revenue`
             FROM `orders`
             WHERE `created_at` >= :sdate AND `created_at` <= :edate
               AND `status` NOT IN ('cancelled', 'refunded') AND `payment_status` = 'paid'
             GROUP BY DATE(`created_at`)
             ORDER BY `sale_date` ASC",
            [':sdate' => $startDate . ' 00:00:00', ':edate' => $endDate . ' 23:59:59']
        );

        // Low stock report items
        $lowStock = Database::fetchAll(
            "SELECT `id`, `name`, `sku`, `price`, `stock_quantity`, `low_stock_threshold`
             FROM `products`
             WHERE `stock_quantity` <= `low_stock_threshold` AND `status` = 'active'
             ORDER BY `stock_quantity` ASC"
        );

        $this->render('admin/reports/index', [
            'pageTitle' => 'Financial & Inventory Reports',
            'startDate' => $startDate,
            'endDate' => $endDate,
            'sales' => $salesRow,
            'daily' => $daily,
            'lowStock' => $lowStock,
        ], 'layouts/admin_header');
    }

    public function exportCsv(): void
    {
        $startDate = $_GET['start_date'] ?? date('Y-m-01');
        $endDate = $_GET['end_date'] ?? date('Y-m-d');

        $orders = Database::fetchAll(
            "SELECT o.`order_number`, o.`created_at`, o.`status`, o.`payment_status`, o.`payment_method`,
                    o.`subtotal`, o.`discount_amount`, o.`shipping_amount`, o.`tax_amount`, o.`total_amount`,
                    COALESCE(u.`name`, 'Guest') as `customer_name`,
                    COALESCE(u.`email`, o.`guest_email`) as `customer_email`
             FROM `orders` o
             LEFT JOIN `users` u ON o.`user_id` = u.`id`
             WHERE o.`created_at` >= :sdate AND o.`created_at` <= :edate
             ORDER BY o.`id` DESC",
            [':sdate' => $startDate . ' 00:00:00', ':edate' => $endDate . ' 23:59:59']
        );

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=orders_report_' . date('Ymd_His') . '.csv');

        $out = fopen('php://output', 'w');

        // CSV Header
        fputcsv($out, ['Order Number', 'Date', 'Customer Name', 'Customer Email', 'Status', 'Payment Status', 'Method', 'Subtotal', 'Discount', 'Shipping', 'Tax', 'Total']);

        foreach ($orders as $row) {
            // Defense against CSV injection: prefix formula chars with single quote
            $cleanRow = array_map(function ($val) {
                $str = (string)$val;
                if (in_array(substr($str, 0, 1), ['=', '+', '-', '@', "\t", "\r"], true)) {
                    return "'" . $str;
                }
                return $str;
            }, [
                $row['order_number'],
                $row['created_at'],
                $row['customer_name'],
                $row['customer_email'],
                $row['status'],
                $row['payment_status'],
                $row['payment_method'],
                $row['subtotal'],
                $row['discount_amount'],
                $row['shipping_amount'],
                $row['tax_amount'],
                $row['total_amount']
            ]);

            fputcsv($out, $cleanRow);
        }

        fclose($out);
        exit;
    }
}
