<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use App\Services\Auth;
use App\Services\Database;
use App\Services\FileUploader;

class ProductController extends Controller
{
    public function index(): void
    {
        $page = max(1, (int)($_GET['page'] ?? 1));
        $filters = [
            'search' => trim($_GET['search'] ?? ''),
            'category_id' => $_GET['category_id'] ?? null,
            'sort' => $_GET['sort'] ?? 'newest',
        ];

        $catalog = Product::getPaginatedCatalog($filters, $page, 15);
        $categories = Category::all();

        $this->render('admin/products/index', [
            'pageTitle' => 'Manage Products',
            'catalog' => $catalog,
            'categories' => $categories,
            'filters' => $filters,
        ], 'layouts/admin_header');
    }

    public function create(): void
    {
        $categories = Category::all();
        $this->render('admin/products/form', [
            'pageTitle' => 'Add New Product',
            'categories' => $categories,
            'product' => null,
        ], 'layouts/admin_header');
    }

    public function store(): void
    {
        $name = trim($_POST['name'] ?? '');
        $sku = strtoupper(trim($_POST['sku'] ?? ''));
        $categoryId = (int)($_POST['category_id'] ?? 0);
        $price = (float)($_POST['price'] ?? 0);
        $discountPrice = !empty($_POST['discount_price']) ? (float)$_POST['discount_price'] : null;
        $stock = max(0, (int)($_POST['stock_quantity'] ?? 0));
        $lowStock = max(1, (int)($_POST['low_stock_threshold'] ?? 5));
        $shortDesc = trim($_POST['short_description'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $status = $_POST['status'] ?? 'active';

        if (empty($name) || empty($sku) || $categoryId <= 0 || $price <= 0) {
            $this->backWithError('Please provide a valid product name, unique SKU, category, and price.', '/admin/products/create');
        }

        // Check SKU uniqueness
        $existing = Database::fetchOne("SELECT `id` FROM `products` WHERE `sku` = :sku LIMIT 1", [':sku' => $sku]);
        if ($existing) {
            $this->backWithError("The SKU '{$sku}' is already assigned to another product.", '/admin/products/create');
        }

        try {
            $productId = Product::create([
                'name' => $name,
                'sku' => $sku,
                'category_id' => $categoryId,
                'price' => $price,
                'discount_price' => $discountPrice,
                'stock_quantity' => $stock,
                'low_stock_threshold' => $lowStock,
                'short_description' => $shortDesc,
                'description' => $desc,
                'is_featured' => !empty($_POST['is_featured']),
                'is_bestseller' => !empty($_POST['is_bestseller']),
                'is_new_arrival' => !empty($_POST['is_new_arrival']),
                'status' => $status,
            ]);

            // Handle primary image upload if provided
            if (!empty($_FILES['image']['name'])) {
                $imagePath = FileUploader::uploadImage($_FILES['image'], 'products');
                Database::insert('product_images', [
                    'product_id' => $productId,
                    'image_path' => $imagePath,
                    'is_primary' => 1,
                    'display_order' => 1,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

            // Log admin action
            Database::insert('admin_logs', [
                'admin_id' => Auth::id(),
                'action' => 'create_product',
                'entity_type' => 'product',
                'entity_id' => $productId,
                'details' => json_encode(['sku' => $sku, 'name' => $name]),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $this->redirectWithSuccess('/admin/products', "Product '{$name}' created successfully.");
        } catch (\Throwable $e) {
            $this->backWithError('Failed to create product: ' . $e->getMessage(), '/admin/products/create');
        }
    }

    public function edit(int $id): void
    {
        $product = Product::findById($id);
        if (!$product) {
            $this->backWithError('Product not found.', '/admin/products');
        }

        $categories = Category::all();
        $this->render('admin/products/form', [
            'pageTitle' => "Edit Product: {$product['name']}",
            'categories' => $categories,
            'product' => $product,
        ], 'layouts/admin_header');
    }

    public function update(int $id): void
    {
        $product = Product::findById($id);
        if (!$product) {
            $this->backWithError('Product not found.', '/admin/products');
        }

        $name = trim($_POST['name'] ?? '');
        $sku = strtoupper(trim($_POST['sku'] ?? ''));
        $categoryId = (int)($_POST['category_id'] ?? 0);
        $price = (float)($_POST['price'] ?? 0);
        $discountPrice = !empty($_POST['discount_price']) ? (float)$_POST['discount_price'] : null;
        $stock = max(0, (int)($_POST['stock_quantity'] ?? 0));
        $lowStock = max(1, (int)($_POST['low_stock_threshold'] ?? 5));
        $shortDesc = trim($_POST['short_description'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $status = $_POST['status'] ?? 'active';

        // Check SKU collision with other products
        $existing = Database::fetchOne("SELECT `id` FROM `products` WHERE `sku` = :sku AND `id` != :id LIMIT 1", [':sku' => $sku, ':id' => $id]);
        if ($existing) {
            $this->backWithError("The SKU '{$sku}' is already assigned to another product.", "/admin/products/edit/{$id}");
        }

        try {
            Product::update($id, [
                'name' => $name,
                'sku' => $sku,
                'category_id' => $categoryId,
                'price' => $price,
                'discount_price' => $discountPrice,
                'stock_quantity' => $stock,
                'low_stock_threshold' => $lowStock,
                'short_description' => $shortDesc,
                'description' => $desc,
                'is_featured' => !empty($_POST['is_featured']),
                'is_bestseller' => !empty($_POST['is_bestseller']),
                'is_new_arrival' => !empty($_POST['is_new_arrival']),
                'status' => $status,
            ]);

            // Handle optional new image upload
            if (!empty($_FILES['image']['name'])) {
                $imagePath = FileUploader::uploadImage($_FILES['image'], 'products');
                // Remove existing primary flag
                Database::execute("UPDATE `product_images` SET `is_primary` = 0 WHERE `product_id` = :id", [':id' => $id]);
                Database::insert('product_images', [
                    'product_id' => $id,
                    'image_path' => $imagePath,
                    'is_primary' => 1,
                    'display_order' => 1,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

            // Log admin action
            Database::insert('admin_logs', [
                'admin_id' => Auth::id(),
                'action' => 'update_product',
                'entity_type' => 'product',
                'entity_id' => $id,
                'details' => json_encode(['sku' => $sku]),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $this->redirectWithSuccess('/admin/products', "Product updated successfully.");
        } catch (\Throwable $e) {
            $this->backWithError('Failed to update product: ' . $e->getMessage(), "/admin/products/edit/{$id}");
        }
    }

    public function delete(int $id): void
    {
        try {
            Product::delete($id);
            Database::insert('admin_logs', [
                'admin_id' => Auth::id(),
                'action' => 'delete_or_archive_product',
                'entity_type' => 'product',
                'entity_id' => $id,
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $this->redirectWithSuccess('/admin/products', 'Product deleted or archived successfully.');
        } catch (\Throwable $e) {
            $this->backWithError($e->getMessage(), '/admin/products');
        }
    }
}
