<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Models\Review;

class ReviewController extends Controller
{
    public function index(): void
    {
        $page = max(1, (int)($_GET['page'] ?? 1));
        $status = $_GET['status'] ?? null;

        $reviews = Review::allPaginated($page, 15, $status);

        $this->render('admin/reviews/index', [
            'pageTitle' => 'Moderate Reviews',
            'reviews' => $reviews,
            'currentStatus' => $status,
        ], 'layouts/admin_header');
    }

    public function updateStatus(int $id): void
    {
        $status = $_POST['status'] ?? 'approved';
        if (in_array($status, ['approved', 'rejected', 'pending'], true)) {
            Review::updateStatus($id, $status);
            $this->redirectWithSuccess('/admin/reviews', "Review marked as {$status}.");
        }

        $this->backWithError('Invalid review status.', '/admin/reviews');
    }
}
