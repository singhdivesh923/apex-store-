<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Models\Address;
use App\Models\Order;
use App\Models\User;
use App\Services\Auth;
use App\Services\Database;

class CustomerController extends Controller
{
    public function index(): void
    {
        $page = max(1, (int)($_GET['page'] ?? 1));
        $search = trim($_GET['search'] ?? '');

        $customers = User::getCustomersPaginated($page, 15, $search);

        $this->render('admin/customers/index', [
            'pageTitle' => 'Customer Management',
            'customers' => $customers,
            'search' => $search,
        ], 'layouts/admin_header');
    }

    public function show(int $id): void
    {
        $customer = User::findById($id);
        if (!$customer || $customer['role'] !== 'customer') {
            $this->backWithError('Customer not found.', '/admin/customers');
        }

        $orders = Order::getCustomerOrders($id);
        $addresses = Address::getByUser($id);

        $this->render('admin/customers/detail', [
            'pageTitle' => 'Customer: ' . $customer['name'],
            'customer' => $customer,
            'orders' => $orders,
            'addresses' => $addresses,
        ], 'layouts/admin_header');
    }

    public function toggleStatus(int $id): void
    {
        $customer = User::findById($id);
        if (!$customer || $customer['role'] !== 'customer') {
            $this->backWithError('Customer not found.', '/admin/customers');
        }

        $newStatus = ($customer['status'] === 'active') ? 'suspended' : 'active';
        User::update($id, ['status' => $newStatus]);

        Database::insert('admin_logs', [
            'admin_id' => Auth::id(),
            'action' => 'toggle_customer_status',
            'entity_type' => 'customer',
            'entity_id' => $id,
            'details' => json_encode(['new_status' => $newStatus]),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        $this->redirectWithSuccess("/admin/customers/{$id}", "Customer account is now {$newStatus}.");
    }
}
