<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Controllers\Controller;
use App\Models\Order;
use App\Services\Auth;

class OrderController extends Controller
{
    public function index(): void
    {
        $page = max(1, (int)($_GET['page'] ?? 1));
        $filters = [
            'status' => $_GET['status'] ?? '',
            'payment_status' => $_GET['payment_status'] ?? '',
            'search' => trim($_GET['search'] ?? ''),
            'start_date' => $_GET['start_date'] ?? '',
            'end_date' => $_GET['end_date'] ?? '',
        ];

        $ordersData = Order::getAdminOrdersPaginated($filters, $page, 15);

        $this->render('admin/orders/index', [
            'pageTitle' => 'Order Management',
            'orders' => $ordersData,
            'filters' => $filters,
        ], 'layouts/admin_header');
    }

    public function show(int $id): void
    {
        $order = Order::findById($id);
        if (!$order) {
            $this->backWithError('Order not found.', '/admin/orders');
        }

        $this->render('admin/orders/detail', [
            'pageTitle' => 'Order #' . $order['order_number'],
            'order' => $order,
            'allowedTransitions' => Order::ALLOWED_TRANSITIONS[$order['status']] ?? [],
        ], 'layouts/admin_header');
    }

    public function updateStatus(int $id): void
    {
        $status = $_POST['status'] ?? '';
        $adminNotes = trim($_POST['admin_notes'] ?? '');

        try {
            $res = Order::updateStatus($id, $status, Auth::id(), $adminNotes ?: null);
            $this->redirectWithSuccess("/admin/orders/{$id}", $res['message']);
        } catch (\Throwable $e) {
            $this->backWithError('Status update failed: ' . $e->getMessage(), "/admin/orders/{$id}");
        }
    }
}
