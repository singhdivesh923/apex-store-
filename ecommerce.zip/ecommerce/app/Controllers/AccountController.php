<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Address;
use App\Models\User;
use App\Services\Auth;
use App\Services\Session;

class AccountController extends Controller
{
    public function profile(): void
    {
        $user = Auth::user();

        $this->render('account/profile', [
            'pageTitle' => 'My Account Profile',
            'user' => $user,
        ]);
    }

    public function updateProfile(): void
    {
        $userId = Auth::id();
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';

        if (empty($name)) {
            $this->backWithError('Full name is required.', '/account/profile');
        }

        $updateData = [
            'name' => $name,
            'phone' => $phone ?: null,
        ];

        // Handle password update
        if (!empty($newPassword)) {
            $user = User::findById($userId);
            $fullUser = Database::fetchOne("SELECT password_hash FROM users WHERE id = :id", [':id' => $userId]);

            if (empty($currentPassword) || !password_verify($currentPassword, $fullUser['password_hash'])) {
                $this->backWithError('Current password entered is incorrect.', '/account/profile');
            }

            if (strlen($newPassword) < 8) {
                $this->backWithError('New password must be at least 8 characters long.', '/account/profile');
            }

            $updateData['password'] = $newPassword;
        }

        User::update($userId, $updateData);
        $this->redirectWithSuccess('/account/profile', 'Profile updated successfully.');
    }

    public function addresses(): void
    {
        $userId = Auth::id();
        $addresses = Address::getByUser($userId);

        $this->render('account/addresses', [
            'pageTitle' => 'Address Book',
            'addresses' => $addresses,
        ]);
    }

    public function storeAddress(): void
    {
        $userId = Auth::id();
        $data = [
            'recipient_name' => trim($_POST['recipient_name'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'address_line1' => trim($_POST['address_line1'] ?? ''),
            'address_line2' => trim($_POST['address_line2'] ?? ''),
            'city' => trim($_POST['city'] ?? ''),
            'state' => trim($_POST['state'] ?? ''),
            'postal_code' => trim($_POST['postal_code'] ?? ''),
            'country' => trim($_POST['country'] ?? 'US'),
            'type' => $_POST['type'] ?? 'both',
            'is_default' => !empty($_POST['is_default']),
        ];

        if (empty($data['recipient_name']) || empty($data['phone']) || empty($data['address_line1']) || empty($data['city']) || empty($data['postal_code'])) {
            $this->backWithError('Please provide all mandatory address fields.', '/account/addresses');
        }

        Address::create($userId, $data);
        $this->redirectWithSuccess('/account/addresses', 'New address saved to your address book.');
    }

    public function deleteAddress(int $id): void
    {
        $userId = Auth::id();
        Address::delete($id, $userId);
        $this->redirectWithSuccess('/account/addresses', 'Address deleted.');
    }
}
