<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Order;
use App\Services\Auth;
use App\Services\Session;

class OrderController extends Controller
{
    public function index(): void
    {
        $userId = Auth::id();
        $orders = Order::getCustomerOrders($userId);

        $this->render('account/orders', [
            'pageTitle' => 'My Orders',
            'orders' => $orders,
        ]);
    }

    public function show(string $orderNumber): void
    {
        $userId = Auth::id();
        $order = Order::findByOrderNumber($orderNumber);

        if (!$order) {
            http_response_code(404);
            $this->render('pages/404', ['pageTitle' => 'Order Not Found']);
            return;
        }

        // Strict authorization check against IDOR
        if ((int)$order['user_id'] !== $userId && !Auth::isAdmin()) {
            Session::flash('error', 'You are not authorized to view this order.');
            redirect('/account/orders');
        }

        $this->render('account/order_detail', [
            'pageTitle' => 'Order #' . $order['order_number'],
            'order' => $order,
        ]);
    }

    public function cancel(string $orderNumber): void
    {
        $userId = Auth::id();
        $order = Order::findByOrderNumber($orderNumber);

        if (!$order || (int)$order['user_id'] !== $userId) {
            $this->backWithError('Unauthorized action.', '/account/orders');
        }

        if (!in_array($order['status'], ['pending', 'confirmed'], true)) {
            $this->backWithError('This order can no longer be cancelled as it is already being processed.', "/account/orders/{$orderNumber}");
        }

        try {
            Order::updateStatus((int)$order['id'], 'cancelled', null, 'Cancelled by customer.');
            $this->redirectWithSuccess("/account/orders/{$orderNumber}", 'Order cancelled successfully. Any reserved inventory has been released.');
        } catch (\Throwable $e) {
            $this->backWithError('Failed to cancel order: ' . $e->getMessage(), "/account/orders/{$orderNumber}");
        }
    }
}
