<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Cart;
use App\Models\Coupon;
use App\Services\Auth;
use App\Services\Session;

class CartController extends Controller
{
    public function index(): void
    {
        $userId = Auth::id();
        $cartId = Cart::getOrCreateCartId($userId);

        $appliedCoupon = Session::get('applied_coupon');
        $cartData = Cart::getTotals($cartId, $appliedCoupon);

        $this->render('cart/index', [
            'pageTitle' => 'Shopping Cart',
            'cart' => $cartData,
        ]);
    }

    public function add(): void
    {
        $productId = (int)($_POST['product_id'] ?? 0);
        $quantity = max(1, (int)($_POST['quantity'] ?? 1));

        $userId = Auth::id();
        $cartId = Cart::getOrCreateCartId($userId);

        $result = Cart::addItem($cartId, $productId, $quantity);

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            $appliedCoupon = Session::get('applied_coupon');
            $totals = Cart::getTotals($cartId, $appliedCoupon);
            $result['cart_count'] = $totals['total_items'];
            $this->json($result, $result['success'] ? 200 : 400);
        }

        if ($result['success']) {
            Session::flash('success', $result['message']);
        } else {
            Session::flash('error', $result['error']);
        }

        $referer = $_SERVER['HTTP_REFERER'] ?? '/cart';
        redirect($referer);
    }

    public function update(): void
    {
        $productId = (int)($_POST['product_id'] ?? 0);
        $quantity = max(0, (int)($_POST['quantity'] ?? 1));

        $userId = Auth::id();
        $cartId = Cart::getOrCreateCartId($userId);

        $result = Cart::updateQuantity($cartId, $productId, $quantity);

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            $appliedCoupon = Session::get('applied_coupon');
            $totals = Cart::getTotals($cartId, $appliedCoupon);
            $result['totals'] = $totals;
            $this->json($result, $result['success'] ? 200 : 400);
        }

        if (!$result['success']) {
            Session::flash('error', $result['error']);
        }

        redirect('/cart');
    }

    public function remove(): void
    {
        $productId = (int)($_POST['product_id'] ?? 0);

        $userId = Auth::id();
        $cartId = Cart::getOrCreateCartId($userId);

        $result = Cart::removeItem($cartId, $productId);

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            $appliedCoupon = Session::get('applied_coupon');
            $totals = Cart::getTotals($cartId, $appliedCoupon);
            $result['totals'] = $totals;
            $this->json($result, 200);
        }

        Session::flash('success', 'Item removed from your cart.');
        redirect('/cart');
    }

    public function applyCoupon(): void
    {
        $code = trim($_POST['coupon_code'] ?? '');
        if (empty($code)) {
            $this->backWithError('Please enter a coupon code.', '/cart');
        }

        $userId = Auth::id();
        $cartId = Cart::getOrCreateCartId($userId);
        $totals = Cart::getTotals($cartId);

        $res = Coupon::validateCoupon($code, $totals['subtotal'], $userId);

        if (!$res['valid']) {
            $this->backWithError($res['error'], '/cart');
        }

        Session::set('applied_coupon', $res['coupon']);
        $this->redirectWithSuccess('/cart', 'Promotion code applied successfully!');
    }

    public function removeCoupon(): void
    {
        Session::remove('applied_coupon');
        $this->redirectWithSuccess('/cart', 'Promotion code removed.');
    }
}
