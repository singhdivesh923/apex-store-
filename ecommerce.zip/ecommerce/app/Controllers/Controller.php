<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Services\Session;

abstract class Controller
{
    /**
     * Render a view file with layout wrapping
     */
    protected function render(string $viewPath, array $data = [], string $layout = 'layouts/header'): void
    {
        extract($data);

        $baseViewDir = dirname(__DIR__) . '/Views/';
        $viewFile = $baseViewDir . $viewPath . '.php';

        if (!file_exists($viewFile)) {
            throw new \RuntimeException("View file not found: {$viewPath}");
        }

        // Include header layout if specified
        if ($layout) {
            $headerFile = $baseViewDir . $layout . '.php';
            if (file_exists($headerFile)) {
                require $headerFile;
            }
        }

        // Render target view
        require $viewFile;

        // Include footer layout if standard header layout was used
        if ($layout === 'layouts/header') {
            $footerFile = $baseViewDir . 'layouts/footer.php';
            if (file_exists($footerFile)) {
                require $footerFile;
            }
        } elseif ($layout === 'layouts/admin_header') {
            $footerFile = $baseViewDir . 'layouts/admin_footer.php';
            if (file_exists($footerFile)) {
                require $footerFile;
            }
        }
    }

    /**
     * Send standard JSON response
     */
    protected function json(mixed $data, int $statusCode = 200): never
    {
        json_response($data, $statusCode);
    }

    /**
     * Flash error and redirect back or to fallback URL
     */
    protected function backWithError(string $message, string $fallback = '/'): never
    {
        Session::flash('error', $message);
        $referer = $_SERVER['HTTP_REFERER'] ?? $fallback;
        redirect($referer);
    }

    /**
     * Flash success and redirect
     */
    protected function redirectWithSuccess(string $url, string $message): never
    {
        Session::flash('success', $message);
        redirect($url);
    }
}
