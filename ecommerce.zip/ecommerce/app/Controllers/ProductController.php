<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Review;
use App\Models\Setting;
use App\Services\Auth;

class ProductController extends Controller
{
    public function index(): void
    {
        $page = max(1, (int)($_GET['page'] ?? 1));
        $filters = [
            'search' => trim($_GET['q'] ?? ''),
            'category_slug' => trim($_GET['category'] ?? ''),
            'min_price' => $_GET['min_price'] ?? null,
            'max_price' => $_GET['max_price'] ?? null,
            'in_stock' => !empty($_GET['in_stock']),
            'sort' => $_GET['sort'] ?? 'newest',
        ];

        $catalog = Product::getPaginatedCatalog($filters, $page, 12);
        $categories = Category::all();

        $currentCategory = null;
        if (!empty($filters['category_slug'])) {
            $currentCategory = Category::findBySlug($filters['category_slug']);
        }

        $this->render('catalog/index', [
            'pageTitle' => $currentCategory ? $currentCategory['name'] . ' | Catalog' : 'All Products | Catalog',
            'catalog' => $catalog,
            'categories' => $categories,
            'currentCategory' => $currentCategory,
            'filters' => $filters,
        ]);
    }

    public function show(string $slug): void
    {
        $product = Product::findBySlug($slug);
        if (!$product) {
            http_response_code(404);
            $this->render('pages/404', ['pageTitle' => 'Product Not Found']);
            return;
        }

        $relatedProducts = Product::getRelated((int)$product['category_id'], (int)$product['id'], 4);
        $reviews = Review::getForProduct((int)$product['id']);

        $this->render('catalog/detail', [
            'pageTitle' => $product['name'] . ' | ' . Setting::get('store_name', 'ApexStore'),
            'product' => $product,
            'relatedProducts' => $relatedProducts,
            'reviews' => $reviews,
            'isLoggedIn' => Auth::check(),
        ]);
    }
}
