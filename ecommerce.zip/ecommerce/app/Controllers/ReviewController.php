<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Product;
use App\Models\Review;
use App\Services\Auth;
use App\Services\Session;

class ReviewController extends Controller
{
    public function store(): void
    {
        if (!Auth::check()) {
            $this->backWithError('Please sign in to submit a review.', '/login');
        }

        $userId = Auth::id();
        $productId = (int)($_POST['product_id'] ?? 0);
        $rating = (int)($_POST['rating'] ?? 5);
        $title = trim($_POST['title'] ?? '');
        $comment = trim($_POST['comment'] ?? '');

        $product = Product::findById($productId);
        if (!$product) {
            $this->backWithError('Product not found.', '/');
        }

        if (empty($title) || empty($comment)) {
            $this->backWithError('Please provide both a review headline and comment.', "/product/{$product['slug']}");
        }

        Review::create($productId, $userId, $rating, $title, $comment);
        $this->redirectWithSuccess("/product/{$product['slug']}", 'Thank you! Your product review has been submitted.');
    }
}
