<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Wishlist;
use App\Services\Auth;
use App\Services\Session;

class WishlistController extends Controller
{
    public function index(): void
    {
        $userId = Auth::id();
        $items = Wishlist::getForUser($userId);

        $this->render('account/wishlist', [
            'pageTitle' => 'My Wishlist',
            'items' => $items,
        ]);
    }

    public function toggle(): void
    {
        if (!Auth::check()) {
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
                $this->json(['success' => false, 'error' => 'Please sign in to save items to your wishlist.'], 401);
            }
            $this->backWithError('Please sign in to save items to your wishlist.', '/login');
        }

        $productId = (int)($_POST['product_id'] ?? 0);
        $userId = Auth::id();

        $result = Wishlist::toggle($userId, $productId);

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            $this->json(['success' => true, 'saved' => $result['saved'], 'message' => $result['message']]);
        }

        Session::flash('success', $result['message']);
        $referer = $_SERVER['HTTP_REFERER'] ?? '/wishlist';
        redirect($referer);
    }

    public function remove(): void
    {
        $productId = (int)($_POST['product_id'] ?? 0);
        $userId = Auth::id();

        Wishlist::remove($userId, $productId);
        Session::flash('success', 'Item removed from your wishlist.');
        redirect('/wishlist');
    }
}
