<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Address;
use App\Models\Cart;
use App\Models\Order;
use App\Models\Setting;
use App\Services\Auth;
use App\Services\MailerService;
use App\Services\Payment\PaymentFactory;
use App\Services\Session;
use Throwable;

class CheckoutController extends Controller
{
    public function index(): void
    {
        $userId = Auth::id();
        $cartId = Cart::getOrCreateCartId($userId);

        $appliedCoupon = Session::get('applied_coupon');
        $cart = Cart::getTotals($cartId, $appliedCoupon);

        if (empty($cart['items'])) {
            Session::flash('warning', 'Your shopping cart is empty.');
            redirect('/cart');
        }

        // Check if any cart item exceeds stock
        foreach ($cart['items'] as $item) {
            if ($item['exceeds_stock'] || !$item['is_available']) {
                Session::flash('error', "Item '{$item['name']}' has insufficient stock. Please update your cart before checkout.");
                redirect('/cart');
            }
        }

        $addresses = $userId ? Address::getByUser($userId) : [];
        $enableCod = (bool) Setting::get('enable_cod', true);
        $enableRazorpay = (bool) Setting::get('enable_razorpay', false);

        $this->render('checkout/index', [
            'pageTitle' => 'Secure Checkout',
            'cart' => $cart,
            'addresses' => $addresses,
            'enableCod' => $enableCod,
            'enableRazorpay' => $enableRazorpay,
            'user' => Auth::user(),
        ]);
    }

    public function process(): void
    {
        $userId = Auth::id();
        $cartId = Cart::getOrCreateCartId($userId);

        // Anti-duplicate submission check
        $lastOrderSubmit = Session::get('last_order_submit_time', 0);
        if (time() - $lastOrderSubmit < 3) {
            $this->backWithError('Your order request is already processing. Please wait a moment.', '/checkout');
        }
        Session::set('last_order_submit_time', time());

        // Extract and validate shipping address
        $recipientName = trim($_POST['recipient_name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $addressLine1 = trim($_POST['address_line1'] ?? '');
        $addressLine2 = trim($_POST['address_line2'] ?? '');
        $city = trim($_POST['city'] ?? '');
        $state = trim($_POST['state'] ?? '');
        $postalCode = trim($_POST['postal_code'] ?? '');
        $country = trim($_POST['country'] ?? 'US');
        $guestEmail = trim($_POST['guest_email'] ?? '');
        $paymentMethod = $_POST['payment_method'] ?? 'cod';
        $customerNotes = trim($_POST['customer_notes'] ?? '');

        if (!$userId && empty($guestEmail)) {
            $this->backWithError('Email address is required for order updates.', '/checkout');
        }

        if (empty($recipientName) || empty($phone) || empty($addressLine1) || empty($city) || empty($postalCode)) {
            $this->backWithError('Please fill in all mandatory shipping address fields.', '/checkout');
        }

        $shippingAddress = [
            'recipient_name' => $recipientName,
            'phone' => $phone,
            'address_line1' => $addressLine1,
            'address_line2' => $addressLine2,
            'city' => $city,
            'state' => $state,
            'postal_code' => $postalCode,
            'country' => $country,
            'email' => $guestEmail ?: (Auth::user()['email'] ?? ''),
        ];

        // Save address for logged-in user if requested
        if ($userId && !empty($_POST['save_address'])) {
            Address::create($userId, $shippingAddress);
        }

        $appliedCoupon = Session::get('applied_coupon');
        $couponCode = $appliedCoupon ? $appliedCoupon['code'] : null;

        try {
            $orderData = Order::createOrder([
                'cart_id' => $cartId,
                'user_id' => $userId,
                'guest_email' => $guestEmail ?: null,
                'payment_method' => $paymentMethod,
                'shipping_address' => $shippingAddress,
                'billing_address' => $shippingAddress,
                'customer_notes' => $customerNotes,
                'coupon_code' => $couponCode,
            ]);

            // Clear session coupon
            Session::remove('applied_coupon');

            // Send notification
            $fullOrder = Order::findById((int)$orderData['order_id']);
            MailerService::sendOrderConfirmation($fullOrder);

            // Handle Payment Gateway
            $gateway = PaymentFactory::create($paymentMethod);
            $paymentInit = $gateway->initializePayment($orderData);

            if ($paymentMethod === 'razorpay') {
                // Render online checkout gateway bridge
                $this->render('checkout/razorpay', [
                    'pageTitle' => 'Complete Payment',
                    'payment' => $paymentInit,
                    'order' => $fullOrder,
                ]);
                return;
            }

            // Cash on delivery
            redirect("/checkout/success?order_number={$orderData['order_number']}");
        } catch (Throwable $e) {
            $this->backWithError($e->getMessage(), '/checkout');
        }
    }

    public function verifyPayment(): void
    {
        $payload = [
            'razorpay_payment_id' => $_POST['razorpay_payment_id'] ?? '',
            'razorpay_order_id' => $_POST['razorpay_order_id'] ?? '',
            'razorpay_signature' => $_POST['razorpay_signature'] ?? '',
        ];

        try {
            $gateway = PaymentFactory::create('razorpay');
            $res = $gateway->verifyPayment($payload);

            if (!$res['success']) {
                $this->backWithError($res['error'] ?? 'Payment verification failed.', '/checkout');
            }

            $order = Order::findById((int)$res['order_id']);
            redirect("/checkout/success?order_number={$order['order_number']}");
        } catch (Throwable $e) {
            $this->backWithError('Payment verification error: ' . $e->getMessage(), '/checkout');
        }
    }

    public function success(): void
    {
        $orderNumber = trim($_GET['order_number'] ?? '');
        if (empty($orderNumber)) {
            redirect('/');
        }

        $order = Order::findByOrderNumber($orderNumber);
        if (!$order) {
            redirect('/');
        }

        // Security check: If order has an owner, verify current logged in user owns it
        if (!empty($order['user_id'])) {
            $currentUserId = Auth::id();
            if ($currentUserId !== (int)$order['user_id'] && !Auth::isAdmin()) {
                Session::flash('error', 'Unauthorized access to order details.');
                redirect('/');
            }
        }

        $this->render('checkout/success', [
            'pageTitle' => 'Order Confirmed - #' . $order['order_number'],
            'order' => $order,
        ]);
    }
}
