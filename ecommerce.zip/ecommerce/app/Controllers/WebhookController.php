<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Services\Payment\PaymentFactory;

class WebhookController extends Controller
{
    public function razorpay(): void
    {
        $signature = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';
        $payload = file_get_contents('php://input') ?: '';

        try {
            $gateway = PaymentFactory::create('razorpay');
            $res = $gateway->processWebhook($payload, $signature);
            $this->json($res, $res['success'] ? 200 : 400);
        } catch (\Throwable $e) {
            $this->json(['success' => false, 'error' => $e->getMessage()], 400);
        }
    }
}
