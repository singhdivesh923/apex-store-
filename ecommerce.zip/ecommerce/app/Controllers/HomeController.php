<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Setting;

class HomeController extends Controller
{
    public function index(): void
    {
        $categories = Category::allActiveWithHierarchy();
        $featuredProducts = Product::getFeatured(8);
        $bestSellers = Product::getBestSellers(4);
        $newArrivals = Product::getNewArrivals(4);

        $this->render('home/index', [
            'pageTitle' => Setting::get('store_name', 'ApexStore') . ' | ' . Setting::get('store_tagline', 'Premium Lifestyle Essentials'),
            'categories' => $categories,
            'featuredProducts' => $featuredProducts,
            'bestSellers' => $bestSellers,
            'newArrivals' => $newArrivals,
        ]);
    }
}
