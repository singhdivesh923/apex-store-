<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Models\Setting;
use App\Services\Database;
use App\Services\MailerService;
use App\Services\Session;

class ContactController extends Controller
{
    public function show(): void
    {
        $this->render('pages/contact', [
            'pageTitle' => 'Contact Us | ' . Setting::get('store_name', 'ApexStore'),
        ]);
    }

    public function submit(): void
    {
        // Honeypot spam check
        if (!empty($_POST['website_hp'])) {
            // Silently redirect bot
            redirect('/contact');
        }

        $name = trim($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $subject = trim($_POST['subject'] ?? '');
        $message = trim($_POST['message'] ?? '');

        if (empty($name) || empty($email) || empty($message)) {
            $this->backWithError('Please fill in all required fields.', '/contact');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->backWithError('Please provide a valid email address.', '/contact');
        }

        $adminEmail = Setting::get('store_email', 'support@apexstore.com');
        $emailSubject = "Contact Form: " . ($subject ?: 'Customer Inquiry');
        $body = "<h3>Customer Message from {$name} ({$email})</h3><p>" . nl2br(e($message)) . "</p>";

        MailerService::send($adminEmail, $emailSubject, $body);

        $this->redirectWithSuccess('/contact', 'Thank you for reaching out! Our support team will respond within 24 hours.');
    }

    public function newsletter(): void
    {
        $email = strtolower(trim($_POST['email'] ?? ''));

        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
                $this->json(['success' => false, 'error' => 'Please enter a valid email address.'], 400);
            }
            $this->backWithError('Please enter a valid email address.', '/');
        }

        try {
            Database::execute(
                "INSERT INTO `newsletter_subscribers` (`email`, `subscribed_at`) VALUES (:email, NOW()) 
                 ON DUPLICATE KEY UPDATE `status` = 'subscribed'",
                [':email' => $email]
            );
        } catch (\Throwable $e) {
            // Ignore duplicate
        }

        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            $this->json(['success' => true, 'message' => 'Thank you for subscribing to our newsletter!']);
        }

        $this->redirectWithSuccess('/', 'Thank you for subscribing to our newsletter!');
    }

    public function faq(): void
    {
        $this->render('pages/faq', ['pageTitle' => 'Frequently Asked Questions']);
    }

    public function shipping(): void
    {
        $this->render('pages/shipping', ['pageTitle' => 'Shipping & Delivery Information']);
    }

    public function returns(): void
    {
        $this->render('pages/returns', ['pageTitle' => 'Returns & Refund Policy']);
    }

    public function privacy(): void
    {
        $this->render('pages/privacy', ['pageTitle' => 'Privacy Policy & Data Security']);
    }
}
