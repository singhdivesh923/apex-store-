<?php
declare(strict_types=1);

namespace App;

use Throwable;

class Router
{
    private array $routes = [];

    public function get(string $path, array|callable $handler, array $middleware = []): void
    {
        $this->addRoute('GET', $path, $handler, $middleware);
    }

    public function post(string $path, array|callable $handler, array $middleware = []): void
    {
        $this->addRoute('POST', $path, $handler, $middleware);
    }

    private function addRoute(string $method, string $path, array|callable $handler, array $middleware = []): void
    {
        // Normalize path
        $path = '/' . trim($path, '/');
        if ($path === '//') $path = '/';

        // Convert {param} to regex named group (?P<param>[^/]+)
        $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '(?P<$1>[^/]+)', $path);
        $regex = '#^' . $pattern . '$#';

        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'regex' => $regex,
            'handler' => $handler,
            'middleware' => $middleware,
        ];
    }

    public function dispatch(string $method, string $uri): void
    {
        $uriPath = parse_url($uri, PHP_URL_PATH) ?? '/';
        $uriPath = '/' . trim($uriPath, '/');
        if ($uriPath === '//') $uriPath = '/';

        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) {
                continue;
            }

            if (preg_match($route['regex'], $uriPath, $matches)) {
                // Execute route middlewares
                foreach ($route['middleware'] as $mw) {
                    if (is_callable([$mw, 'handle'])) {
                        $mw::handle();
                    }
                }

                // Extract named params
                $params = array_filter($matches, fn($k) => is_string($k), ARRAY_FILTER_USE_KEY);

                $handler = $route['handler'];
                if (is_callable($handler)) {
                    call_user_func_array($handler, $params);
                    return;
                }

                if (is_array($handler) && count($handler) === 2) {
                    [$class, $action] = $handler;
                    if (class_exists($class)) {
                        $controller = new $class();
                        if (method_exists($controller, $action)) {
                            call_user_func_array([$controller, $action], $params);
                            return;
                        }
                    }
                }
            }
        }

        // No match found -> 404
        http_response_code(404);
        $notFoundView = dirname(__DIR__) . '/app/Views/pages/404.php';
        if (file_exists($notFoundView)) {
            require $notFoundView;
        } else {
            echo "<h1>404 Not Found</h1><p>The requested page was not found.</p>";
        }
    }
}
