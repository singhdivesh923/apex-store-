<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\Database;

class User
{
    public static function findById(int $id): ?array
    {
        return Database::fetchOne(
            "SELECT `id`, `name`, `email`, `phone`, `role`, `status`, `email_verified_at`, `created_at` FROM `users` WHERE `id` = :id LIMIT 1",
            [':id' => $id]
        );
    }

    public static function findByEmail(string $email): ?array
    {
        return Database::fetchOne(
            "SELECT * FROM `users` WHERE `email` = :email LIMIT 1",
            [':email' => strtolower(trim($email))]
        );
    }

    public static function create(array $data): int
    {
        return Database::insert('users', [
            'name' => trim($data['name']),
            'email' => strtolower(trim($data['email'])),
            'password_hash' => password_hash($data['password'], PASSWORD_BCRYPT),
            'phone' => $data['phone'] ?? null,
            'role' => $data['role'] ?? 'customer',
            'status' => $data['status'] ?? 'active',
            'email_verified_at' => $data['email_verified_at'] ?? null,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public static function update(int $id, array $data): int
    {
        $allowedCols = ['name', 'phone', 'role', 'status', 'email_verified_at', 'password'];
        $fields = [];
        $params = [':id' => $id];

        foreach ($data as $col => $val) {
            if (!in_array($col, $allowedCols, true)) {
                continue;
            }

            if ($col === 'password') {
                $fields[] = "`password_hash` = :password_hash";
                $params[':password_hash'] = password_hash($val, PASSWORD_BCRYPT);
            } else {
                $fields[] = "`{$col}` = :{$col}";
                $params[":{$col}"] = $val;
            }
        }

        if (empty($fields)) {
            return 0;
        }

        $sql = "UPDATE `users` SET " . implode(', ', $fields) . ", `updated_at` = NOW() WHERE `id` = :id";
        return Database::execute($sql, $params);
    }

    public static function getCustomersPaginated(int $page = 1, int $perPage = 15, string $search = ''): array
    {
        $offset = ($page - 1) * $perPage;
        $params = [];
        $where = "WHERE `role` = 'customer'";

        if (!empty($search)) {
            $where .= " AND (`name` LIKE :search OR `email` LIKE :search OR `phone` LIKE :search)";
            $params[':search'] = "%{$search}%";
        }

        $totalSql = "SELECT COUNT(*) as `total` FROM `users` {$where}";
        $totalRow = Database::fetchOne($totalSql, $params);
        $total = (int)($totalRow['total'] ?? 0);

        $sql = "SELECT u.`id`, u.`name`, u.`email`, u.`phone`, u.`status`, u.`created_at`,
                       (SELECT COUNT(*) FROM `orders` o WHERE o.`user_id` = u.`id`) as `order_count`,
                       (SELECT COALESCE(SUM(o.`total_amount`), 0) FROM `orders` o WHERE o.`user_id` = u.`id` AND o.`status` != 'cancelled') as `total_spent`
                FROM `users` u
                {$where}
                ORDER BY u.`id` DESC
                LIMIT {$perPage} OFFSET {$offset}";

        $items = Database::fetchAll($sql, $params);

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => (int)ceil($total / $perPage),
        ];
    }
}
