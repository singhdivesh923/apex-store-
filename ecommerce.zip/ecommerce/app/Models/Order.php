<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\Database;
use RuntimeException;

class Order
{
    /**
     * Permitted state transitions for orders
     */
    public const ALLOWED_TRANSITIONS = [
        'pending' => ['confirmed', 'cancelled'],
        'confirmed' => ['processing', 'cancelled'],
        'processing' => ['shipped', 'cancelled'],
        'shipped' => ['delivered', 'cancelled'],
        'delivered' => ['refunded'],
        'cancelled' => [],
        'refunded' => [],
    ];

    public static function createOrder(array $params): array
    {
        return Database::transaction(function () use ($params) {
            $cartId = (int)$params['cart_id'];
            $userId = !empty($params['user_id']) ? (int)$params['user_id'] : null;
            $guestEmail = !empty($params['guest_email']) ? trim($params['guest_email']) : null;
            $paymentMethod = $params['payment_method'] ?? 'cod';
            $shippingAddress = $params['shipping_address'];
            $billingAddress = $params['billing_address'];
            $customerNotes = $params['customer_notes'] ?? null;
            $couponCode = $params['coupon_code'] ?? null;

            // 1. Fetch cart items with fresh lock on products
            $items = Cart::getItems($cartId);
            if (empty($items)) {
                throw new RuntimeException("Your shopping cart is empty.");
            }

            // 2. Validate stock availability and calculate strict server-side totals
            $subtotal = 0.0;
            foreach ($items as $item) {
                // Fetch product with lock
                $p = Database::fetchOne(
                    "SELECT `id`, `name`, `sku`, `price`, `discount_price`, `stock_quantity`, `status` 
                     FROM `products` WHERE `id` = :id FOR UPDATE",
                    [':id' => $item['product_id']]
                );

                if (!$p || $p['status'] !== 'active') {
                    throw new RuntimeException("Product '{$item['name']}' is no longer available.");
                }

                $qty = (int)$item['quantity'];
                $stock = (int)$p['stock_quantity'];

                if ($stock < $qty) {
                    throw new RuntimeException("Insufficient stock for '{$p['name']}'. Only {$stock} unit(s) remaining.");
                }

                $unitPrice = !empty($p['discount_price']) && (float)$p['discount_price'] > 0
                    ? (float)$p['discount_price']
                    : (float)$p['price'];

                $subtotal += ($unitPrice * $qty);
            }

            // 3. Process coupon if provided
            $coupon = null;
            $discount = 0.0;
            if (!empty($couponCode)) {
                $couponRes = Coupon::validateCoupon($couponCode, $subtotal, $userId);
                if ($couponRes['valid']) {
                    $coupon = $couponRes['coupon'];
                    $discount = (float)$couponRes['discount'];
                }
            }

            // 4. Calculate Shipping and Taxes
            $flatShipping = (float) Setting::get('flat_shipping_rate', 15.00);
            $freeShippingThreshold = (float) Setting::get('free_shipping_threshold', 150.00);
            $shipping = ($subtotal >= $freeShippingThreshold) ? 0.0 : $flatShipping;

            $taxPercent = (float) Setting::get('tax_rate_percent', 8.50);
            $taxable = max(0.0, $subtotal - $discount);
            $tax = round($taxable * ($taxPercent / 100), 2);

            $grandTotal = round(max(0.0, $taxable + $shipping + $tax), 2);

            // 5. Generate unique non-sequential public order reference
            $orderNumber = generate_order_number();

            // 6. Insert Order Record
            $orderId = Database::insert('orders', [
                'order_number' => $orderNumber,
                'user_id' => $userId,
                'guest_email' => $guestEmail,
                'status' => 'pending',
                'subtotal' => round($subtotal, 2),
                'discount_amount' => round($discount, 2),
                'coupon_id' => $coupon ? $coupon['id'] : null,
                'coupon_code' => $coupon ? $coupon['code'] : null,
                'shipping_amount' => round($shipping, 2),
                'tax_amount' => round($tax, 2),
                'total_amount' => $grandTotal,
                'payment_method' => $paymentMethod,
                'payment_status' => ($paymentMethod === 'cod') ? 'unpaid' : 'unpaid',
                'shipping_address' => json_encode($shippingAddress),
                'billing_address' => json_encode($billingAddress),
                'customer_notes' => $customerNotes,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            // 7. Insert Order Line Items & Decrement Inventory
            foreach ($items as $item) {
                $p = Product::findById((int)$item['product_id']);
                $qty = (int)$item['quantity'];
                $unitPrice = !empty($p['discount_price']) && (float)$p['discount_price'] > 0
                    ? (float)$p['discount_price']
                    : (float)$p['price'];
                $itemSubtotal = round($unitPrice * $qty, 2);

                Database::insert('order_items', [
                    'order_id' => $orderId,
                    'product_id' => $p['id'],
                    'product_name' => $p['name'],
                    'product_sku' => $p['sku'],
                    'unit_price' => $unitPrice,
                    'quantity' => $qty,
                    'subtotal' => $itemSubtotal,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);

                // Atomically decrement stock with concurrency guard against over-allocation
                $affected = Database::execute(
                    "UPDATE `products` SET `stock_quantity` = `stock_quantity` - :qty, `updated_at` = NOW() WHERE `id` = :id AND `stock_quantity` >= :qty",
                    [':qty' => $qty, ':id' => $p['id']]
                );

                if ($affected === 0) {
                    throw new RuntimeException("Insufficient stock for product '{$p['name']}'. Order cannot be completed.");
                }

                $updatedStock = (int)$p['stock_quantity'] - $qty;

                // Record inventory log
                Database::insert('inventory_logs', [
                    'product_id' => $p['id'],
                    'change_quantity' => -$qty,
                    'stock_after' => $updatedStock,
                    'reference_type' => 'order_placed',
                    'reference_id' => $orderId,
                    'note' => "Order #{$orderNumber} placed",
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

            // 8. Record coupon usage if applicable
            if ($coupon) {
                Coupon::recordUsage((int)$coupon['id'], $userId, $orderId, $discount);
            }

            // 9. Clear the customer's cart
            Cart::clearCart($cartId);

            return [
                'order_id' => $orderId,
                'order_number' => $orderNumber,
                'total_amount' => $grandTotal,
            ];
        });
    }

    public static function findById(int $id): ?array
    {
        $order = Database::fetchOne("SELECT * FROM `orders` WHERE `id` = :id LIMIT 1", [':id' => $id]);
        if ($order) {
            $order['items'] = Database::fetchAll("SELECT * FROM `order_items` WHERE `order_id` = :id", [':id' => $id]);
            $order['shipping_address'] = json_decode($order['shipping_address'] ?? '{}', true);
            $order['billing_address'] = json_decode($order['billing_address'] ?? '{}', true);
        }
        return $order;
    }

    public static function findByOrderNumber(string $orderNumber): ?array
    {
        $order = Database::fetchOne("SELECT * FROM `orders` WHERE `order_number` = :num LIMIT 1", [':num' => $orderNumber]);
        if ($order) {
            $order['items'] = Database::fetchAll("SELECT * FROM `order_items` WHERE `order_id` = :id", [':id' => $order['id']]);
            $order['shipping_address'] = json_decode($order['shipping_address'] ?? '{}', true);
            $order['billing_address'] = json_decode($order['billing_address'] ?? '{}', true);
        }
        return $order;
    }

    public static function getCustomerOrders(int $userId): array
    {
        return Database::fetchAll(
            "SELECT o.*, 
                    (SELECT COUNT(*) FROM `order_items` oi WHERE oi.`order_id` = o.`id`) as `item_count`
             FROM `orders` o
             WHERE o.`user_id` = :uid
             ORDER BY o.`id` DESC",
            [':uid' => $userId]
        );
    }

    public static function updateStatus(int $orderId, string $newStatus, ?int $adminId = null, ?string $adminNotes = null): array
    {
        return Database::transaction(function () use ($orderId, $newStatus, $adminId, $adminNotes) {
            $order = self::findById($orderId);
            if (!$order) {
                throw new RuntimeException("Order not found.");
            }

            $currentStatus = $order['status'];
            if ($currentStatus === $newStatus) {
                return ['success' => true, 'message' => 'Order status unchanged.'];
            }

            $allowed = self::ALLOWED_TRANSITIONS[$currentStatus] ?? [];
            if (!in_array($newStatus, $allowed, true)) {
                throw new RuntimeException("Invalid status transition from '{$currentStatus}' to '{$newStatus}'.");
            }

            $extraUpdates = [];
            $params = [':id' => $orderId, ':status' => $newStatus];

            if ($newStatus === 'cancelled') {
                $extraUpdates[] = "`cancelled_at` = NOW()";

                // Restore inventory for all items in order
                foreach ($order['items'] as $item) {
                    if (!empty($item['product_id'])) {
                        Database::execute(
                            "UPDATE `products` SET `stock_quantity` = `stock_quantity` + :qty, `updated_at` = NOW() WHERE `id` = :id",
                            [':qty' => $item['quantity'], ':id' => $item['product_id']]
                        );

                        $p = Product::findById((int)$item['product_id']);
                        Database::insert('inventory_logs', [
                            'product_id' => $item['product_id'],
                            'change_quantity' => (int)$item['quantity'],
                            'stock_after' => (int)($p['stock_quantity'] ?? 0),
                            'reference_type' => 'order_cancelled',
                            'reference_id' => $orderId,
                            'note' => "Order #{$order['order_number']} cancelled - inventory restored",
                            'created_at' => date('Y-m-d H:i:s'),
                        ]);
                    }
                }
            } elseif ($newStatus === 'refunded') {
                $extraUpdates[] = "`refunded_at` = NOW()";
                $extraUpdates[] = "`payment_status` = 'refunded'";
            }

            if ($adminNotes !== null) {
                $extraUpdates[] = "`admin_notes` = :admin_notes";
                $params[':admin_notes'] = $adminNotes;
            }

            $extraSql = !empty($extraUpdates) ? ', ' . implode(', ', $extraUpdates) : '';
            $sql = "UPDATE `orders` SET `status` = :status{$extraSql}, `updated_at` = NOW() WHERE `id` = :id";
            Database::execute($sql, $params);

            // Audit log
            if ($adminId) {
                Database::insert('admin_logs', [
                    'admin_id' => $adminId,
                    'action' => 'update_order_status',
                    'entity_type' => 'order',
                    'entity_id' => $orderId,
                    'details' => json_encode([
                        'from' => $currentStatus,
                        'to' => $newStatus,
                        'order_number' => $order['order_number']
                    ]),
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

            return ['success' => true, 'message' => "Order updated to '{$newStatus}'."];
        });
    }

    public static function getAdminOrdersPaginated(array $filters = [], int $page = 1, int $perPage = 15): array
    {
        $offset = ($page - 1) * $perPage;
        $where = [];
        $params = [];

        if (!empty($filters['status'])) {
            $where[] = "o.`status` = :status";
            $params[':status'] = $filters['status'];
        }

        if (!empty($filters['payment_status'])) {
            $where[] = "o.`payment_status` = :pstatus";
            $params[':pstatus'] = $filters['payment_status'];
        }

        if (!empty($filters['search'])) {
            $where[] = "(o.`order_number` LIKE :search OR u.`name` LIKE :search OR u.`email` LIKE :search OR o.`guest_email` LIKE :search)";
            $params[':search'] = '%' . trim($filters['search']) . '%';
        }

        if (!empty($filters['start_date'])) {
            $where[] = "o.`created_at` >= :sdate";
            $params[':sdate'] = $filters['start_date'] . ' 00:00:00';
        }

        if (!empty($filters['end_date'])) {
            $where[] = "o.`created_at` <= :edate";
            $params[':edate'] = $filters['end_date'] . ' 23:59:59';
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $totalSql = "SELECT COUNT(*) as `total` FROM `orders` o LEFT JOIN `users` u ON o.`user_id` = u.`id` {$whereClause}";
        $totalRow = Database::fetchOne($totalSql, $params);
        $total = (int)($totalRow['total'] ?? 0);

        $sql = "SELECT o.*, u.`name` as `customer_name`, u.`email` as `customer_email`,
                       (SELECT COUNT(*) FROM `order_items` oi WHERE oi.`order_id` = o.`id`) as `item_count`
                FROM `orders` o
                LEFT JOIN `users` u ON o.`user_id` = u.`id`
                {$whereClause}
                ORDER BY o.`id` DESC
                LIMIT {$perPage} OFFSET {$offset}";

        $items = Database::fetchAll($sql, $params);

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => (int)ceil($total / $perPage),
        ];
    }
}
