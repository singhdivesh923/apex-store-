<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\Database;

class Category
{
    public static function all(): array
    {
        return Database::fetchAll(
            "SELECT c.*, p.`name` as `parent_name`,
                    (SELECT COUNT(*) FROM `products` pr WHERE pr.`category_id` = c.`id` AND pr.`status` = 'active') as `product_count`
             FROM `categories` c
             LEFT JOIN `categories` p ON c.`parent_id` = p.`id`
             ORDER BY c.`display_order` ASC, c.`name` ASC"
        );
    }

    public static function allActiveWithHierarchy(): array
    {
        $all = Database::fetchAll(
            "SELECT c.*,
                    (SELECT COUNT(*) FROM `products` pr WHERE pr.`category_id` = c.`id` AND pr.`status` = 'active') as `product_count`
             FROM `categories` c
             WHERE c.`is_active` = 1
             ORDER BY c.`display_order` ASC, c.`name` ASC"
        );

        $tree = [];
        $indexed = [];

        foreach ($all as $item) {
            $item['children'] = [];
            $indexed[$item['id']] = $item;
        }

        foreach ($indexed as $id => &$item) {
            if ($item['parent_id'] && isset($indexed[$item['parent_id']])) {
                $indexed[$item['parent_id']]['children'][] = &$item;
            } else {
                $tree[] = &$item;
            }
        }

        return $tree;
    }

    public static function findById(int $id): ?array
    {
        return Database::fetchOne(
            "SELECT * FROM `categories` WHERE `id` = :id LIMIT 1",
            [':id' => $id]
        );
    }

    public static function findBySlug(string $slug): ?array
    {
        return Database::fetchOne(
            "SELECT * FROM `categories` WHERE `slug` = :slug AND `is_active` = 1 LIMIT 1",
            [':slug' => $slug]
        );
    }

    public static function create(array $data): int
    {
        return Database::insert('categories', [
            'parent_id' => !empty($data['parent_id']) ? (int)$data['parent_id'] : null,
            'name' => trim($data['name']),
            'slug' => slugify($data['slug'] ?? $data['name']),
            'description' => $data['description'] ?? null,
            'image_url' => $data['image_url'] ?? null,
            'is_active' => isset($data['is_active']) ? 1 : 0,
            'display_order' => (int)($data['display_order'] ?? 0),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public static function update(int $id, array $data): int
    {
        $sql = "UPDATE `categories` SET
                    `parent_id` = :parent_id,
                    `name` = :name,
                    `slug` = :slug,
                    `description` = :description,
                    `image_url` = :image_url,
                    `is_active` = :is_active,
                    `display_order` = :display_order,
                    `updated_at` = NOW()
                WHERE `id` = :id";

        return Database::execute($sql, [
            ':id' => $id,
            ':parent_id' => !empty($data['parent_id']) ? (int)$data['parent_id'] : null,
            ':name' => trim($data['name']),
            ':slug' => slugify($data['slug'] ?? $data['name']),
            ':description' => $data['description'] ?? null,
            ':image_url' => $data['image_url'] ?? null,
            ':is_active' => isset($data['is_active']) ? 1 : 0,
            ':display_order' => (int)($data['display_order'] ?? 0),
        ]);
    }

    public static function delete(int $id): bool
    {
        // Check if products exist in category
        $count = Database::fetchOne(
            "SELECT COUNT(*) as `total` FROM `products` WHERE `category_id` = :id",
            [':id' => $id]
        );

        if (($count['total'] ?? 0) > 0) {
            throw new \RuntimeException("Cannot delete category containing products. Reassign or delete the products first.");
        }

        return Database::execute("DELETE FROM `categories` WHERE `id` = :id", [':id' => $id]) > 0;
    }
}
