<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\Database;
use App\Services\Session;

class Cart
{
    public static function getOrCreateCartId(?int $userId = null): int
    {
        Session::start();
        $sessionId = session_id();

        if ($userId) {
            $cart = Database::fetchOne(
                "SELECT `id` FROM `carts` WHERE `user_id` = :uid LIMIT 1",
                [':uid' => $userId]
            );

            if ($cart) {
                return (int)$cart['id'];
            }

            // Check if there was an anonymous session cart to claim
            $sessionCart = Database::fetchOne(
                "SELECT `id` FROM `carts` WHERE `session_id` = :sid AND `user_id` IS NULL LIMIT 1",
                [':sid' => $sessionId]
            );

            if ($sessionCart) {
                Database::execute(
                    "UPDATE `carts` SET `user_id` = :uid, `updated_at` = NOW() WHERE `id` = :id",
                    [':uid' => $userId, ':id' => $sessionCart['id']]
                );
                return (int)$sessionCart['id'];
            }

            return Database::insert('carts', [
                'user_id' => $userId,
                'session_id' => $sessionId,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }

        // Guest user by session ID
        $cart = Database::fetchOne(
            "SELECT `id` FROM `carts` WHERE `session_id` = :sid AND `user_id` IS NULL LIMIT 1",
            [':sid' => $sessionId]
        );

        if ($cart) {
            return (int)$cart['id'];
        }

        return Database::insert('carts', [
            'user_id' => null,
            'session_id' => $sessionId,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public static function getItems(int $cartId): array
    {
        $items = Database::fetchAll(
            "SELECT ci.`id` as `cart_item_id`, ci.`quantity`,
                    p.`id` as `product_id`, p.`name`, p.`slug`, p.`sku`, p.`price`, p.`discount_price`,
                    p.`stock_quantity`, p.`status`,
                    (SELECT `image_path` FROM `product_images` pi WHERE pi.`product_id` = p.`id` ORDER BY pi.`is_primary` DESC LIMIT 1) as `primary_image`
             FROM `cart_items` ci
             JOIN `products` p ON ci.`product_id` = p.`id`
             WHERE ci.`cart_id` = :cart_id
             ORDER BY ci.`id` DESC",
            [':cart_id' => $cartId]
        );

        $processed = [];
        foreach ($items as $item) {
            $unitPrice = !empty($item['discount_price']) && (float)$item['discount_price'] > 0
                ? (float)$item['discount_price']
                : (float)$item['price'];

            $quantity = (int)$item['quantity'];
            $stock = (int)$item['stock_quantity'];

            // Clamp quantity to available stock if depleted
            $isAvailable = ($item['status'] === 'active' && $stock > 0);
            $effectiveQuantity = min($quantity, max(1, $stock));

            $item['unit_price'] = $unitPrice;
            $item['line_total'] = round($unitPrice * $quantity, 2);
            $item['is_available'] = $isAvailable;
            $item['is_out_of_stock'] = ($stock <= 0 || $item['status'] !== 'active');
            $item['exceeds_stock'] = ($quantity > $stock);

            $processed[] = $item;
        }

        return $processed;
    }

    public static function addItem(int $cartId, int $productId, int $quantity = 1): array
    {
        $product = Product::findById($productId);
        if (!$product || $product['status'] !== 'active') {
            return ['success' => false, 'error' => 'Product is not available for purchase.'];
        }

        $stock = (int)$product['stock_quantity'];
        if ($stock < 1) {
            return ['success' => false, 'error' => 'Product is currently out of stock.'];
        }

        $existing = Database::fetchOne(
            "SELECT `id`, `quantity` FROM `cart_items` WHERE `cart_id` = :cid AND `product_id` = :pid LIMIT 1",
            [':cid' => $cartId, ':pid' => $productId]
        );

        $targetQty = $quantity;
        if ($existing) {
            $targetQty = (int)$existing['quantity'] + $quantity;
        }

        if ($targetQty > $stock) {
            return [
                'success' => false,
                'error' => "Only {$stock} unit(s) available in stock."
            ];
        }

        if ($existing) {
            Database::execute(
                "UPDATE `cart_items` SET `quantity` = :qty, `updated_at` = NOW() WHERE `id` = :id",
                [':qty' => $targetQty, ':id' => $existing['id']]
            );
        } else {
            Database::insert('cart_items', [
                'cart_id' => $cartId,
                'product_id' => $productId,
                'quantity' => $targetQty,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }

        return ['success' => true, 'message' => 'Product added to cart.'];
    }

    public static function updateQuantity(int $cartId, int $productId, int $quantity): array
    {
        if ($quantity <= 0) {
            return self::removeItem($cartId, $productId);
        }

        $product = Product::findById($productId);
        if (!$product || $product['status'] !== 'active') {
            return ['success' => false, 'error' => 'Product is unavailable.'];
        }

        $stock = (int)$product['stock_quantity'];
        if ($quantity > $stock) {
            return ['success' => false, 'error' => "Only {$stock} unit(s) available."];
        }

        Database::execute(
            "UPDATE `cart_items` SET `quantity` = :qty, `updated_at` = NOW() WHERE `cart_id` = :cid AND `product_id` = :pid",
            [':qty' => $quantity, ':cid' => $cartId, ':pid' => $productId]
        );

        return ['success' => true, 'message' => 'Cart updated.'];
    }

    public static function removeItem(int $cartId, int $productId): array
    {
        Database::execute(
            "DELETE FROM `cart_items` WHERE `cart_id` = :cid AND `product_id` = :pid",
            [':cid' => $cartId, ':pid' => $productId]
        );

        return ['success' => true, 'message' => 'Item removed from cart.'];
    }

    public static function clearCart(int $cartId): void
    {
        Database::execute("DELETE FROM `cart_items` WHERE `cart_id` = :cid", [':cid' => $cartId]);
    }

    public static function getTotals(int $cartId, ?array $coupon = null): array
    {
        $items = self::getItems($cartId);
        $subtotal = 0.0;
        $totalItems = 0;

        foreach ($items as $item) {
            if ($item['is_available']) {
                $subtotal += $item['line_total'];
                $totalItems += (int)$item['quantity'];
            }
        }

        $discount = 0.0;
        if ($coupon && $subtotal > 0) {
            $discount = Coupon::calculateDiscount($coupon, $subtotal);
        }

        // Shipping calculation from store settings
        $flatShipping = (float) Setting::get('flat_shipping_rate', 15.00);
        $freeShippingThreshold = (float) Setting::get('free_shipping_threshold', 150.00);
        $shipping = ($subtotal >= $freeShippingThreshold || $subtotal == 0) ? 0.0 : $flatShipping;

        // Tax calculation from store settings
        $taxPercent = (float) Setting::get('tax_rate_percent', 8.50);
        $taxableAmount = max(0.0, $subtotal - $discount);
        $tax = round($taxableAmount * ($taxPercent / 100), 2);

        $grandTotal = round(max(0.0, $taxableAmount + $shipping + $tax), 2);

        return [
            'items' => $items,
            'total_items' => $totalItems,
            'subtotal' => round($subtotal, 2),
            'discount' => round($discount, 2),
            'shipping' => round($shipping, 2),
            'tax' => round($tax, 2),
            'tax_percent' => $taxPercent,
            'grand_total' => $grandTotal,
            'coupon' => $coupon,
        ];
    }
}
