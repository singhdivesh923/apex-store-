<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\Database;

class Wishlist
{
    public static function getForUser(int $userId): array
    {
        return Database::fetchAll(
            "SELECT w.`id` as `wishlist_id`, w.`created_at` as `saved_at`,
                    p.`id` as `product_id`, p.`name`, p.`slug`, p.`sku`, p.`price`, p.`discount_price`,
                    p.`stock_quantity`, p.`status`,
                    (SELECT `image_path` FROM `product_images` pi WHERE pi.`product_id` = p.`id` ORDER BY pi.`is_primary` DESC LIMIT 1) as `primary_image`
             FROM `wishlists` w
             JOIN `products` p ON w.`product_id` = p.`id`
             WHERE w.`user_id` = :uid
             ORDER BY w.`id` DESC",
            [':uid' => $userId]
        );
    }

    public static function toggle(int $userId, int $productId): array
    {
        $existing = Database::fetchOne(
            "SELECT `id` FROM `wishlists` WHERE `user_id` = :uid AND `product_id` = :pid LIMIT 1",
            [':uid' => $userId, ':pid' => $productId]
        );

        if ($existing) {
            Database::execute("DELETE FROM `wishlists` WHERE `id` = :id", [':id' => $existing['id']]);
            return ['saved' => false, 'message' => 'Removed from wishlist.'];
        }

        Database::insert('wishlists', [
            'user_id' => $userId,
            'product_id' => $productId,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return ['saved' => true, 'message' => 'Saved to wishlist.'];
    }

    public static function remove(int $userId, int $productId): bool
    {
        return Database::execute(
            "DELETE FROM `wishlists` WHERE `user_id` = :uid AND `product_id` = :pid",
            [':uid' => $userId, ':pid' => $productId]
        ) > 0;
    }

    public static function isSaved(int $userId, int $productId): bool
    {
        $row = Database::fetchOne(
            "SELECT 1 FROM `wishlists` WHERE `user_id` = :uid AND `product_id` = :pid LIMIT 1",
            [':uid' => $userId, ':pid' => $productId]
        );
        return $row !== null;
    }
}
