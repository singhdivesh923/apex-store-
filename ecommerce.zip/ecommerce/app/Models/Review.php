<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\Database;

class Review
{
    public static function getForProduct(int $productId): array
    {
        return Database::fetchAll(
            "SELECT r.*, u.`name` as `author_name`
             FROM `reviews` r
             JOIN `users` u ON r.`user_id` = u.`id`
             WHERE r.`product_id` = :pid AND r.`status` = 'approved'
             ORDER BY r.`id` DESC",
            [':pid' => $productId]
        );
    }

    public static function create(int $productId, int $userId, int $rating, string $title, string $comment): int
    {
        return Database::transaction(function () use ($productId, $userId, $rating, $title, $comment) {
            $rating = max(1, min(5, $rating));

            $reviewId = Database::insert('reviews', [
                'product_id' => $productId,
                'user_id' => $userId,
                'rating' => $rating,
                'title' => trim($title),
                'comment' => trim($comment),
                'status' => 'approved', // Auto-approved or set pending if moderation required
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            // Recalculate average product rating
            self::recalculateProductRating($productId);

            return $reviewId;
        });
    }

    public static function updateStatus(int $id, string $status): bool
    {
        $review = Database::fetchOne("SELECT `product_id` FROM `reviews` WHERE `id` = :id", [':id' => $id]);
        if (!$review) {
            return false;
        }

        $res = Database::execute(
            "UPDATE `reviews` SET `status` = :status, `updated_at` = NOW() WHERE `id` = :id",
            [':status' => $status, ':id' => $id]
        ) > 0;

        self::recalculateProductRating((int)$review['product_id']);
        return $res;
    }

    public static function recalculateProductRating(int $productId): void
    {
        $stats = Database::fetchOne(
            "SELECT COUNT(*) as `cnt`, COALESCE(AVG(`rating`), 0) as `avg_score`
             FROM `reviews`
             WHERE `product_id` = :pid AND `status` = 'approved'",
            [':pid' => $productId]
        );

        Database::execute(
            "UPDATE `products` SET `rating_avg` = :avg_score, `rating_count` = :cnt, `updated_at` = NOW() WHERE `id` = :id",
            [
                ':avg_score' => round((float)($stats['avg_score'] ?? 0), 2),
                ':cnt' => (int)($stats['cnt'] ?? 0),
                ':id' => $productId
            ]
        );
    }

    public static function allPaginated(int $page = 1, int $perPage = 15, ?string $status = null): array
    {
        $offset = ($page - 1) * $perPage;
        $where = [];
        $params = [];

        if (!empty($status)) {
            $where[] = "r.`status` = :status";
            $params[':status'] = $status;
        }

        $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

        $totalSql = "SELECT COUNT(*) as `total` FROM `reviews` r {$whereClause}";
        $totalRow = Database::fetchOne($totalSql, $params);
        $total = (int)($totalRow['total'] ?? 0);

        $sql = "SELECT r.*, p.`name` as `product_name`, p.`slug` as `product_slug`, u.`name` as `customer_name`, u.`email` as `customer_email`
                FROM `reviews` r
                JOIN `products` p ON r.`product_id` = p.`id`
                JOIN `users` u ON r.`user_id` = u.`id`
                {$whereClause}
                ORDER BY r.`id` DESC
                LIMIT {$perPage} OFFSET {$offset}";

        $items = Database::fetchAll($sql, $params);

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => (int)ceil($total / $perPage),
        ];
    }
}
