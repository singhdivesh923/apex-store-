<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\Database;

class Address
{
    public static function getByUser(int $userId): array
    {
        return Database::fetchAll(
            "SELECT * FROM `addresses` WHERE `user_id` = :uid ORDER BY `is_default` DESC, `id` DESC",
            [':uid' => $userId]
        );
    }

    public static function findById(int $id, int $userId): ?array
    {
        return Database::fetchOne(
            "SELECT * FROM `addresses` WHERE `id` = :id AND `user_id` = :uid LIMIT 1",
            [':id' => $id, ':uid' => $userId]
        );
    }

    public static function create(int $userId, array $data): int
    {
        return Database::transaction(function () use ($userId, $data) {
            $isDefault = !empty($data['is_default']) ? 1 : 0;

            if ($isDefault) {
                Database::execute(
                    "UPDATE `addresses` SET `is_default` = 0 WHERE `user_id` = :uid",
                    [':uid' => $userId]
                );
            }

            return Database::insert('addresses', [
                'user_id' => $userId,
                'type' => $data['type'] ?? 'both',
                'recipient_name' => trim($data['recipient_name']),
                'phone' => trim($data['phone']),
                'address_line1' => trim($data['address_line1']),
                'address_line2' => !empty($data['address_line2']) ? trim($data['address_line2']) : null,
                'city' => trim($data['city']),
                'state' => trim($data['state']),
                'postal_code' => trim($data['postal_code']),
                'country' => strtoupper(trim($data['country'] ?? 'US')),
                'is_default' => $isDefault,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        });
    }

    public static function update(int $id, int $userId, array $data): int
    {
        return Database::transaction(function () use ($id, $userId, $data) {
            $isDefault = !empty($data['is_default']) ? 1 : 0;

            if ($isDefault) {
                Database::execute(
                    "UPDATE `addresses` SET `is_default` = 0 WHERE `user_id` = :uid AND `id` != :id",
                    [':uid' => $userId, ':id' => $id]
                );
            }

            $sql = "UPDATE `addresses` SET
                        `type` = :type,
                        `recipient_name` = :recipient_name,
                        `phone` = :phone,
                        `address_line1` = :address_line1,
                        `address_line2` = :address_line2,
                        `city` = :city,
                        `state` = :state,
                        `postal_code` = :postal_code,
                        `country` = :country,
                        `is_default` = :is_default,
                        `updated_at` = NOW()
                    WHERE `id` = :id AND `user_id` = :uid";

            return Database::execute($sql, [
                ':id' => $id,
                ':uid' => $userId,
                ':type' => $data['type'] ?? 'both',
                ':recipient_name' => trim($data['recipient_name']),
                ':phone' => trim($data['phone']),
                ':address_line1' => trim($data['address_line1']),
                ':address_line2' => !empty($data['address_line2']) ? trim($data['address_line2']) : null,
                ':city' => trim($data['city']),
                ':state' => trim($data['state']),
                ':postal_code' => trim($data['postal_code']),
                ':country' => strtoupper(trim($data['country'] ?? 'US')),
                ':is_default' => $isDefault,
            ]);
        });
    }

    public static function delete(int $id, int $userId): bool
    {
        return Database::execute(
            "DELETE FROM `addresses` WHERE `id` = :id AND `user_id` = :uid",
            [':id' => $id, ':uid' => $userId]
        ) > 0;
    }
}
