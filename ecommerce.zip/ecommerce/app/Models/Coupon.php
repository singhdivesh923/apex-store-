<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\Database;

class Coupon
{
    public static function all(): array
    {
        return Database::fetchAll("SELECT * FROM `coupons` ORDER BY `id` DESC");
    }

    public static function findById(int $id): ?array
    {
        return Database::fetchOne("SELECT * FROM `coupons` WHERE `id` = :id LIMIT 1", [':id' => $id]);
    }

    public static function findByCode(string $code): ?array
    {
        return Database::fetchOne(
            "SELECT * FROM `coupons` WHERE UPPER(`code`) = :code LIMIT 1",
            [':code' => strtoupper(trim($code))]
        );
    }

    public static function validateCoupon(string $code, float $cartSubtotal, ?int $userId = null): array
    {
        $coupon = self::findByCode($code);
        if (!$coupon) {
            return ['valid' => false, 'error' => 'Invalid promotion code.'];
        }

        if (!$coupon['is_active']) {
            return ['valid' => false, 'error' => 'This coupon has been disabled.'];
        }

        $now = date('Y-m-d H:i:s');
        if (!empty($coupon['start_date']) && $coupon['start_date'] > $now) {
            return ['valid' => false, 'error' => 'This promotion has not started yet.'];
        }

        if (!empty($coupon['end_date']) && $coupon['end_date'] < $now) {
            return ['valid' => false, 'error' => 'This promotion code has expired.'];
        }

        if ($coupon['usage_limit'] !== null && $coupon['usage_count'] >= $coupon['usage_limit']) {
            return ['valid' => false, 'error' => 'This promotion code has reached its maximum usage limit.'];
        }

        $minAmount = (float)$coupon['min_order_amount'];
        if ($cartSubtotal < $minAmount) {
            return [
                'valid' => false,
                'error' => sprintf('This coupon requires a minimum subtotal of %s.', format_currency($minAmount))
            ];
        }

        // Per-user usage check if logged in
        if ($userId) {
            $userUsage = Database::fetchOne(
                "SELECT COUNT(*) as `cnt` FROM `coupon_usages` WHERE `coupon_id` = :cid AND `user_id` = :uid",
                [':cid' => $coupon['id'], ':uid' => $userId]
            );
            if (($userUsage['cnt'] ?? 0) >= 1) { // 1 use per customer limit
                return ['valid' => false, 'error' => 'You have already redeemed this promotion code.'];
            }
        }

        $discount = self::calculateDiscount($coupon, $cartSubtotal);

        return [
            'valid' => true,
            'coupon' => $coupon,
            'discount' => $discount,
            'message' => 'Coupon code applied successfully.'
        ];
    }

    public static function calculateDiscount(array $coupon, float $subtotal): float
    {
        $discount = 0.0;
        $val = (float)$coupon['discount_value'];

        if ($coupon['type'] === 'percentage') {
            $discount = round($subtotal * ($val / 100), 2);
            if (!empty($coupon['max_discount_amount'])) {
                $maxDisc = (float)$coupon['max_discount_amount'];
                if ($discount > $maxDisc) {
                    $discount = $maxDisc;
                }
            }
        } elseif ($coupon['type'] === 'fixed') {
            $discount = min($val, $subtotal);
        }

        return max(0.0, $discount);
    }

    public static function recordUsage(int $couponId, ?int $userId, int $orderId, float $discountApplied): void
    {
        Database::insert('coupon_usages', [
            'coupon_id' => $couponId,
            'user_id' => $userId,
            'order_id' => $orderId,
            'discount_applied' => $discountApplied,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        Database::execute(
            "UPDATE `coupons` SET `usage_count` = `usage_count` + 1, `updated_at` = NOW() WHERE `id` = :id",
            [':id' => $couponId]
        );
    }

    public static function create(array $data): int
    {
        return Database::insert('coupons', [
            'code' => strtoupper(trim($data['code'])),
            'type' => in_array($data['type'], ['percentage', 'fixed'], true) ? $data['type'] : 'percentage',
            'discount_value' => (float)$data['discount_value'],
            'min_order_amount' => (float)($data['min_order_amount'] ?? 0),
            'max_discount_amount' => !empty($data['max_discount_amount']) ? (float)$data['max_discount_amount'] : null,
            'usage_limit' => !empty($data['usage_limit']) ? (int)$data['usage_limit'] : null,
            'is_active' => isset($data['is_active']) ? 1 : 0,
            'start_date' => !empty($data['start_date']) ? $data['start_date'] : null,
            'end_date' => !empty($data['end_date']) ? $data['end_date'] : null,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public static function update(int $id, array $data): int
    {
        $sql = "UPDATE `coupons` SET
                    `code` = :code,
                    `type` = :type,
                    `discount_value` = :discount_value,
                    `min_order_amount` = :min_order_amount,
                    `max_discount_amount` = :max_discount_amount,
                    `usage_limit` = :usage_limit,
                    `is_active` = :is_active,
                    `start_date` = :start_date,
                    `end_date` = :end_date,
                    `updated_at` = NOW()
                WHERE `id` = :id";

        return Database::execute($sql, [
            ':id' => $id,
            ':code' => strtoupper(trim($data['code'])),
            ':type' => in_array($data['type'], ['percentage', 'fixed'], true) ? $data['type'] : 'percentage',
            ':discount_value' => (float)$data['discount_value'],
            ':min_order_amount' => (float)($data['min_order_amount'] ?? 0),
            ':max_discount_amount' => !empty($data['max_discount_amount']) ? (float)$data['max_discount_amount'] : null,
            ':usage_limit' => !empty($data['usage_limit']) ? (int)$data['usage_limit'] : null,
            ':is_active' => isset($data['is_active']) ? 1 : 0,
            ':start_date' => !empty($data['start_date']) ? $data['start_date'] : null,
            ':end_date' => !empty($data['end_date']) ? $data['end_date'] : null,
        ]);
    }

    public static function delete(int $id): bool
    {
        return Database::execute("DELETE FROM `coupons` WHERE `id` = :id", [':id' => $id]) > 0;
    }
}
