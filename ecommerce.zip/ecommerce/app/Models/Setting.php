<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\Database;

class Setting
{
    private static ?array $cache = null;

    public static function all(): array
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        try {
            $rows = Database::fetchAll("SELECT `setting_key`, `setting_value` FROM `settings`");
            $settings = [];
            foreach ($rows as $row) {
                $settings[$row['setting_key']] = $row['setting_value'];
            }
            self::$cache = $settings;
            return self::$cache;
        } catch (\Throwable $e) {
            return [];
        }
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $all = self::all();
        return $all[$key] ?? $default;
    }

    public static function set(string $key, string $value, string $group = 'general'): void
    {
        $sql = "INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_group`) 
                VALUES (:key, :val, :grp)
                ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`), `updated_at` = NOW()";
        Database::execute($sql, [
            ':key' => $key,
            ':val' => $value,
            ':grp' => $group
        ]);
        self::$cache = null;
    }
}
