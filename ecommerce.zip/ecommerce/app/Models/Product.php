<?php
declare(strict_types=1);

namespace App\Models;

use App\Services\Database;

class Product
{
    public static function getFeatured(int $limit = 8): array
    {
        return Database::fetchAll(
            "SELECT p.*, c.`name` as `category_name`, c.`slug` as `category_slug`,
                    (SELECT `image_path` FROM `product_images` pi WHERE pi.`product_id` = p.`id` ORDER BY pi.`is_primary` DESC, pi.`display_order` ASC LIMIT 1) as `primary_image`
             FROM `products` p
             JOIN `categories` c ON p.`category_id` = c.`id`
             WHERE p.`status` = 'active' AND p.`is_featured` = 1
             ORDER BY p.`id` DESC
             LIMIT {$limit}"
        );
    }

    public static function getBestSellers(int $limit = 8): array
    {
        return Database::fetchAll(
            "SELECT p.*, c.`name` as `category_name`, c.`slug` as `category_slug`,
                    (SELECT `image_path` FROM `product_images` pi WHERE pi.`product_id` = p.`id` ORDER BY pi.`is_primary` DESC, pi.`display_order` ASC LIMIT 1) as `primary_image`
             FROM `products` p
             JOIN `categories` c ON p.`category_id` = c.`id`
             WHERE p.`status` = 'active' AND p.`is_bestseller` = 1
             ORDER BY p.`rating_count` DESC, p.`id` DESC
             LIMIT {$limit}"
        );
    }

    public static function getNewArrivals(int $limit = 8): array
    {
        return Database::fetchAll(
            "SELECT p.*, c.`name` as `category_name`, c.`slug` as `category_slug`,
                    (SELECT `image_path` FROM `product_images` pi WHERE pi.`product_id` = p.`id` ORDER BY pi.`is_primary` DESC, pi.`display_order` ASC LIMIT 1) as `primary_image`
             FROM `products` p
             JOIN `categories` c ON p.`category_id` = c.`id`
             WHERE p.`status` = 'active' AND p.`is_new_arrival` = 1
             ORDER BY p.`created_at` DESC
             LIMIT {$limit}"
        );
    }

    public static function getPaginatedCatalog(array $filters = [], int $page = 1, int $perPage = 12): array
    {
        $offset = ($page - 1) * $perPage;
        $where = ["p.`status` = 'active'"];
        $params = [];

        // Category filter
        if (!empty($filters['category_id'])) {
            $where[] = "p.`category_id` = :category_id";
            $params[':category_id'] = (int)$filters['category_id'];
        } elseif (!empty($filters['category_slug'])) {
            $cat = Category::findBySlug($filters['category_slug']);
            if ($cat) {
                // Include child categories
                $where[] = "(p.`category_id` = :cat_id OR p.`category_id` IN (SELECT id FROM categories WHERE parent_id = :parent_id))";
                $params[':cat_id'] = $cat['id'];
                $params[':parent_id'] = $cat['id'];
            }
        }

        // Search filter (name, SKU, short_description)
        if (!empty($filters['search'])) {
            $where[] = "(p.`name` LIKE :search OR p.`sku` LIKE :search OR p.`short_description` LIKE :search)";
            $params[':search'] = '%' . trim($filters['search']) . '%';
        }

        // Price range
        if (isset($filters['min_price']) && is_numeric($filters['min_price'])) {
            $where[] = "COALESCE(p.`discount_price`, p.`price`) >= :min_price";
            $params[':min_price'] = (float)$filters['min_price'];
        }
        if (isset($filters['max_price']) && is_numeric($filters['max_price'])) {
            $where[] = "COALESCE(p.`discount_price`, p.`price`) <= :max_price";
            $params[':max_price'] = (float)$filters['max_price'];
        }

        // In Stock only
        if (!empty($filters['in_stock'])) {
            $where[] = "p.`stock_quantity` > 0";
        }

        // Sorting
        $sortOrder = "p.`id` DESC";
        $sort = $filters['sort'] ?? 'newest';
        switch ($sort) {
            case 'price_asc':
                $sortOrder = "COALESCE(p.`discount_price`, p.`price`) ASC";
                break;
            case 'price_desc':
                $sortOrder = "COALESCE(p.`discount_price`, p.`price`) DESC";
                break;
            case 'rating':
                $sortOrder = "p.`rating_avg` DESC, p.`rating_count` DESC";
                break;
            case 'popularity':
                $sortOrder = "p.`is_bestseller` DESC, p.`rating_count` DESC";
                break;
            case 'newest':
            default:
                $sortOrder = "p.`created_at` DESC";
                break;
        }

        $whereClause = implode(' AND ', $where);

        $countSql = "SELECT COUNT(*) as `total` FROM `products` p WHERE {$whereClause}";
        $countRow = Database::fetchOne($countSql, $params);
        $total = (int)($countRow['total'] ?? 0);

        $sql = "SELECT p.*, c.`name` as `category_name`, c.`slug` as `category_slug`,
                       (SELECT `image_path` FROM `product_images` pi WHERE pi.`product_id` = p.`id` ORDER BY pi.`is_primary` DESC, pi.`display_order` ASC LIMIT 1) as `primary_image`
                FROM `products` p
                JOIN `categories` c ON p.`category_id` = c.`id`
                WHERE {$whereClause}
                ORDER BY {$sortOrder}
                LIMIT {$perPage} OFFSET {$offset}";

        $items = Database::fetchAll($sql, $params);

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => (int)ceil($total / $perPage),
        ];
    }

    public static function findBySlug(string $slug): ?array
    {
        $product = Database::fetchOne(
            "SELECT p.*, c.`name` as `category_name`, c.`slug` as `category_slug`
             FROM `products` p
             JOIN `categories` c ON p.`category_id` = c.`id`
             WHERE p.`slug` = :slug LIMIT 1",
            [':slug' => $slug]
        );

        if (!$product) {
            return null;
        }

        // Fetch gallery images
        $product['images'] = Database::fetchAll(
            "SELECT * FROM `product_images` WHERE `product_id` = :id ORDER BY `is_primary` DESC, `display_order` ASC",
            [':id' => $product['id']]
        );

        // Fetch primary image fallback
        $product['primary_image'] = $product['images'][0]['image_path'] ?? null;

        return $product;
    }

    public static function findById(int $id): ?array
    {
        $product = Database::fetchOne(
            "SELECT p.*, c.`name` as `category_name`, c.`slug` as `category_slug`
             FROM `products` p
             LEFT JOIN `categories` c ON p.`category_id` = c.`id`
             WHERE p.`id` = :id LIMIT 1",
            [':id' => $id]
        );

        if ($product) {
            $product['images'] = Database::fetchAll(
                "SELECT * FROM `product_images` WHERE `product_id` = :id ORDER BY `is_primary` DESC, `display_order` ASC",
                [':id' => $id]
            );
            $product['primary_image'] = $product['images'][0]['image_path'] ?? null;
        }

        return $product;
    }

    public static function getRelated(int $categoryId, int $currentProductId, int $limit = 4): array
    {
        return Database::fetchAll(
            "SELECT p.*, c.`name` as `category_name`,
                    (SELECT `image_path` FROM `product_images` pi WHERE pi.`product_id` = p.`id` ORDER BY pi.`is_primary` DESC LIMIT 1) as `primary_image`
             FROM `products` p
             JOIN `categories` c ON p.`category_id` = c.`id`
             WHERE p.`category_id` = :category_id AND p.`id` != :current_id AND p.`status` = 'active'
             ORDER BY p.`rating_avg` DESC, p.`id` DESC
             LIMIT {$limit}",
            [':category_id' => $categoryId, ':current_id' => $currentProductId]
        );
    }

    public static function create(array $data): int
    {
        return Database::transaction(function () use ($data) {
            $productId = Database::insert('products', [
                'category_id' => (int)$data['category_id'],
                'name' => trim($data['name']),
                'slug' => slugify($data['slug'] ?? $data['name']),
                'sku' => strtoupper(trim($data['sku'])),
                'short_description' => $data['short_description'] ?? null,
                'description' => $data['description'] ?? null,
                'price' => (float)$data['price'],
                'discount_price' => !empty($data['discount_price']) ? (float)$data['discount_price'] : null,
                'stock_quantity' => (int)($data['stock_quantity'] ?? 0),
                'low_stock_threshold' => (int)($data['low_stock_threshold'] ?? 5),
                'is_featured' => !empty($data['is_featured']) ? 1 : 0,
                'is_bestseller' => !empty($data['is_bestseller']) ? 1 : 0,
                'is_new_arrival' => !empty($data['is_new_arrival']) ? 1 : 0,
                'status' => $data['status'] ?? 'active',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            // If initial stock > 0, log it
            if ((int)($data['stock_quantity'] ?? 0) > 0) {
                Database::insert('inventory_logs', [
                    'product_id' => $productId,
                    'change_quantity' => (int)$data['stock_quantity'],
                    'stock_after' => (int)$data['stock_quantity'],
                    'reference_type' => 'restock',
                    'note' => 'Initial stock on product creation',
                    'created_at' => date('Y-m-d H:i:s')
                ]);
            }

            return $productId;
        });
    }

    public static function update(int $id, array $data): int
    {
        $current = self::findById($id);
        if (!$current) {
            throw new \RuntimeException("Product with ID {$id} not found.");
        }

        $fields = [
            '`category_id` = :category_id',
            '`name` = :name',
            '`slug` = :slug',
            '`sku` = :sku',
            '`short_description` = :short_description',
            '`description` = :description',
            '`price` = :price',
            '`discount_price` = :discount_price',
            '`low_stock_threshold` = :low_stock_threshold',
            '`is_featured` = :is_featured',
            '`is_bestseller` = :is_bestseller',
            '`is_new_arrival` = :is_new_arrival',
            '`status` = :status',
            '`updated_at` = NOW()'
        ];

        $params = [
            ':id' => $id,
            ':category_id' => (int)$data['category_id'],
            ':name' => trim($data['name']),
            ':slug' => slugify($data['slug'] ?? $data['name']),
            ':sku' => strtoupper(trim($data['sku'])),
            ':short_description' => $data['short_description'] ?? null,
            ':description' => $data['description'] ?? null,
            ':price' => (float)$data['price'],
            ':discount_price' => !empty($data['discount_price']) ? (float)$data['discount_price'] : null,
            ':low_stock_threshold' => (int)($data['low_stock_threshold'] ?? 5),
            ':is_featured' => !empty($data['is_featured']) ? 1 : 0,
            ':is_bestseller' => !empty($data['is_bestseller']) ? 1 : 0,
            ':is_new_arrival' => !empty($data['is_new_arrival']) ? 1 : 0,
            ':status' => $data['status'] ?? 'active',
        ];

        // Handle stock change if provided
        if (isset($data['stock_quantity'])) {
            $newStock = (int)$data['stock_quantity'];
            $stockDiff = $newStock - (int)$current['stock_quantity'];
            $fields[] = '`stock_quantity` = :stock_quantity';
            $params[':stock_quantity'] = $newStock;

            if ($stockDiff !== 0) {
                Database::insert('inventory_logs', [
                    'product_id' => $id,
                    'change_quantity' => $stockDiff,
                    'stock_after' => $newStock,
                    'reference_type' => 'manual_adjustment',
                    'note' => 'Manual stock update via Admin',
                    'created_at' => date('Y-m-d H:i:s')
                ]);
            }
        }

        $sql = "UPDATE `products` SET " . implode(', ', $fields) . " WHERE `id` = :id";
        return Database::execute($sql, $params);
    }

    public static function delete(int $id): bool
    {
        // Check if referenced in historical orders
        $orderItem = Database::fetchOne(
            "SELECT COUNT(*) as `total` FROM `order_items` WHERE `product_id` = :id",
            [':id' => $id]
        );

        if (($orderItem['total'] ?? 0) > 0) {
            // Cannot physically delete without breaking historical records -> archive it
            Database::execute("UPDATE `products` SET `status` = 'archived', `updated_at` = NOW() WHERE `id` = :id", [':id' => $id]);
            return true;
        }

        return Database::execute("DELETE FROM `products` WHERE `id` = :id", [':id' => $id]) > 0;
    }
}
