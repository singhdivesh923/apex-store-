<?php
declare(strict_types=1);

/**
 * Global Helper Functions
 * Provides environment loading, escaping, URL resolution, and utilities.
 */

if (!function_exists('load_env')) {
    /**
     * Load environment variables from .env file if present
     */
    function load_env(string $filePath): void
    {
        if (!file_exists($filePath)) {
            return;
        }

        $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#')) {
                continue;
            }

            if (strpos($line, '=') !== false) {
                [$key, $value] = explode('=', $line, 2);
                $key = trim($key);
                $value = trim($value);

                // Strip quotes if wrapped
                if ((str_starts_with($value, '"') && str_ends_with($value, '"')) ||
                    (str_starts_with($value, "'") && str_ends_with($value, "'"))) {
                    $value = substr($value, 1, -1);
                }

                // Handle boolean / null strings
                $lower = strtolower($value);
                if ($lower === 'true') {
                    $value = true;
                } elseif ($lower === 'false') {
                    $value = false;
                } elseif ($lower === 'null') {
                    $value = null;
                }

                if (!array_key_exists($key, $_ENV)) {
                    $_ENV[$key] = $value;
                    putenv("{$key}={$value}");
                }
            }
        }
    }
}

if (!function_exists('env')) {
    /**
     * Retrieve environment variable with fallback
     */
    function env(string $key, mixed $default = null): mixed
    {
        if (array_key_exists($key, $_ENV)) {
            return $_ENV[$key];
        }

        $val = getenv($key);
        if ($val !== false) {
            $lower = strtolower($val);
            if ($lower === 'true') return true;
            if ($lower === 'false') return false;
            if ($lower === 'null') return null;
            return $val;
        }

        return $default;
    }
}

if (!function_exists('e')) {
    /**
     * Secure HTML output escaping against XSS
     */
    function e(?string $value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('clean_html')) {
    /**
     * Sanitize rich HTML content against XSS while allowing safe semantic tags
     */
    function clean_html(?string $html): string
    {
        if ($html === null || $html === '') {
            return '';
        }

        // Allow only safe semantic formatting tags
        $allowedTags = '<p><br><strong><em><b><i><u><ul><ol><li><h1><h2><h3><h4><h5><h6><blockquote><span>';
        $cleaned = strip_tags($html, $allowedTags);

        // Remove any inline event handler attributes (onload, onerror, onclick, etc.)
        $cleaned = preg_replace('/\s*on[a-zA-Z]+\s*=\s*(["\']).*?\1/is', '', $cleaned);
        $cleaned = preg_replace('/\s*on[a-zA-Z]+\s*=\s*[^>\s]+/is', '', $cleaned);

        // Remove javascript: and data: pseudo-protocols
        $cleaned = preg_replace('/javascript\s*:/i', '', $cleaned);

        return $cleaned;
    }
}

if (!function_exists('base_url')) {
    /**
     * Return base URL of application
     */
    function base_url(string $path = ''): string
    {
        static $cachedBase = null;
        if ($cachedBase === null) {
            $configured = env('APP_URL');
            if ($configured) {
                $cachedBase = rtrim($configured, '/');
            } else {
                $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] ?? 80) == 443 ? 'https://' : 'http://';
                $host = $_SERVER['HTTP_HOST'] ?? 'localhost:8000';
                $cachedBase = $protocol . $host;
            }
        }

        $trimmed = ltrim($path, '/');
        return $trimmed ? "{$cachedBase}/{$trimmed}" : $cachedBase;
    }
}

if (!function_exists('asset')) {
    /**
     * Return full URL to public asset
     */
    function asset(string $path): string
    {
        return base_url('assets/' . ltrim($path, '/'));
    }
}

if (!function_exists('format_currency')) {
    /**
     * Format money value safely
     */
    function format_currency(float|int|string|null $amount, string $symbol = '$'): string
    {
        $val = (float)($amount ?? 0);
        return $symbol . number_format($val, 2, '.', ',');
    }
}

if (!function_exists('redirect')) {
    /**
     * Redirect to URL and terminate
     */
    function redirect(string $url, int $statusCode = 302): never
    {
        if (!str_starts_with($url, 'http://') && !str_starts_with($url, 'https://')) {
            $url = base_url($url);
        }
        header("Location: {$url}", true, $statusCode);
        exit;
    }
}

if (!function_exists('json_response')) {
    /**
     * Send JSON HTTP response
     */
    function json_response(mixed $data, int $statusCode = 200): never
    {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if (!function_exists('slugify')) {
    /**
     * Generate URL-friendly slug
     */
    function slugify(string $text): string
    {
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
        $text = preg_replace('~[^-\w]+~', '', $text);
        $text = trim($text, '-');
        $text = preg_replace('~-+~', '-', $text);
        $text = strtolower($text);
        return empty($text) ? 'item' : $text;
    }
}

if (!function_exists('generate_order_number')) {
    /**
     * Generate unique, non-sequential order reference
     */
    function generate_order_number(): string
    {
        // Format: APX-YYYYMMDD-XXXXXX (high entropy hex)
        $date = date('Ymd');
        $random = strtoupper(bin2hex(random_bytes(3)));
        return "APX-{$date}-{$random}";
    }
}
