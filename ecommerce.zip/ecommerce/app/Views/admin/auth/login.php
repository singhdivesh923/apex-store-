<?php
use App\Models\Setting;
use App\Services\CSRF;
$storeName = Setting::get('store_name', 'ApexStore');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator Login | <?= e($storeName) ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="/assets/css/admin.css" rel="stylesheet">
</head>
<body class="bg-dark d-flex align-items-center min-vh-100">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5 col-lg-4">
            <div class="bg-white p-4 p-md-5 rounded-4 shadow-lg">
                <div class="text-center mb-4">
                    <i class="bi bi-shield-lock-fill fs-1 text-primary mb-2 d-block"></i>
                    <h1 class="h4 fw-bold">Admin Portal</h1>
                    <p class="text-muted small">Sign in with administrator credentials.</p>
                </div>

                <?php require dirname(__DIR__, 2) . '/layouts/alerts.php'; ?>

                <form action="<?= base_url('/admin/login') ?>" method="POST">
                    <?= CSRF::field() ?>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">Admin Email</label>
                        <input type="email" id="adminEmail" name="email" class="form-control" placeholder="admin@apexstore.com" value="<?= e($_POST['email'] ?? '') ?>" required autofocus>
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-bold">Password</label>
                        <input type="password" id="adminPassword" name="password" class="form-control" placeholder="Enter password" required>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                        Authenticate &rarr;
                    </button>
                </form>

                <?php if (env('APP_ENV') !== 'production' && env('APP_DEBUG')): ?>
                <div class="mt-4 p-3 bg-light rounded-2 border small text-muted" id="defaultCredentialsBox" style="cursor: pointer;" title="Click to fill credentials">
                    <strong>Default Admin Credentials (Development Only):</strong><br>
                    Email: <code>admin@apexstore.com</code><br>
                    Password: <code>Admin@12345</code>
                    <div class="mt-1 text-primary small"><i class="bi bi-box-arrow-in-down-left"></i> Click to fill credentials</div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php if (env('APP_ENV') !== 'production' && env('APP_DEBUG')): ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const credBox = document.getElementById('defaultCredentialsBox');
    if (credBox) {
        credBox.addEventListener('click', () => {
            const emailInput = document.getElementById('adminEmail');
            const passInput = document.getElementById('adminPassword');
            if (emailInput && passInput) {
                emailInput.value = 'admin@apexstore.com';
                passInput.value = 'Admin@12345';
                passInput.focus();
            }
        });
    }
});
</script>
<?php endif; ?>
</body>
</html>
