<?php
use App\Services\CSRF;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <p class="text-muted small m-0">Configure store branding, taxation, delivery rates, and payment gateways</p>
    </div>
</div>

<div class="admin-table-card p-4 p-md-5" style="max-width: 900px;">
    <form action="<?= base_url('/admin/settings') ?>" method="POST">
        <?= CSRF::field() ?>

        <!-- 1. Store Identity -->
        <h5 class="fw-bold mb-3 border-bottom pb-2"><i class="bi bi-shop me-2 text-primary"></i> Store Identity & Contact</h5>
        <div class="row g-3 mb-4">
            <div class="col-md-6">
                <label class="form-label small fw-bold">Store Public Name</label>
                <input type="text" name="store_name" class="form-control" value="<?= e($settings['store_name'] ?? 'ApexStore') ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label small fw-bold">Store Tagline / Slogan</label>
                <input type="text" name="store_tagline" class="form-control" value="<?= e($settings['store_tagline'] ?? '') ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label small fw-bold">Support Email Address</label>
                <input type="email" name="store_email" class="form-control" value="<?= e($settings['store_email'] ?? '') ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label small fw-bold">Support Telephone</label>
                <input type="tel" name="store_phone" class="form-control" value="<?= e($settings['store_phone'] ?? '') ?>">
            </div>
            <div class="col-12">
                <label class="form-label small fw-bold">Headquarters Street Address</label>
                <input type="text" name="store_address" class="form-control" value="<?= e($settings['store_address'] ?? '') ?>">
            </div>
        </div>

        <!-- 2. Currency, Tax & Delivery -->
        <h5 class="fw-bold mb-3 border-bottom pb-2"><i class="bi bi-currency-exchange me-2 text-primary"></i> Financial & Fulfillment Rules</h5>
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <label class="form-label small fw-bold">Currency Code</label>
                <input type="text" name="currency_code" class="form-control text-uppercase" value="<?= e($settings['currency_code'] ?? 'USD') ?>" required>
            </div>
            <div class="col-md-3">
                <label class="form-label small fw-bold">Currency Symbol</label>
                <input type="text" name="currency_symbol" class="form-control" value="<?= e($settings['currency_symbol'] ?? '$') ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label small fw-bold">Standard Sales Tax Rate (%)</label>
                <input type="number" name="tax_rate_percent" class="form-control" step="0.01" min="0" value="<?= e($settings['tax_rate_percent'] ?? '8.50') ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label small fw-bold">Standard Flat Shipping Rate ($)</label>
                <input type="number" name="flat_shipping_rate" class="form-control" step="0.01" min="0" value="<?= e($settings['flat_shipping_rate'] ?? '15.00') ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label small fw-bold">Free Shipping Threshold ($)</label>
                <input type="number" name="free_shipping_threshold" class="form-control" step="0.01" min="0" value="<?= e($settings['free_shipping_threshold'] ?? '150.00') ?>" required>
            </div>
        </div>

        <!-- 3. Payment Providers -->
        <h5 class="fw-bold mb-3 border-bottom pb-2"><i class="bi bi-credit-card me-2 text-primary"></i> Payment Gateways</h5>
        <div class="mb-4">
            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" name="enable_cod" value="1" id="switchCod" <?= !empty($settings['enable_cod']) ? 'checked' : '' ?>>
                <label class="form-check-label fw-bold" for="switchCod">Enable Cash on Delivery (COD)</label>
            </div>

            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" name="enable_razorpay" value="1" id="switchRzp" <?= !empty($settings['enable_razorpay']) ? 'checked' : '' ?>>
                <label class="form-check-label fw-bold" for="switchRzp">Enable Razorpay Payment Gateway</label>
            </div>

            <div class="p-3 bg-light rounded-3 border">
                <h6 class="fw-bold small text-muted text-uppercase mb-3">Razorpay Sandbox / Production API Credentials</h6>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Key ID</label>
                        <input type="text" name="razorpay_key_id" class="form-control form-control-sm font-monospace" placeholder="rzp_test_..." value="<?= e($settings['razorpay_key_id'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Key Secret</label>
                        <input type="password" name="razorpay_key_secret" class="form-control form-control-sm font-monospace" placeholder="Enter Secret Key" value="<?= e($settings['razorpay_key_secret'] ?? '') ?>">
                    </div>
                </div>
                <div class="form-text small text-muted mt-2">
                    <i class="bi bi-info-circle me-1"></i> When Razorpay is disabled, only COD will be offered at checkout. If credentials are missing, tests will show a configuration error rather than simulating fake payments.
                </div>
            </div>
        </div>

        <div class="border-top pt-3 d-flex justify-content-end">
            <button type="submit" class="btn btn-primary px-5 fw-bold py-2">
                Save All Settings
            </button>
        </div>
    </form>
</div>
