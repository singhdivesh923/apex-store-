<?php
use App\Services\CSRF;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <p class="text-muted small m-0">Total <?= $reviews['total'] ?> customer feedback submissions</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= base_url('/admin/reviews') ?>" class="btn btn-sm <?= empty($currentStatus) ? 'btn-primary' : 'btn-outline-secondary' ?>">All</a>
        <a href="<?= base_url('/admin/reviews?status=approved') ?>" class="btn btn-sm <?= $currentStatus === 'approved' ? 'btn-primary' : 'btn-outline-secondary' ?>">Approved</a>
        <a href="<?= base_url('/admin/reviews?status=pending') ?>" class="btn btn-sm <?= $currentStatus === 'pending' ? 'btn-primary' : 'btn-outline-secondary' ?>">Pending</a>
        <a href="<?= base_url('/admin/reviews?status=rejected') ?>" class="btn btn-sm <?= $currentStatus === 'rejected' ? 'btn-primary' : 'btn-outline-secondary' ?>">Rejected</a>
    </div>
</div>

<div class="admin-table-card">
    <div class="table-responsive">
        <table class="table admin-table align-middle m-0">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Customer</th>
                    <th>Rating</th>
                    <th>Feedback Title & Comment</th>
                    <th class="text-center">Status</th>
                    <th>Submitted</th>
                    <th class="text-end">Moderation</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($reviews['items'])): ?>
                    <tr><td colspan="7" class="text-center py-5 text-muted">No reviews match filter.</td></tr>
                <?php else: ?>
                    <?php foreach ($reviews['items'] as $rev): ?>
                        <tr>
                            <td>
                                <a href="<?= base_url('/product/' . urlencode($rev['product_slug'])) ?>" target="_blank" class="fw-semibold text-primary text-decoration-none">
                                    <?= e($rev['product_name']) ?> <i class="bi bi-box-arrow-up-right small"></i>
                                </a>
                            </td>
                            <td>
                                <div class="fw-bold"><?= e($rev['customer_name']) ?></div>
                                <div class="small text-muted"><?= e($rev['customer_email']) ?></div>
                            </td>
                            <td>
                                <div class="text-warning small text-nowrap">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <i class="bi <?= $i <= (int)$rev['rating'] ? 'bi-star-fill' : 'bi-star' ?>"></i>
                                    <?php endfor; ?>
                                </div>
                            </td>
                            <td>
                                <div class="fw-bold small text-dark"><?= e($rev['title']) ?></div>
                                <div class="small text-secondary" style="max-width: 320px;"><?= nl2br(e($rev['comment'])) ?></div>
                            </td>
                            <td class="text-center">
                                <span class="badge <?= $rev['status'] === 'approved' ? 'bg-success' : ($rev['status'] === 'rejected' ? 'bg-danger' : 'bg-warning text-dark') ?> text-uppercase">
                                    <?= e($rev['status']) ?>
                                </span>
                            </td>
                            <td class="small text-muted">
                                <?= date('M d, Y', strtotime($rev['created_at'])) ?>
                            </td>
                            <td class="text-end">
                                <div class="d-inline-flex gap-1">
                                    <?php if ($rev['status'] !== 'approved'): ?>
                                        <form action="<?= base_url('/admin/reviews/' . (int)$rev['id'] . '/status') ?>" method="POST" class="m-0">
                                            <?= CSRF::field() ?>
                                            <input type="hidden" name="status" value="approved">
                                            <button type="submit" class="btn btn-sm btn-outline-success" title="Approve Review">
                                                <i class="bi bi-check-lg"></i> Approve
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if ($rev['status'] !== 'rejected'): ?>
                                        <form action="<?= base_url('/admin/reviews/' . (int)$rev['id'] . '/status') ?>" method="POST" class="m-0">
                                            <?= CSRF::field() ?>
                                            <input type="hidden" name="status" value="rejected">
                                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Reject Review">
                                                <i class="bi bi-x-lg"></i> Reject
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
