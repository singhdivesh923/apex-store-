<?php
use App\Services\CSRF;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <p class="text-muted small m-0">Total <?= $catalog['total'] ?> products recorded in database</p>
    </div>
    <a href="<?= base_url('/admin/products/create') ?>" class="btn btn-primary btn-sm px-3">
        <i class="bi bi-plus-lg me-1"></i> Add New Product
    </a>
</div>

<!-- Filters Toolbar -->
<div class="admin-table-card p-3 mb-4">
    <form action="<?= base_url('/admin/products') ?>" method="GET" class="row g-2 align-items-center">
        <div class="col-md-5">
            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search by name or SKU..." value="<?= e($filters['search']) ?>">
        </div>
        <div class="col-md-4">
            <select name="category_id" class="form-select form-select-sm">
                <option value="">All Categories</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= (int)$cat['id'] ?>" <?= ($filters['category_id'] == $cat['id']) ? 'selected' : '' ?>>
                        <?= e($cat['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn btn-outline-primary btn-sm flex-grow-1">Filter</button>
            <a href="<?= base_url('/admin/products') ?>" class="btn btn-outline-secondary btn-sm">Reset</a>
        </div>
    </form>
</div>

<!-- Products Table -->
<div class="admin-table-card">
    <div class="table-responsive">
        <table class="table admin-table align-middle m-0">
            <thead>
                <tr>
                    <th style="width: 70px;">Image</th>
                    <th>Product & SKU</th>
                    <th>Category</th>
                    <th class="text-end">Base Price</th>
                    <th class="text-end">Discount</th>
                    <th class="text-center">Stock</th>
                    <th class="text-center">Status</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($catalog['items'])): ?>
                    <tr><td colspan="8" class="text-center py-5 text-muted">No products found matching query.</td></tr>
                <?php else: ?>
                    <?php foreach ($catalog['items'] as $product): ?>
                        <tr>
                            <td>
                                <img src="<?= e($product['primary_image'] ?: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=80&q=80') ?>" alt="<?= e($product['name']) ?>" class="rounded-2 border" style="width: 48px; height: 48px; object-fit: cover;">
                            </td>
                            <td>
                                <div class="fw-bold text-dark"><?= e($product['name']) ?></div>
                                <div class="small text-muted font-monospace"><?= e($product['sku']) ?></div>
                            </td>
                            <td><?= e($product['category_name']) ?></td>
                            <td class="text-end fw-semibold"><?= format_currency($product['price']) ?></td>
                            <td class="text-end small">
                                <?= !empty($product['discount_price']) ? '<span class="text-danger fw-semibold">' . format_currency($product['discount_price']) . '</span>' : '-' ?>
                            </td>
                            <td class="text-center">
                                <?php $qty = (int)$product['stock_quantity']; ?>
                                <span class="badge <?= $qty <= (int)$product['low_stock_threshold'] ? 'bg-danger' : 'bg-success' ?>">
                                    <?= $qty ?> in stock
                                </span>
                            </td>
                            <td class="text-center">
                                <span class="badge <?= $product['status'] === 'active' ? 'bg-success bg-opacity-10 text-success' : 'bg-secondary' ?> text-uppercase">
                                    <?= e($product['status']) ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <div class="d-inline-flex gap-1">
                                    <a href="<?= base_url('/admin/products/edit/' . (int)$product['id']) ?>" class="btn btn-sm btn-outline-secondary" title="Edit Product">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?= base_url('/admin/products/delete/' . (int)$product['id']) ?>" method="POST" class="m-0" onsubmit="return confirm('Delete or archive this product?');">
                                        <?= CSRF::field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete Product">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($catalog['total_pages'] > 1): ?>
        <div class="p-3 border-top d-flex justify-content-center">
            <ul class="pagination pagination-sm m-0">
                <?php for ($p = 1; $p <= $catalog['total_pages']; $p++): ?>
                    <li class="page-item <?= $p === $catalog['page'] ? 'active' : '' ?>">
                        <a class="page-link" href="<?= base_url('/admin/products?page=' . $p . '&' . http_build_query($filters)) ?>"><?= $p ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
