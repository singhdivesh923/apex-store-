<?php
use App\Services\CSRF;

$isEdit = !empty($product);
$actionUrl = $isEdit ? base_url('/admin/products/edit/' . (int)$product['id']) : base_url('/admin/products/create');
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <a href="<?= base_url('/admin/products') ?>" class="small text-secondary text-decoration-none">&larr; Back to Products</a>
        <h2 class="h4 fw-bold m-0"><?= $isEdit ? 'Edit Product Details' : 'Create New Product' ?></h2>
    </div>
</div>

<div class="admin-table-card p-4 p-md-5">
    <form action="<?= $actionUrl ?>" method="POST" enctype="multipart/form-data">
        <?= CSRF::field() ?>

        <div class="row g-4">
            <!-- Left: Core Metadata -->
            <div class="col-lg-8">
                <div class="mb-3">
                    <label class="form-label small fw-bold">Product Title</label>
                    <input type="text" name="name" class="form-control" value="<?= e($product['name'] ?? '') ?>" placeholder="e.g. Apex Pro ANC Wireless Headphones" required autofocus>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">SKU (Stock Keeping Unit)</label>
                        <input type="text" name="sku" class="form-control text-uppercase font-monospace" value="<?= e($product['sku'] ?? '') ?>" placeholder="e.g. APX-AUD-001" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Category</label>
                        <select name="category_id" class="form-select" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= (int)$cat['id'] ?>" <?= (($product['category_id'] ?? 0) == $cat['id']) ? 'selected' : '' ?>>
                                    <?= e($cat['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Regular Price ($)</label>
                        <input type="number" name="price" class="form-control" step="0.01" min="0.01" value="<?= e($product['price'] ?? '') ?>" placeholder="299.00" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Discounted Price ($) (Optional)</label>
                        <input type="number" name="discount_price" class="form-control" step="0.01" min="0" value="<?= e($product['discount_price'] ?? '') ?>" placeholder="249.00">
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold">Short Synopsis / Excerpt</label>
                    <textarea name="short_description" rows="2" class="form-control" placeholder="1-2 sentences summarizing key benefits"><?= e($product['short_description'] ?? '') ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold">Full Extended Description (HTML allowed)</label>
                    <textarea name="description" rows="8" class="form-control" placeholder="<p>Full specs, box contents, driver dimensions...</p>"><?= e($product['description'] ?? '') ?></textarea>
                </div>
            </div>

            <!-- Right: Stock, Image, & Flags -->
            <div class="col-lg-4">
                <div class="p-3 bg-light rounded-3 border mb-4">
                    <h6 class="fw-bold mb-3 text-uppercase small text-muted">Inventory Configuration</h6>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">Current Stock Quantity</label>
                        <input type="number" name="stock_quantity" class="form-control" value="<?= (int)($product['stock_quantity'] ?? 10) ?>" min="0" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">Low Stock Warning Threshold</label>
                        <input type="number" name="low_stock_threshold" class="form-control" value="<?= (int)($product['low_stock_threshold'] ?? 5) ?>" min="1" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">Listing Status</label>
                        <select name="status" class="form-select">
                            <option value="active" <?= (($product['status'] ?? 'active') === 'active') ? 'selected' : '' ?>>Active - Visible in Store</option>
                            <option value="inactive" <?= (($product['status'] ?? '') === 'inactive') ? 'selected' : '' ?>>Inactive - Hidden</option>
                            <option value="archived" <?= (($product['status'] ?? '') === 'archived') ? 'selected' : '' ?>>Archived - Discontinued</option>
                        </select>
                    </div>
                </div>

                <!-- Primary Image Upload -->
                <div class="p-3 bg-light rounded-3 border mb-4">
                    <h6 class="fw-bold mb-2 text-uppercase small text-muted">Product Media</h6>
                    <?php if ($isEdit && !empty($product['primary_image'])): ?>
                        <div class="mb-3 text-center">
                            <img src="<?= e($product['primary_image']) ?>" alt="Preview" class="rounded-2 border img-fluid" style="max-height: 150px;">
                            <div class="small text-muted mt-1">Current Active Image</div>
                        </div>
                    <?php endif; ?>

                    <label class="form-label small fw-bold"><?= $isEdit ? 'Replace Primary Image' : 'Upload Primary Image' ?></label>
                    <input type="file" name="image" class="form-control form-control-sm" accept="image/jpeg,image/png,image/webp">
                    <div class="form-text small">Accepted formats: JPG, PNG, WebP (Max 5MB).</div>
                </div>

                <!-- Showcase Flags -->
                <div class="p-3 bg-light rounded-3 border">
                    <h6 class="fw-bold mb-3 text-uppercase small text-muted">Storefront Placement</h6>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="is_featured" value="1" id="chkFeatured" <?= !empty($product['is_featured']) ? 'checked' : '' ?>>
                        <label class="form-check-label small fw-semibold" for="chkFeatured">Feature on Homepage</label>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="is_bestseller" value="1" id="chkBestseller" <?= !empty($product['is_bestseller']) ? 'checked' : '' ?>>
                        <label class="form-check-label small fw-semibold" for="chkBestseller">Best Seller Badge</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="is_new_arrival" value="1" id="chkNew" <?= !empty($product['is_new_arrival']) ? 'checked' : '' ?>>
                        <label class="form-check-label small fw-semibold" for="chkNew">New Arrival Badge</label>
                    </div>
                </div>
            </div>
        </div>

        <div class="border-top pt-4 mt-4 d-flex justify-content-end gap-2">
            <a href="<?= base_url('/admin/products') ?>" class="btn btn-outline-secondary px-4">Cancel</a>
            <button type="submit" class="btn btn-primary px-5 fw-bold">
                <?= $isEdit ? 'Save Product Changes' : 'Publish Product' ?>
            </button>
        </div>
    </form>
</div>
