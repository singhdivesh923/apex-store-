<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
    <div>
        <p class="text-muted small m-0">Review net sales volume, tax deductions, and export safe CSV spreadsheets</p>
    </div>
    <div>
        <a href="<?= base_url('/admin/reports/export-csv?start_date=' . urlencode($startDate) . '&end_date=' . urlencode($endDate)) ?>" class="btn btn-outline-success btn-sm">
            <i class="bi bi-file-earmark-spreadsheet me-1"></i> Export Orders to CSV
        </a>
    </div>
</div>

<!-- Date Range Picker -->
<div class="admin-table-card p-3 mb-4">
    <form action="<?= base_url('/admin/reports') ?>" method="GET" class="row g-2 align-items-center">
        <div class="col-md-4">
            <label class="form-label small fw-bold text-muted m-0">Start Date</label>
            <input type="date" name="start_date" class="form-control form-control-sm" value="<?= e($startDate) ?>">
        </div>
        <div class="col-md-4">
            <label class="form-label small fw-bold text-muted m-0">End Date</label>
            <input type="date" name="end_date" class="form-control form-control-sm" value="<?= e($endDate) ?>">
        </div>
        <div class="col-md-4 d-flex align-items-end gap-2 mt-md-4">
            <button type="submit" class="btn btn-primary btn-sm flex-grow-1">Update Report Period</button>
        </div>
    </form>
</div>

<!-- Period KPI Overview -->
<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="metric-card">
            <span class="metric-label">Completed Orders</span>
            <div class="metric-value"><?= (int)($sales['order_count'] ?? 0) ?></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card">
            <span class="metric-label">Gross Revenue</span>
            <div class="metric-value"><?= format_currency($sales['gross_sales'] ?? 0) ?></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card">
            <span class="metric-label">Total Discounts</span>
            <div class="metric-value text-danger">-<?= format_currency($sales['total_discounts'] ?? 0) ?></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="metric-card">
            <span class="metric-label">Sales Tax Collected</span>
            <div class="metric-value text-info"><?= format_currency($sales['total_tax'] ?? 0) ?></div>
        </div>
    </div>
</div>

<!-- Daily Sales Breakdown Table -->
<div class="admin-table-card mb-4">
    <div class="p-3 border-bottom">
        <h5 class="fw-bold m-0"><i class="bi bi-calendar-event me-2 text-primary"></i> Daily Sales Volume in Selected Period</h5>
    </div>
    <div class="table-responsive">
        <table class="table admin-table align-middle m-0">
            <thead>
                <tr>
                    <th>Date</th>
                    <th class="text-center">Paid Orders Count</th>
                    <th class="text-end">Total Daily Realized Sales</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($daily)): ?>
                    <tr><td colspan="3" class="text-center py-4 text-muted">No paid sales records in this date range.</td></tr>
                <?php else: ?>
                    <?php foreach ($daily as $day): ?>
                        <tr>
                            <td class="fw-bold text-dark"><?= date('F d, Y (l)', strtotime($day['sale_date'])) ?></td>
                            <td class="text-center">
                                <span class="badge bg-light text-dark border"><?= (int)$day['orders'] ?> orders</span>
                            </td>
                            <td class="text-end fw-bold text-success"><?= format_currency($day['revenue']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Low Stock Report Table -->
<div class="admin-table-card">
    <div class="p-3 border-bottom">
        <h5 class="fw-bold m-0"><i class="bi bi-exclamation-octagon text-danger me-2"></i> Low Inventory Threshold Report</h5>
    </div>
    <div class="table-responsive">
        <table class="table admin-table align-middle m-0">
            <thead>
                <tr>
                    <th>Product Title</th>
                    <th class="text-center">SKU</th>
                    <th class="text-end">Base Price</th>
                    <th class="text-center">Remaining Stock</th>
                    <th class="text-center">Low Threshold</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($lowStock)): ?>
                    <tr><td colspan="6" class="text-center py-4 text-success"><i class="bi bi-check2-all me-1"></i> No items currently below low stock threshold.</td></tr>
                <?php else: ?>
                    <?php foreach ($lowStock as $low): ?>
                        <tr>
                            <td class="fw-bold text-dark"><?= e($low['name']) ?></td>
                            <td class="text-center font-monospace small text-muted"><?= e($low['sku']) ?></td>
                            <td class="text-end"><?= format_currency($low['price']) ?></td>
                            <td class="text-center">
                                <span class="badge bg-danger fs-6"><?= (int)$low['stock_quantity'] ?></span>
                            </td>
                            <td class="text-center small text-muted"><?= (int)$low['low_stock_threshold'] ?></td>
                            <td class="text-end">
                                <a href="<?= base_url('/admin/products/edit/' . (int)$low['id']) ?>" class="btn btn-sm btn-outline-primary">Restock</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
