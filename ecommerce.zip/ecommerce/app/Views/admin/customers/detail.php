<?php
use App\Services\CSRF;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <a href="<?= base_url('/admin/customers') ?>" class="small text-secondary text-decoration-none">&larr; Back to Customers</a>
        <h2 class="h4 fw-bold m-0"><?= e($customer['name']) ?></h2>
    </div>
    <div>
        <form action="<?= base_url('/admin/customers/' . (int)$customer['id'] . '/toggle-status') ?>" method="POST" class="m-0" onsubmit="return confirm('Change customer account status?');">
            <?= CSRF::field() ?>
            <?php if ($customer['status'] === 'active'): ?>
                <button type="submit" class="btn btn-outline-danger btn-sm">
                    <i class="bi bi-slash-circle me-1"></i> Suspend Account
                </button>
            <?php else: ?>
                <button type="submit" class="btn btn-outline-success btn-sm">
                    <i class="bi bi-check-circle me-1"></i> Reactivate Account
                </button>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="admin-table-card p-4">
            <h6 class="fw-bold small text-uppercase text-muted mb-3"><i class="bi bi-person me-1"></i> Customer Profile</h6>
            <div class="mb-2">
                <span class="small text-muted d-block">Account Status</span>
                <span class="badge <?= $customer['status'] === 'active' ? 'bg-success' : 'bg-danger' ?> text-uppercase">
                    <?= e($customer['status']) ?>
                </span>
            </div>
            <div class="mb-2">
                <span class="small text-muted d-block">Email</span>
                <span class="fw-semibold"><?= e($customer['email']) ?></span>
            </div>
            <div class="mb-2">
                <span class="small text-muted d-block">Phone Number</span>
                <span><?= e($customer['phone'] ?? 'Not provided') ?></span>
            </div>
            <div>
                <span class="small text-muted d-block">Member Since</span>
                <span><?= date('F d, Y', strtotime($customer['created_at'])) ?></span>
            </div>
        </div>
    </div>

    <!-- Address Book -->
    <div class="col-md-8">
        <div class="admin-table-card p-4">
            <h6 class="fw-bold small text-uppercase text-muted mb-3"><i class="bi bi-geo-alt me-1"></i> Saved Addresses (<?= count($addresses) ?>)</h6>
            <?php if (empty($addresses)): ?>
                <p class="text-muted small m-0">No addresses saved on file.</p>
            <?php else: ?>
                <div class="row g-3">
                    <?php foreach ($addresses as $addr): ?>
                        <div class="col-sm-6">
                            <div class="p-3 bg-light rounded-2 border small">
                                <div class="fw-bold"><?= e($addr['recipient_name']) ?></div>
                                <div class="text-muted"><?= e($addr['phone']) ?></div>
                                <div><?= e($addr['address_line1']) ?></div>
                                <div><?= e($addr['city']) ?>, <?= e($addr['state']) ?> <?= e($addr['postal_code']) ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Customer Orders History -->
<div class="admin-table-card">
    <div class="p-3 border-bottom">
        <h5 class="fw-bold m-0"><i class="bi bi-receipt me-2 text-primary"></i> Customer Order History (<?= count($orders) ?>)</h5>
    </div>
    <div class="table-responsive">
        <table class="table admin-table align-middle m-0">
            <thead>
                <tr>
                    <th>Order #</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Payment</th>
                    <th class="text-end">Amount</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                    <tr><td colspan="6" class="text-center py-4 text-muted">No historical orders.</td></tr>
                <?php else: ?>
                    <?php foreach ($orders as $ord): ?>
                        <tr>
                            <td>
                                <a href="<?= base_url('/admin/orders/' . (int)$ord['id']) ?>" class="fw-bold font-monospace text-primary text-decoration-none">
                                    <?= e($ord['order_number']) ?>
                                </a>
                            </td>
                            <td class="small text-muted"><?= date('M d, Y', strtotime($ord['created_at'])) ?></td>
                            <td>
                                <span class="badge badge-status badge-status-<?= e($ord['status']) ?>">
                                    <?= ucfirst(e($ord['status'])) ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-status badge-status-<?= e($ord['payment_status']) ?>">
                                    <?= ucfirst(e($ord['payment_status'])) ?>
                                </span>
                            </td>
                            <td class="text-end fw-bold"><?= format_currency($ord['total_amount']) ?></td>
                            <td class="text-end">
                                <a href="<?= base_url('/admin/orders/' . (int)$ord['id']) ?>" class="btn btn-sm btn-outline-primary py-1 px-2">
                                    View
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
