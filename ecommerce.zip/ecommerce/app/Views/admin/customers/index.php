<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <p class="text-muted small m-0">Total <?= $customers['total'] ?> registered customer accounts</p>
    </div>
</div>

<!-- Search Bar -->
<div class="admin-table-card p-3 mb-4">
    <form action="<?= base_url('/admin/customers') ?>" method="GET" class="row g-2 align-items-center">
        <div class="col-md-8">
            <input type="text" name="search" class="form-control form-control-sm" placeholder="Search customer by name, email, or telephone..." value="<?= e($search) ?>">
        </div>
        <div class="col-md-4 d-flex gap-2">
            <button type="submit" class="btn btn-outline-primary btn-sm flex-grow-1">Search</button>
            <a href="<?= base_url('/admin/customers') ?>" class="btn btn-outline-secondary btn-sm">Reset</a>
        </div>
    </form>
</div>

<!-- Customers Table -->
<div class="admin-table-card">
    <div class="table-responsive">
        <table class="table admin-table align-middle m-0">
            <thead>
                <tr>
                    <th>Customer Name</th>
                    <th>Email Address</th>
                    <th>Phone</th>
                    <th class="text-center">Total Orders</th>
                    <th class="text-end">Total Spent</th>
                    <th class="text-center">Status</th>
                    <th>Registered</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($customers['items'])): ?>
                    <tr><td colspan="8" class="text-center py-5 text-muted">No customer accounts found matching search.</td></tr>
                <?php else: ?>
                    <?php foreach ($customers['items'] as $cust): ?>
                        <tr>
                            <td class="fw-bold text-dark"><?= e($cust['name']) ?></td>
                            <td><?= e($cust['email']) ?></td>
                            <td class="small text-muted"><?= e($cust['phone'] ?? '-') ?></td>
                            <td class="text-center">
                                <span class="badge bg-light text-dark border">
                                    <?= (int)$cust['order_count'] ?> orders
                                </span>
                            </td>
                            <td class="text-end fw-bold text-dark">
                                <?= format_currency($cust['total_spent']) ?>
                            </td>
                            <td class="text-center">
                                <span class="badge <?= $cust['status'] === 'active' ? 'bg-success bg-opacity-10 text-success' : 'bg-danger bg-opacity-10 text-danger' ?> text-uppercase">
                                    <?= e($cust['status']) ?>
                                </span>
                            </td>
                            <td class="small text-muted">
                                <?= date('M d, Y', strtotime($cust['created_at'])) ?>
                            </td>
                            <td class="text-end">
                                <a href="<?= base_url('/admin/customers/' . (int)$cust['id']) ?>" class="btn btn-sm btn-outline-primary px-3">
                                    Profile &rarr;
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($customers['total_pages'] > 1): ?>
        <div class="p-3 border-top d-flex justify-content-center">
            <ul class="pagination pagination-sm m-0">
                <?php for ($p = 1; $p <= $customers['total_pages']; $p++): ?>
                    <li class="page-item <?= $p === $customers['page'] ? 'active' : '' ?>">
                        <a class="page-link" href="<?= base_url('/admin/customers?page=' . $p . '&search=' . urlencode($search)) ?>"><?= $p ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
