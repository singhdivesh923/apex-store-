<?php
use App\Services\CSRF;

$isEdit = !empty($coupon);
$actionUrl = $isEdit ? base_url('/admin/coupons/edit/' . (int)$coupon['id']) : base_url('/admin/coupons/create');
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <a href="<?= base_url('/admin/coupons') ?>" class="small text-secondary text-decoration-none">&larr; Back to Coupons</a>
        <h2 class="h4 fw-bold m-0"><?= $isEdit ? 'Edit Coupon Code' : 'Create New Promotion Coupon' ?></h2>
    </div>
</div>

<div class="admin-table-card p-4 p-md-5" style="max-width: 800px;">
    <form action="<?= $actionUrl ?>" method="POST">
        <?= CSRF::field() ?>

        <div class="row g-3 mb-3">
            <div class="col-md-6">
                <label class="form-label small fw-bold">Coupon Code (Uppercase)</label>
                <input type="text" name="code" class="form-control text-uppercase font-monospace" placeholder="e.g. FLASH20" value="<?= e($coupon['code'] ?? '') ?>" required autofocus>
            </div>
            <div class="col-md-6">
                <label class="form-label small fw-bold">Discount Type</label>
                <select name="type" id="couponType" class="form-select" required>
                    <option value="percentage" <?= (($coupon['type'] ?? 'percentage') === 'percentage') ? 'selected' : '' ?>>Percentage Discount (%)</option>
                    <option value="fixed" <?= (($coupon['type'] ?? '') === 'fixed') ? 'selected' : '' ?>>Fixed Dollar Amount ($)</option>
                </select>
            </div>
        </div>

        <div class="row g-3 mb-3">
            <div class="col-md-4">
                <label class="form-label small fw-bold">Discount Value (<span id="discountUnitLabel">%</span>)</label>
                <input type="number" name="discount_value" id="discountValue" class="form-control" step="0.01" min="0.01" value="<?= e($coupon['discount_value'] ?? '') ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label small fw-bold">Minimum Cart Subtotal ($)</label>
                <input type="number" name="min_order_amount" class="form-control" step="0.01" min="0" value="<?= e($coupon['min_order_amount'] ?? '0') ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label small fw-bold">Max Discount Cap ($) (Optional)</label>
                <input type="number" name="max_discount_amount" class="form-control" step="0.01" min="0" value="<?= e($coupon['max_discount_amount'] ?? '') ?>" placeholder="e.g. 50.00">
            </div>
        </div>

        <div class="row g-3 mb-3">
            <div class="col-md-4">
                <label class="form-label small fw-bold">Total Max Usage Limit</label>
                <input type="number" name="usage_limit" class="form-control" min="1" value="<?= e($coupon['usage_limit'] ?? '') ?>" placeholder="Unlimited if blank">
            </div>
            <div class="col-md-4">
                <label class="form-label small fw-bold">Start Date & Time (Optional)</label>
                <input type="datetime-local" name="start_date" class="form-control form-control-sm" value="<?= !empty($coupon['start_date']) ? date('Y-m-d\TH:i', strtotime($coupon['start_date'])) : '' ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label small fw-bold">Expiry Date & Time (Optional)</label>
                <input type="datetime-local" name="end_date" class="form-control form-control-sm" value="<?= !empty($coupon['end_date']) ? date('Y-m-d\TH:i', strtotime($coupon['end_date'])) : '' ?>">
            </div>
        </div>

        <div class="mb-4">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="is_active" value="1" id="couponActiveCheck" <?= (!isset($coupon) || !empty($coupon['is_active'])) ? 'checked' : '' ?>>
                <label class="form-check-label small fw-semibold" for="couponActiveCheck">Coupon is Active and Valid for Customer Redemption</label>
            </div>
        </div>

        <div class="border-top pt-3 d-flex justify-content-end gap-2">
            <a href="<?= base_url('/admin/coupons') ?>" class="btn btn-outline-secondary px-4">Cancel</a>
            <button type="submit" class="btn btn-primary px-5 fw-bold">
                <?= $isEdit ? 'Update Coupon' : 'Create Coupon' ?>
            </button>
        </div>
    </form>
</div>
