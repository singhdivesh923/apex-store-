<?php
use App\Services\CSRF;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <p class="text-muted small m-0">Create promotional codes with percentage or fixed discounts and minimum cart constraints</p>
    </div>
    <a href="<?= base_url('/admin/coupons/create') ?>" class="btn btn-primary btn-sm px-3">
        <i class="bi bi-plus-lg me-1"></i> Create Coupon
    </a>
</div>

<div class="admin-table-card">
    <div class="table-responsive">
        <table class="table admin-table align-middle m-0">
            <thead>
                <tr>
                    <th>Coupon Code</th>
                    <th>Discount Type & Value</th>
                    <th>Min. Cart Subtotal</th>
                    <th>Max Discount Cap</th>
                    <th class="text-center">Redemption Usage</th>
                    <th>Validity Period</th>
                    <th class="text-center">Status</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($coupons)): ?>
                    <tr><td colspan="8" class="text-center py-4 text-muted">No coupons configured.</td></tr>
                <?php else: ?>
                    <?php foreach ($coupons as $coup): ?>
                        <tr>
                            <td>
                                <strong class="font-monospace text-primary bg-light px-2 py-1 rounded border"><?= e($coup['code']) ?></strong>
                            </td>
                            <td>
                                <?php if ($coup['type'] === 'percentage'): ?>
                                    <span class="fw-bold"><?= (float)$coup['discount_value'] ?>% Off</span>
                                <?php else: ?>
                                    <span class="fw-bold"><?= format_currency($coup['discount_value']) ?> Flat Off</span>
                                <?php endif; ?>
                            </td>
                            <td><?= format_currency($coup['min_order_amount']) ?></td>
                            <td class="text-muted small">
                                <?= !empty($coup['max_discount_amount']) ? format_currency($coup['max_discount_amount']) : 'No Cap' ?>
                            </td>
                            <td class="text-center">
                                <span class="badge bg-light text-dark border">
                                    <?= (int)$coup['usage_count'] ?> / <?= $coup['usage_limit'] !== null ? (int)$coup['usage_limit'] : '&infin;' ?>
                                </span>
                            </td>
                            <td class="small text-muted">
                                <?php if (!empty($coup['end_date'])): ?>
                                    Expires: <?= date('M d, Y', strtotime($coup['end_date'])) ?>
                                <?php else: ?>
                                    No Expiry
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <span class="badge <?= $coup['is_active'] ? 'bg-success bg-opacity-10 text-success' : 'bg-secondary' ?>">
                                    <?= $coup['is_active'] ? 'Active' : 'Disabled' ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <div class="d-inline-flex gap-1">
                                    <a href="<?= base_url('/admin/coupons/edit/' . (int)$coup['id']) ?>" class="btn btn-sm btn-outline-secondary" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?= base_url('/admin/coupons/delete/' . (int)$coup['id']) ?>" method="POST" class="m-0" onsubmit="return confirm('Delete this coupon code?');">
                                        <?= CSRF::field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
