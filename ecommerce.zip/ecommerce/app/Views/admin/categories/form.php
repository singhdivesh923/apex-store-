<?php
use App\Services\CSRF;

$isEdit = !empty($category);
$actionUrl = $isEdit ? base_url('/admin/categories/edit/' . (int)$category['id']) : base_url('/admin/categories/create');
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <a href="<?= base_url('/admin/categories') ?>" class="small text-secondary text-decoration-none">&larr; Back to Categories</a>
        <h2 class="h4 fw-bold m-0"><?= $isEdit ? 'Edit Category' : 'Create New Category' ?></h2>
    </div>
</div>

<div class="admin-table-card p-4 p-md-5" style="max-width: 750px;">
    <form action="<?= $actionUrl ?>" method="POST" enctype="multipart/form-data">
        <?= CSRF::field() ?>

        <div class="mb-3">
            <label class="form-label small fw-bold">Category Name</label>
            <input type="text" name="name" class="form-control" value="<?= e($category['name'] ?? '') ?>" placeholder="e.g. Audio & Acoustics" required autofocus>
        </div>

        <div class="mb-3">
            <label class="form-label small fw-bold">Parent Category (Optional)</label>
            <select name="parent_id" class="form-select">
                <option value="">None (Top-Level Category)</option>
                <?php foreach ($categories as $cat): ?>
                    <?php if ($isEdit && $cat['id'] == $category['id']) continue; ?>
                    <option value="<?= (int)$cat['id'] ?>" <?= (($category['parent_id'] ?? 0) == $cat['id']) ? 'selected' : '' ?>>
                        <?= e($cat['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label small fw-bold">Description (Optional)</label>
            <textarea name="description" rows="3" class="form-control" placeholder="Short description of items in this category"><?= e($category['description'] ?? '') ?></textarea>
        </div>

        <div class="row g-3 mb-3">
            <div class="col-md-8">
                <label class="form-label small fw-bold">Category Image (Upload or Web URL)</label>
                <input type="file" name="image" class="form-control form-control-sm mb-2" accept="image/jpeg,image/png,image/webp">
                <input type="url" name="image_url" class="form-control form-control-sm" placeholder="https://..." value="<?= e($category['image_url'] ?? '') ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label small fw-bold">Display Order</label>
                <input type="number" name="display_order" class="form-control form-control-sm" value="<?= (int)($category['display_order'] ?? 0) ?>" min="0">
            </div>
        </div>

        <div class="mb-4">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="is_active" value="1" id="activeCatCheck" <?= (!isset($category) || !empty($category['is_active'])) ? 'checked' : '' ?>>
                <label class="form-check-label small fw-semibold" for="activeCatCheck">Category is Active and Publicly Visible</label>
            </div>
        </div>

        <div class="border-top pt-3 d-flex justify-content-end gap-2">
            <a href="<?= base_url('/admin/categories') ?>" class="btn btn-outline-secondary px-4">Cancel</a>
            <button type="submit" class="btn btn-primary px-5 fw-bold">
                <?= $isEdit ? 'Update Category' : 'Save Category' ?>
            </button>
        </div>
    </form>
</div>
