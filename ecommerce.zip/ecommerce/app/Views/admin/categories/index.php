<?php
use App\Services\CSRF;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <p class="text-muted small m-0">Organize merchandise hierarchy and navigation menus</p>
    </div>
    <a href="<?= base_url('/admin/categories/create') ?>" class="btn btn-primary btn-sm px-3">
        <i class="bi bi-plus-lg me-1"></i> Add Category
    </a>
</div>

<div class="admin-table-card">
    <div class="table-responsive">
        <table class="table admin-table align-middle m-0">
            <thead>
                <tr>
                    <th style="width: 60px;">Image</th>
                    <th>Category Name</th>
                    <th>Parent Category</th>
                    <th>Slug</th>
                    <th class="text-center">Products</th>
                    <th class="text-center">Order</th>
                    <th class="text-center">Status</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($categories)): ?>
                    <tr><td colspan="8" class="text-center py-4 text-muted">No categories created yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($categories as $cat): ?>
                        <tr>
                            <td>
                                <?php if (!empty($cat['image_url'])): ?>
                                    <img src="<?= e($cat['image_url']) ?>" alt="Category" class="rounded-circle border" style="width: 40px; height: 40px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="rounded-circle bg-light border d-flex align-items-center justify-content-center text-muted" style="width: 40px; height: 40px;">
                                        <i class="bi bi-folder"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="fw-bold text-dark"><?= e($cat['name']) ?></td>
                            <td>
                                <?= !empty($cat['parent_name']) ? '<span class="badge bg-secondary">' . e($cat['parent_name']) . '</span>' : '<span class="text-muted small">None (Top-Level)</span>' ?>
                            </td>
                            <td class="font-monospace small text-muted"><?= e($cat['slug']) ?></td>
                            <td class="text-center">
                                <span class="badge bg-light text-dark border">
                                    <?= (int)($cat['product_count'] ?? 0) ?> items
                                </span>
                            </td>
                            <td class="text-center small"><?= (int)$cat['display_order'] ?></td>
                            <td class="text-center">
                                <span class="badge <?= $cat['is_active'] ? 'bg-success bg-opacity-10 text-success' : 'bg-secondary' ?>">
                                    <?= $cat['is_active'] ? 'Active' : 'Disabled' ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <div class="d-inline-flex gap-1">
                                    <a href="<?= base_url('/admin/categories/edit/' . (int)$cat['id']) ?>" class="btn btn-sm btn-outline-secondary" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?= base_url('/admin/categories/delete/' . (int)$cat['id']) ?>" method="POST" class="m-0" onsubmit="return confirm('Delete this category? Ensure it contains 0 products.');">
                                        <?= CSRF::field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
