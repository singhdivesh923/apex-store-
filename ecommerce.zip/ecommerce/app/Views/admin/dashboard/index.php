<div class="row g-4 mb-4">
    <!-- Metric 1: Net Realized Sales -->
    <div class="col-sm-6 col-xl-3">
        <div class="metric-card">
            <div class="d-flex justify-content-between align-items-center">
                <span class="metric-label">Net Realized Sales</span>
                <div class="p-2 bg-success bg-opacity-10 text-success rounded-3"><i class="bi bi-currency-dollar fs-4"></i></div>
            </div>
            <div class="metric-value"><?= format_currency($totalSales) ?></div>
            <span class="small text-muted">Excludes unpaid, cancelled, & refunds</span>
        </div>
    </div>

    <!-- Metric 2: Total Orders -->
    <div class="col-sm-6 col-xl-3">
        <div class="metric-card">
            <div class="d-flex justify-content-between align-items-center">
                <span class="metric-label">Total Orders</span>
                <div class="p-2 bg-primary bg-opacity-10 text-primary rounded-3"><i class="bi bi-box-seam fs-4"></i></div>
            </div>
            <div class="metric-value"><?= number_format($totalOrders) ?></div>
            <span class="small text-muted"><strong class="text-warning"><?= $pendingOrders ?></strong> pending fulfillment</span>
        </div>
    </div>

    <!-- Metric 3: Active Customers -->
    <div class="col-sm-6 col-xl-3">
        <div class="metric-card">
            <div class="d-flex justify-content-between align-items-center">
                <span class="metric-label">Registered Customers</span>
                <div class="p-2 bg-info bg-opacity-10 text-info rounded-3"><i class="bi bi-people fs-4"></i></div>
            </div>
            <div class="metric-value"><?= number_format($totalCustomers) ?></div>
            <span class="small text-muted">Active verified customer profiles</span>
        </div>
    </div>

    <!-- Metric 4: Active Products -->
    <div class="col-sm-6 col-xl-3">
        <div class="metric-card">
            <div class="d-flex justify-content-between align-items-center">
                <span class="metric-label">Catalog Products</span>
                <div class="p-2 bg-warning bg-opacity-10 text-warning rounded-3"><i class="bi bi-tags fs-4"></i></div>
            </div>
            <div class="metric-value"><?= number_format($totalProducts) ?></div>
            <span class="small text-muted"><strong class="<?= count($lowStockProducts) > 0 ? 'text-danger' : 'text-success' ?>"><?= count($lowStockProducts) ?></strong> low stock warnings</span>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Recent Orders Table -->
    <div class="col-xl-8">
        <div class="admin-table-card">
            <div class="p-3 border-bottom d-flex justify-content-between align-items-center">
                <h5 class="fw-bold m-0"><i class="bi bi-receipt me-2 text-primary"></i> Recent Customer Orders</h5>
                <a href="<?= base_url('/admin/orders') ?>" class="small text-primary fw-semibold">View All Orders &rarr;</a>
            </div>
            <div class="table-responsive">
                <table class="table admin-table align-middle m-0">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Customer</th>
                            <th>Status</th>
                            <th>Payment</th>
                            <th class="text-end">Amount</th>
                            <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recentOrders)): ?>
                            <tr><td colspan="6" class="text-center py-4 text-muted">No orders found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($recentOrders as $order): ?>
                                <tr>
                                    <td>
                                        <a href="<?= base_url('/admin/orders/' . (int)$order['id']) ?>" class="fw-bold font-monospace text-primary text-decoration-none">
                                            <?= e($order['order_number']) ?>
                                        </a>
                                        <div class="small text-muted"><?= date('M d, H:i', strtotime($order['created_at'])) ?></div>
                                    </td>
                                    <td>
                                        <div class="fw-semibold"><?= e($order['customer_name'] ?? 'Guest Customer') ?></div>
                                        <div class="small text-muted"><?= e($order['customer_email'] ?? $order['guest_email'] ?? '') ?></div>
                                    </td>
                                    <td>
                                        <span class="badge badge-status badge-status-<?= e($order['status']) ?>">
                                            <?= ucfirst(e($order['status'])) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-status badge-status-<?= e($order['payment_status']) ?>">
                                            <?= ucfirst(e($order['payment_status'])) ?>
                                        </span>
                                    </td>
                                    <td class="text-end fw-bold">
                                        <?= format_currency($order['total_amount']) ?>
                                    </td>
                                    <td class="text-end">
                                        <a href="<?= base_url('/admin/orders/' . (int)$order['id']) ?>" class="btn btn-sm btn-outline-primary py-1 px-2">
                                            Inspect
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Low Stock Inventory Alerts -->
    <div class="col-xl-4">
        <div class="admin-table-card mb-4">
            <div class="p-3 border-bottom d-flex justify-content-between align-items-center">
                <h5 class="fw-bold m-0"><i class="bi bi-exclamation-triangle-fill text-warning me-2"></i> Low Stock Alerts</h5>
                <a href="<?= base_url('/admin/products') ?>" class="small text-primary fw-semibold">Products</a>
            </div>
            <div class="p-3">
                <?php if (empty($lowStockProducts)): ?>
                    <p class="text-muted small text-center m-0 py-3"><i class="bi bi-check2-circle text-success me-1"></i> All active products meet healthy inventory thresholds.</p>
                <?php else: ?>
                    <div class="d-flex flex-column gap-2">
                        <?php foreach ($lowStockProducts as $low): ?>
                            <div class="d-flex justify-content-between align-items-center p-2 rounded-2 bg-light border">
                                <div class="text-truncate me-2">
                                    <div class="fw-semibold small text-truncate"><?= e($low['name']) ?></div>
                                    <div class="small text-muted font-monospace"><?= e($low['sku']) ?></div>
                                </div>
                                <div class="text-end">
                                    <span class="badge bg-danger"><?= (int)$low['stock_quantity'] ?> left</span>
                                    <div class="small text-muted" style="font-size: 0.75rem;">Min: <?= (int)$low['low_stock_threshold'] ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Audit Log -->
        <div class="admin-table-card">
            <div class="p-3 border-bottom">
                <h5 class="fw-bold m-0"><i class="bi bi-clock-history me-2 text-primary"></i> Administrative Activity Log</h5>
            </div>
            <div class="p-3">
                <?php if (empty($recentLogs)): ?>
                    <p class="text-muted small text-center m-0 py-2">No activity recorded yet.</p>
                <?php else: ?>
                    <div class="d-flex flex-column gap-2 small">
                        <?php foreach ($recentLogs as $log): ?>
                            <div class="border-bottom pb-2">
                                <div class="d-flex justify-content-between text-muted" style="font-size: 0.75rem;">
                                    <span><?= e($log['admin_name']) ?> (<?= e($log['ip_address']) ?>)</span>
                                    <span><?= date('M d, H:i', strtotime($log['created_at'])) ?></span>
                                </div>
                                <div class="fw-semibold text-dark"><?= e($log['action']) ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
