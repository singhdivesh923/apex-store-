<?php
use App\Services\CSRF;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <a href="<?= base_url('/admin/orders') ?>" class="small text-secondary text-decoration-none">&larr; Back to Order Index</a>
        <h2 class="h4 fw-bold font-monospace text-primary m-0">#<?= e($order['order_number']) ?></h2>
    </div>
    <div class="d-flex gap-2 align-items-center">
        <span class="badge badge-status badge-status-<?= e($order['status']) ?> fs-6 py-2 px-3">
            <?= ucfirst(e($order['status'])) ?>
        </span>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Order Line Items & Summary -->
    <div class="col-lg-8">
        <div class="admin-table-card mb-4">
            <div class="p-3 border-bottom">
                <h5 class="fw-bold m-0"><i class="bi bi-box me-2 text-primary"></i> Order Line Items</h5>
            </div>
            <div class="table-responsive">
                <table class="table admin-table align-middle m-0">
                    <thead>
                        <tr>
                            <th>Item Name</th>
                            <th class="text-center">SKU</th>
                            <th class="text-center">Unit Price Snapshot</th>
                            <th class="text-center">Qty</th>
                            <th class="text-end">Line Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($order['items'] as $item): ?>
                            <tr>
                                <td class="fw-semibold text-dark"><?= e($item['product_name']) ?></td>
                                <td class="text-center font-monospace small text-muted"><?= e($item['product_sku']) ?></td>
                                <td class="text-center small"><?= format_currency($item['unit_price']) ?></td>
                                <td class="text-center small"><?= (int)$item['quantity'] ?></td>
                                <td class="text-end fw-bold"><?= format_currency($item['subtotal']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="p-4 border-top bg-light">
                <div class="row justify-content-end">
                    <div class="col-md-6">
                        <div class="d-flex justify-content-between mb-1 small text-muted">
                            <span>Subtotal:</span>
                            <span class="fw-semibold text-dark"><?= format_currency($order['subtotal']) ?></span>
                        </div>
                        <?php if ($order['discount_amount'] > 0): ?>
                            <div class="d-flex justify-content-between mb-1 small text-success">
                                <span>Coupon (<?= e($order['coupon_code'] ?? '') ?>):</span>
                                <span>-<?= format_currency($order['discount_amount']) ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="d-flex justify-content-between mb-1 small text-muted">
                            <span>Shipping Amount:</span>
                            <span class="fw-semibold text-dark"><?= format_currency($order['shipping_amount']) ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2 small text-muted">
                            <span>Tax Amount:</span>
                            <span class="fw-semibold text-dark"><?= format_currency($order['tax_amount']) ?></span>
                        </div>
                        <div class="d-flex justify-content-between border-top pt-2">
                            <span class="h5 fw-bold m-0">Grand Total:</span>
                            <span class="h5 fw-bold text-primary m-0"><?= format_currency($order['total_amount']) ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Customer & Order Notes -->
        <?php if (!empty($order['customer_notes'])): ?>
            <div class="admin-table-card p-3 mb-4">
                <h6 class="fw-bold small text-uppercase text-muted mb-2"><i class="bi bi-chat-quote me-1"></i> Customer Order Instructions</h6>
                <p class="m-0 text-secondary"><?= nl2br(e($order['customer_notes'])) ?></p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Right Column: Status Transitions & Customer Destination -->
    <div class="col-lg-4">
        <!-- Status Transition Controller Card -->
        <div class="admin-table-card p-4 mb-4">
            <h5 class="fw-bold mb-3 border-bottom pb-2">State Transition Control</h5>
            <form action="<?= base_url('/admin/orders/' . (int)$order['id'] . '/status') ?>" method="POST">
                <?= CSRF::field() ?>

                <div class="mb-3">
                    <label class="form-label small fw-bold">Update Fulfillment Status</label>
                    <select name="status" class="form-select" <?= empty($allowedTransitions) ? 'disabled' : '' ?>>
                        <option value="<?= e($order['status']) ?>" selected>Current: <?= ucfirst(e($order['status'])) ?></option>
                        <?php foreach ($allowedTransitions as $trans): ?>
                            <option value="<?= $trans ?>">Advance to &rarr; <?= ucfirst($trans) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (empty($allowedTransitions)): ?>
                        <div class="form-text small text-muted">This order has reached a terminal state (<?= e($order['status']) ?>).</div>
                    <?php else: ?>
                        <div class="form-text small text-muted">Cancelling an order automatically restores reserved inventory.</div>
                    <?php endif; ?>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold">Internal Admin Notes</label>
                    <textarea name="admin_notes" rows="3" class="form-control" placeholder="Optional internal notes or tracking number"><?= e($order['admin_notes'] ?? '') ?></textarea>
                </div>

                <?php if (!empty($allowedTransitions)): ?>
                    <button type="submit" class="btn btn-primary w-100 fw-bold py-2" data-confirm="Are you sure you wish to apply this status transition?">
                        Update Order State
                    </button>
                <?php endif; ?>
            </form>
        </div>

        <!-- Shipping Destination -->
        <div class="admin-table-card p-4 mb-4">
            <h6 class="fw-bold small text-uppercase text-muted mb-3"><i class="bi bi-truck me-1"></i> Shipping Address</h6>
            <div class="fw-bold text-dark"><?= e($order['shipping_address']['recipient_name'] ?? '') ?></div>
            <div class="small text-muted mb-1"><?= e($order['shipping_address']['phone'] ?? '') ?></div>
            <div class="small text-secondary mb-1">
                <?= e($order['shipping_address']['address_line1'] ?? '') ?><br>
                <?php if (!empty($order['shipping_address']['address_line2'])): ?>
                    <?= e($order['shipping_address']['address_line2']) ?><br>
                <?php endif; ?>
                <?= e($order['shipping_address']['city'] ?? '') ?>, <?= e($order['shipping_address']['state'] ?? '') ?> <?= e($order['shipping_address']['postal_code'] ?? '') ?><br>
                <?= e($order['shipping_address']['country'] ?? '') ?>
            </div>
        </div>

        <!-- Payment Gateway Metadata -->
        <div class="admin-table-card p-4">
            <h6 class="fw-bold small text-uppercase text-muted mb-3"><i class="bi bi-credit-card me-1"></i> Payment Verification</h6>
            <div class="d-flex justify-content-between mb-2 small">
                <span class="text-muted">Method:</span>
                <span class="fw-bold text-uppercase"><?= e($order['payment_method']) ?></span>
            </div>
            <div class="d-flex justify-content-between mb-2 small">
                <span class="text-muted">Payment Status:</span>
                <span class="badge badge-status badge-status-<?= e($order['payment_status']) ?>">
                    <?= ucfirst(e($order['payment_status'])) ?>
                </span>
            </div>
            <div class="d-flex justify-content-between small">
                <span class="text-muted">Order Placed:</span>
                <span><?= date('M d, Y H:i:s', strtotime($order['created_at'])) ?></span>
            </div>
        </div>
    </div>
</div>
