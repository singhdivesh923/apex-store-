<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <p class="text-muted small m-0">Total <?= $orders['total'] ?> customer orders tracked</p>
    </div>
</div>

<!-- Filters Bar -->
<div class="admin-table-card p-3 mb-4">
    <form action="<?= base_url('/admin/orders') ?>" method="GET" class="row g-2 align-items-center">
        <div class="col-md-3">
            <input type="text" name="search" class="form-control form-control-sm" placeholder="Order #, name, or email..." value="<?= e($filters['search']) ?>">
        </div>
        <div class="col-md-2">
            <select name="status" class="form-select form-select-sm">
                <option value="">All Fulfillment Statuses</option>
                <?php foreach (['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'] as $st): ?>
                    <option value="<?= $st ?>" <?= $filters['status'] === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2">
            <select name="payment_status" class="form-select form-select-sm">
                <option value="">All Payment Statuses</option>
                <?php foreach (['unpaid', 'authorized', 'paid', 'refunded', 'failed'] as $pst): ?>
                    <option value="<?= $pst ?>" <?= $filters['payment_status'] === $pst ? 'selected' : '' ?>><?= ucfirst($pst) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2">
            <input type="date" name="start_date" class="form-control form-control-sm" value="<?= e($filters['start_date']) ?>" title="Start Date">
        </div>
        <div class="col-md-2">
            <input type="date" name="end_date" class="form-control form-control-sm" value="<?= e($filters['end_date']) ?>" title="End Date">
        </div>
        <div class="col-md-1 d-flex gap-1">
            <button type="submit" class="btn btn-outline-primary btn-sm flex-grow-1" title="Filter"><i class="bi bi-funnel"></i></button>
            <a href="<?= base_url('/admin/orders') ?>" class="btn btn-outline-secondary btn-sm" title="Reset"><i class="bi bi-arrow-counterclockwise"></i></a>
        </div>
    </form>
</div>

<!-- Orders Table -->
<div class="admin-table-card">
    <div class="table-responsive">
        <table class="table admin-table align-middle m-0">
            <thead>
                <tr>
                    <th>Order Reference</th>
                    <th>Customer Contact</th>
                    <th>Date Placed</th>
                    <th>Status</th>
                    <th>Payment</th>
                    <th class="text-end">Total Amount</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders['items'])): ?>
                    <tr><td colspan="7" class="text-center py-5 text-muted">No orders match filter query.</td></tr>
                <?php else: ?>
                    <?php foreach ($orders['items'] as $ord): ?>
                        <tr>
                            <td>
                                <a href="<?= base_url('/admin/orders/' . (int)$ord['id']) ?>" class="fw-bold font-monospace text-primary text-decoration-none">
                                    <?= e($ord['order_number']) ?>
                                </a>
                                <div class="small text-muted"><?= (int)$ord['item_count'] ?> item(s)</div>
                            </td>
                            <td>
                                <div class="fw-semibold text-dark"><?= e($ord['customer_name'] ?? 'Guest Customer') ?></div>
                                <div class="small text-muted"><?= e($ord['customer_email'] ?? $ord['guest_email'] ?? '') ?></div>
                            </td>
                            <td class="small text-muted">
                                <?= date('M d, Y h:i A', strtotime($ord['created_at'])) ?>
                            </td>
                            <td>
                                <span class="badge badge-status badge-status-<?= e($ord['status']) ?>">
                                    <?= ucfirst(e($ord['status'])) ?>
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-status badge-status-<?= e($ord['payment_status']) ?>">
                                    <?= ucfirst(e($ord['payment_status'])) ?>
                                </span>
                                <div class="small text-muted text-uppercase" style="font-size: 0.7rem;"><?= e($ord['payment_method']) ?></div>
                            </td>
                            <td class="text-end fw-bold">
                                <?= format_currency($ord['total_amount']) ?>
                            </td>
                            <td class="text-end">
                                <a href="<?= base_url('/admin/orders/' . (int)$ord['id']) ?>" class="btn btn-sm btn-outline-primary px-3">
                                    Manage &rarr;
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($orders['total_pages'] > 1): ?>
        <div class="p-3 border-top d-flex justify-content-center">
            <ul class="pagination pagination-sm m-0">
                <?php for ($p = 1; $p <= $orders['total_pages']; $p++): ?>
                    <li class="page-item <?= $p === $orders['page'] ? 'active' : '' ?>">
                        <a class="page-link" href="<?= base_url('/admin/orders?page=' . $p . '&' . http_build_query($filters)) ?>"><?= $p ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
