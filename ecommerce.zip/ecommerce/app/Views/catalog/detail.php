<?php
use App\Models\Setting;
use App\Services\CSRF;

$primaryImg = $product['primary_image'] ?: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1000&q=80';
$stock = (int)$product['stock_quantity'];
$isOutOfStock = ($stock <= 0 || $product['status'] !== 'active');
$isLowStock = (!$isOutOfStock && $stock <= (int)$product['low_stock_threshold']);
?>

<div class="container py-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb small">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('/catalog') ?>">Catalog</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('/catalog?category=' . urlencode($product['category_slug'])) ?>"><?= e($product['category_name']) ?></a></li>
            <li class="breadcrumb-item active text-truncate" style="max-width: 250px;"><?= e($product['name']) ?></li>
        </ol>
    </nav>

    <div class="row g-5 mb-5">
        <!-- Gallery Images -->
        <div class="col-lg-6">
            <div class="bg-white p-3 rounded-3 border mb-3 text-center">
                <img id="mainProductImage" src="<?= e($primaryImg) ?>" alt="<?= e($product['name']) ?>" class="img-fluid rounded-2" style="max-height: 480px; width: 100%; object-fit: contain;">
            </div>

            <?php if (!empty($product['images']) && count($product['images']) > 1): ?>
                <div class="d-flex gap-2 overflow-auto pb-2">
                    <?php foreach ($product['images'] as $img): ?>
                        <img src="<?= e($img['image_path']) ?>" alt="Thumbnail" class="img-thumbnail rounded-2 product-thumb-nav" style="width: 75px; height: 75px; object-fit: cover; cursor: pointer;" onclick="document.getElementById('mainProductImage').src = this.src;">
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Product Actions & Summary -->
        <div class="col-lg-6">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="badge bg-secondary text-uppercase fw-semibold"><?= e($product['category_name']) ?></span>
                <span class="text-muted small">SKU: <strong class="text-dark"><?= e($product['sku']) ?></strong></span>
            </div>

            <h1 class="h2 fw-bold mb-3"><?= e($product['name']) ?></h1>

            <!-- Ratings -->
            <div class="d-flex align-items-center mb-3">
                <div class="rating-stars me-2 fs-6">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <i class="bi <?= $i <= round((float)$product['rating_avg']) ? 'bi-star-fill' : 'bi-star' ?>"></i>
                    <?php endfor; ?>
                </div>
                <span class="fw-semibold text-dark me-2"><?= number_format((float)$product['rating_avg'], 1) ?></span>
                <span class="text-muted small">(<?= (int)$product['rating_count'] ?> customer reviews)</span>
            </div>

            <!-- Price -->
            <div class="d-flex align-items-baseline gap-3 mb-4 p-3 bg-light rounded-3 border">
                <span class="h2 fw-bold text-dark m-0">
                    <?= format_currency($product['discount_price'] ?: $product['price']) ?>
                </span>
                <?php if (!empty($product['discount_price'])): ?>
                    <span class="h5 text-muted text-decoration-line-through m-0">
                        <?= format_currency($product['price']) ?>
                    </span>
                    <span class="badge bg-danger">
                        Save <?= format_currency((float)$product['price'] - (float)$product['discount_price']) ?>
                    </span>
                <?php endif; ?>
            </div>

            <!-- Short Description -->
            <?php if (!empty($product['short_description'])): ?>
                <p class="text-secondary mb-4"><?= e($product['short_description']) ?></p>
            <?php endif; ?>

            <!-- Stock Status -->
            <div class="mb-4">
                <?php if ($isOutOfStock): ?>
                    <span class="badge bg-danger p-2 fs-6"><i class="bi bi-x-circle me-1"></i> Currently Out of Stock</span>
                <?php elseif ($isLowStock): ?>
                    <span class="badge bg-warning text-dark p-2 fs-6"><i class="bi bi-exclamation-triangle me-1"></i> Low Stock Alert: Only <?= $stock ?> units remaining!</span>
                <?php else: ?>
                    <span class="badge bg-success p-2 fs-6"><i class="bi bi-check2-circle me-1"></i> In Stock (<?= $stock ?> units available)</span>
                <?php endif; ?>
            </div>

            <!-- Add to Cart Form -->
            <?php if (!$isOutOfStock): ?>
                <form action="<?= base_url('/cart/add') ?>" method="POST" class="form-add-to-cart mb-4">
                    <?= CSRF::field() ?>
                    <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">

                    <div class="row g-2 align-items-center mb-3">
                        <div class="col-4 col-sm-3">
                            <label for="productQty" class="form-label small fw-bold text-uppercase text-muted">Quantity</label>
                            <input type="number" id="productQty" name="quantity" class="form-control" value="1" min="1" max="<?= $stock ?>" required>
                        </div>
                        <div class="col-8 col-sm-9 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary-custom w-100 py-2 d-flex align-items-center justify-content-center gap-2">
                                <i class="bi bi-bag-plus fs-5"></i> Add to Shopping Cart
                            </button>
                        </div>
                    </div>
                </form>
            <?php endif; ?>

            <!-- Wishlist Button -->
            <div class="d-flex gap-3">
                <button type="button" class="btn btn-outline-custom btn-wishlist-toggle flex-grow-1" data-product-id="<?= (int)$product['id'] ?>">
                    <i class="bi bi-heart me-1"></i> Save to Wishlist
                </button>
            </div>

            <!-- Feature Bullet Trust -->
            <div class="border-top pt-4 mt-4">
                <div class="row g-3 small text-muted">
                    <div class="col-6"><i class="bi bi-check2 text-primary me-1"></i> In Stock & Ready to Dispatch</div>
                    <div class="col-6"><i class="bi bi-shield-check text-primary me-1"></i> 2-Year Limited Manufacturer Warranty</div>
                    <div class="col-6"><i class="bi bi-truck text-primary me-1"></i> Tracked Priority Courier Shipping</div>
                    <div class="col-6"><i class="bi bi-arrow-return-left text-primary me-1"></i> 30-Day Hassle-Free Return Guarantee</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Full Product Description Tab -->
    <div class="bg-white p-4 p-md-5 rounded-3 border mb-5">
        <h3 class="h4 fw-bold mb-4">Detailed Specifications & Design Overview</h3>
        <div class="product-description-content text-secondary lh-lg">
            <?= clean_html($product['description']) ?: '<p>No extended specifications published for this product.</p>' ?>
        </div>
    </div>

    <!-- Customer Reviews Section -->
    <div class="bg-white p-4 p-md-5 rounded-3 border mb-5">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
            <div>
                <h3 class="h4 fw-bold mb-1">Customer Reviews</h3>
                <p class="text-muted small m-0">Verified feedback submitted by our customers</p>
            </div>
            <?php if ($isLoggedIn): ?>
                <button class="btn btn-outline-custom btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#writeReviewCollapse">
                    <i class="bi bi-pencil-square me-1"></i> Write a Review
                </button>
            <?php else: ?>
                <a href="<?= base_url('/login') ?>" class="btn btn-outline-custom btn-sm">
                    Sign in to write a review
                </a>
            <?php endif; ?>
        </div>

        <!-- Submit Review Collapse Form -->
        <?php if ($isLoggedIn): ?>
            <div class="collapse mb-4" id="writeReviewCollapse">
                <div class="card card-body bg-light border p-4">
                    <h5 class="fw-bold mb-3">Submit Your Review</h5>
                    <form action="<?= base_url('/product/review') ?>" method="POST">
                        <?= CSRF::field() ?>
                        <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">

                        <div class="row g-3 mb-3">
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Star Rating</label>
                                <select name="rating" class="form-select form-select-sm" required>
                                    <option value="5" selected>5 Stars - Exceptional</option>
                                    <option value="4">4 Stars - Very Good</option>
                                    <option value="3">3 Stars - Average</option>
                                    <option value="2">2 Stars - Below Expectation</option>
                                    <option value="1">1 Star - Disappointing</option>
                                </select>
                            </div>
                            <div class="col-md-8">
                                <label class="form-label small fw-bold">Headline / Title</label>
                                <input type="text" name="title" class="form-control form-control-sm" placeholder="e.g. Unrivaled noise cancellation and comfort" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold">Your Detailed Review</label>
                            <textarea name="comment" rows="3" class="form-control" placeholder="Share your experience with this product..." required></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary-custom btn-sm px-4">Submit Review</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        <!-- Reviews List -->
        <?php if (empty($reviews)): ?>
            <div class="text-center py-4 text-muted">
                <i class="bi bi-chat-square-quote fs-2 d-block mb-2"></i>
                <p>No customer reviews have been published for this product yet. Be the first to review it!</p>
            </div>
        <?php else: ?>
            <div class="d-flex flex-column gap-3">
                <?php foreach ($reviews as $rev): ?>
                    <div class="border-bottom pb-3">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="fw-bold text-dark"><?= e($rev['title']) ?></span>
                            <span class="text-muted small"><?= date('M d, Y', strtotime($rev['created_at'])) ?></span>
                        </div>
                        <div class="rating-stars mb-2">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="bi <?= $i <= (int)$rev['rating'] ? 'bi-star-fill' : 'bi-star' ?>"></i>
                            <?php endfor; ?>
                        </div>
                        <p class="text-secondary small mb-1"><?= nl2br(e($rev['comment'])) ?></p>
                        <span class="text-muted small"><i class="bi bi-person-check text-success me-1"></i> <?= e($rev['author_name']) ?> (Verified Purchaser)</span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Related Products -->
    <?php if (!empty($relatedProducts)): ?>
        <section>
            <h3 class="h4 fw-bold mb-4">Related Products You May Like</h3>
            <div class="row g-3 g-md-4">
                <?php foreach ($relatedProducts as $rel): ?>
                    <div class="col-6 col-md-3">
                        <div class="product-card">
                            <div class="product-image-wrap">
                                <a href="<?= base_url('/product/' . urlencode($rel['slug'])) ?>">
                                    <img src="<?= e($rel['primary_image'] ?: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80') ?>" alt="<?= e($rel['name']) ?>" loading="lazy">
                                </a>
                            </div>
                            <div class="product-card-body">
                                <span class="product-category-name"><?= e($rel['category_name']) ?></span>
                                <a href="<?= base_url('/product/' . urlencode($rel['slug'])) ?>" class="product-title">
                                    <?= e($rel['name']) ?>
                                </a>
                                <div class="product-price-row">
                                    <span class="price-current"><?= format_currency($rel['discount_price'] ?: $rel['price']) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>
</div>
