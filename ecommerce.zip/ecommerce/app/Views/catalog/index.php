<?php
use App\Services\CSRF;
?>

<div class="container py-4">
    <!-- Breadcrumb & Header -->
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb small">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('/catalog') ?>">Catalog</a></li>
            <?php if ($currentCategory): ?>
                <li class="breadcrumb-item active"><?= e($currentCategory['name']) ?></li>
            <?php else: ?>
                <li class="breadcrumb-item active">All Products</li>
            <?php endif; ?>
        </ol>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 fw-bold mb-1"><?= $currentCategory ? e($currentCategory['name']) : 'Product Catalog' ?></h1>
            <p class="text-muted small m-0">Showing <?= count($catalog['items']) ?> of <?= $catalog['total'] ?> available products</p>
        </div>

        <!-- Sorting Selector -->
        <div class="d-flex align-items-center gap-2 mt-3 mt-sm-0">
            <label for="catalogSort" class="small fw-semibold text-muted text-nowrap">Sort By:</label>
            <select id="catalogSort" class="form-select form-select-sm" onchange="location = this.value;">
                <?php
                $sortParams = $_GET;
                $makeSortUrl = function($sortKey) use ($sortParams) {
                    $sortParams['sort'] = $sortKey;
                    $sortParams['page'] = 1;
                    return base_url('/catalog?' . http_build_query($sortParams));
                };
                $currentSort = $filters['sort'] ?? 'newest';
                ?>
                <option value="<?= $makeSortUrl('newest') ?>" <?= $currentSort === 'newest' ? 'selected' : '' ?>>Newest Arrivals</option>
                <option value="<?= $makeSortUrl('popularity') ?>" <?= $currentSort === 'popularity' ? 'selected' : '' ?>>Popularity</option>
                <option value="<?= $makeSortUrl('price_asc') ?>" <?= $currentSort === 'price_asc' ? 'selected' : '' ?>>Price: Low to High</option>
                <option value="<?= $makeSortUrl('price_desc') ?>" <?= $currentSort === 'price_desc' ? 'selected' : '' ?>>Price: High to Low</option>
                <option value="<?= $makeSortUrl('rating') ?>" <?= $currentSort === 'rating' ? 'selected' : '' ?>>Highest Rated</option>
            </select>
        </div>
    </div>

    <div class="row g-4">
        <!-- Filter Sidebar -->
        <div class="col-lg-3">
            <div class="bg-white p-4 rounded-3 border">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold m-0"><i class="bi bi-funnel me-1 text-primary"></i> Filters</h5>
                    <a href="<?= base_url('/catalog') ?>" class="small text-danger text-decoration-none">Reset</a>
                </div>

                <form action="<?= base_url('/catalog') ?>" method="GET">
                    <!-- Preserve sorting -->
                    <input type="hidden" name="sort" value="<?= e($filters['sort']) ?>">

                    <!-- Search -->
                    <div class="mb-4">
                        <label class="form-label small fw-bold text-uppercase text-muted">Keyword</label>
                        <input type="text" name="q" class="form-control form-control-sm" placeholder="Search title or SKU..." value="<?= e($filters['search']) ?>">
                    </div>

                    <!-- Categories -->
                    <div class="mb-4">
                        <label class="form-label small fw-bold text-uppercase text-muted">Category</label>
                        <div class="d-flex flex-column gap-1">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="category" value="" id="cat_all" <?= empty($filters['category_slug']) ? 'checked' : '' ?>>
                                <label class="form-check-label small" for="cat_all">All Categories</label>
                            </div>
                            <?php foreach ($categories as $cat): ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="category" value="<?= e($cat['slug']) ?>" id="cat_<?= $cat['id'] ?>" <?= ($filters['category_slug'] === $cat['slug']) ? 'checked' : '' ?>>
                                    <label class="form-check-label small" for="cat_<?= $cat['id'] ?>">
                                        <?= e($cat['name']) ?> <span class="text-muted">(<?= (int)($cat['product_count'] ?? 0) ?>)</span>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Price Filter -->
                    <div class="mb-4">
                        <label class="form-label small fw-bold text-uppercase text-muted">Price Range ($)</label>
                        <div class="row g-2">
                            <div class="col-6">
                                <input type="number" name="min_price" class="form-control form-control-sm" placeholder="Min" value="<?= e($filters['min_price'] ?? '') ?>" min="0" step="1">
                            </div>
                            <div class="col-6">
                                <input type="number" name="max_price" class="form-control form-control-sm" placeholder="Max" value="<?= e($filters['max_price'] ?? '') ?>" min="0" step="1">
                            </div>
                        </div>
                    </div>

                    <!-- Stock Availability -->
                    <div class="mb-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="in_stock" value="1" id="in_stock_chk" <?= !empty($filters['in_stock']) ? 'checked' : '' ?>>
                            <label class="form-check-label small fw-semibold" for="in_stock_chk">In Stock Only</label>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary-custom btn-sm w-100 py-2">
                        Apply Filters
                    </button>
                </form>
            </div>
        </div>

        <!-- Product Grid -->
        <div class="col-lg-9">
            <?php if (empty($catalog['items'])): ?>
                <div class="bg-white p-5 rounded-3 border text-center my-4">
                    <i class="bi bi-search fs-1 text-muted mb-3 d-block"></i>
                    <h4 class="fw-bold">No Products Found</h4>
                    <p class="text-muted">We couldn't find any products matching your specific filter criteria.</p>
                    <a href="<?= base_url('/catalog') ?>" class="btn btn-outline-custom mt-2">Clear All Filters</a>
                </div>
            <?php else: ?>
                <div class="row g-3 g-md-4">
                    <?php foreach ($catalog['items'] as $product): ?>
                        <div class="col-6 col-md-4">
                            <div class="product-card">
                                <div class="product-image-wrap">
                                    <a href="<?= base_url('/product/' . urlencode($product['slug'])) ?>">
                                        <img src="<?= e($product['primary_image'] ?: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80') ?>" alt="<?= e($product['name']) ?>" loading="lazy">
                                    </a>

                                    <?php if (!empty($product['discount_price'])): ?>
                                        <span class="badge bg-danger product-badge">Sale</span>
                                    <?php elseif ($product['is_new_arrival']): ?>
                                        <span class="badge bg-primary product-badge">New</span>
                                    <?php endif; ?>

                                    <button type="button" class="btn-wishlist-toggle" data-product-id="<?= (int)$product['id'] ?>" title="Save to wishlist">
                                        <i class="bi bi-heart-fill"></i>
                                    </button>
                                </div>

                                <div class="product-card-body">
                                    <span class="product-category-name"><?= e($product['category_name']) ?></span>
                                    <a href="<?= base_url('/product/' . urlencode($product['slug'])) ?>" class="product-title">
                                        <?= e($product['name']) ?>
                                    </a>

                                    <!-- Rating -->
                                    <div class="d-flex align-items-center my-2">
                                        <div class="rating-stars">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <i class="bi <?= $i <= round((float)$product['rating_avg']) ? 'bi-star-fill' : 'bi-star' ?>"></i>
                                            <?php endfor; ?>
                                        </div>
                                        <span class="rating-count">(<?= (int)$product['rating_count'] ?>)</span>
                                    </div>

                                    <div class="product-price-row mb-3">
                                        <span class="price-current">
                                            <?= format_currency($product['discount_price'] ?: $product['price']) ?>
                                        </span>
                                        <?php if (!empty($product['discount_price'])): ?>
                                            <span class="price-original"><?= format_currency($product['price']) ?></span>
                                        <?php endif; ?>
                                    </div>

                                    <form action="<?= base_url('/cart/add') ?>" method="POST" class="form-add-to-cart m-0">
                                        <?= CSRF::field() ?>
                                        <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
                                        <input type="hidden" name="quantity" value="1">
                                        <button type="submit" class="btn btn-outline-custom w-100 py-2 d-flex align-items-center justify-content-center gap-2">
                                            <i class="bi bi-bag-plus"></i> Add to Cart
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Server-Side Pagination -->
                <?php if ($catalog['total_pages'] > 1): ?>
                    <nav aria-label="Catalog pagination" class="mt-5">
                        <ul class="pagination justify-content-center">
                            <?php
                            $queryParams = $_GET;
                            $makePageUrl = function($pageNum) use ($queryParams) {
                                $queryParams['page'] = $pageNum;
                                return base_url('/catalog?' . http_build_query($queryParams));
                            };
                            $currentPage = $catalog['page'];
                            $totalPages = $catalog['total_pages'];
                            ?>

                            <li class="page-item <?= $currentPage <= 1 ? 'disabled' : '' ?>">
                                <a class="page-link" href="<?= $makePageUrl($currentPage - 1) ?>">Previous</a>
                            </li>

                            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                                <li class="page-item <?= $p === $currentPage ? 'active' : '' ?>">
                                    <a class="page-link" href="<?= $makePageUrl($p) ?>"><?= $p ?></a>
                                </li>
                            <?php endfor; ?>

                            <li class="page-item <?= $currentPage >= $totalPages ? 'disabled' : '' ?>">
                                <a class="page-link" href="<?= $makePageUrl($currentPage + 1) ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
