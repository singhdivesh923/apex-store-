<?php
use App\Models\Cart;
use App\Models\Category;
use App\Models\Setting;
use App\Services\Auth;
use App\Services\CSRF;

$storeName = Setting::get('store_name', 'ApexStore');
$currentUser = Auth::user();
$cartId = Cart::getOrCreateCartId(Auth::id());
$cartTotals = Cart::getTotals($cartId);
$navCategories = Category::allActiveWithHierarchy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= e(CSRF::getToken()) ?>">
    <title><?= e($pageTitle ?? $storeName) ?></title>
    
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5.3 CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    
    <!-- Storefront Custom Styles -->
    <link href="<?= asset('css/storefront.css') ?>" rel="stylesheet">
</head>
<body>

<!-- Top Notification Bar -->
<div class="bg-dark text-white py-1 small text-center">
    <div class="container d-flex justify-content-between align-items-center">
        <span><i class="bi bi-shield-check me-1 text-primary"></i> 100% Guaranteed Authentic & Secured Checkout</span>
        <span class="d-none d-md-inline">Complimentary shipping on qualifying orders over <?= format_currency(Setting::get('free_shipping_threshold', 150)) ?></span>
        <div>
            <?php if (Auth::isAdmin()): ?>
                <a href="<?= base_url('/admin') ?>" class="text-warning text-decoration-none fw-semibold me-3"><i class="bi bi-speedometer2 me-1"></i> Admin Console</a>
            <?php endif; ?>
            <a href="<?= base_url('/contact') ?>" class="text-white text-decoration-none"><i class="bi bi-headset me-1"></i> Help</a>
        </div>
    </div>
</div>

<!-- Primary Navigation Bar -->
<nav class="navbar navbar-expand-lg site-navbar py-3">
    <div class="container">
        <!-- Brand -->
        <a class="navbar-brand d-flex align-items-center" href="<?= base_url('/') ?>">
            <i class="bi bi-hexagon-fill text-primary me-2 fs-4"></i>
            <span><?= e($storeName) ?></span><span class="brand-dot">.</span>
        </a>

        <!-- Mobile Toggler -->
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarContent">
            <!-- Navigation Links -->
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/') ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/catalog') ?>">All Products</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Categories
                    </a>
                    <ul class="dropdown-menu border-0 shadow-sm rounded-3">
                        <?php foreach ($navCategories as $cat): ?>
                            <li><a class="dropdown-item py-2" href="<?= base_url('/catalog?category=' . urlencode($cat['slug'])) ?>"><?= e($cat['name']) ?></a></li>
                        <?php endforeach; ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item py-2 fw-semibold text-primary" href="<?= base_url('/catalog') ?>">View Entire Catalog &rarr;</a></li>
                    </ul>
                </li>
            </ul>

            <!-- Search Bar -->
            <form action="<?= base_url('/catalog') ?>" method="GET" class="d-flex mx-lg-3 my-2 my-lg-0 flex-grow-1" style="max-width: 380px;">
                <div class="input-group">
                    <input type="text" name="q" class="form-control bg-light border-end-0 rounded-start-pill ps-3" placeholder="Search devices, apparel..." value="<?= e($_GET['q'] ?? '') ?>" aria-label="Search">
                    <button class="btn btn-light bg-light border-start-0 border rounded-end-pill px-3 text-muted" type="submit">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
            </form>

            <!-- User & Cart Actions -->
            <div class="d-flex align-items-center gap-3 ms-lg-2">
                <!-- Wishlist -->
                <a href="<?= base_url('/wishlist') ?>" class="btn btn-light rounded-circle position-relative p-2" title="Wishlist">
                    <i class="bi bi-heart fs-5"></i>
                </a>

                <!-- Cart -->
                <a href="<?= base_url('/cart') ?>" class="btn btn-light rounded-circle position-relative p-2" title="Shopping Cart">
                    <i class="bi bi-bag fs-5"></i>
                    <span class="cart-badge cart-count-badge" style="<?= $cartTotals['total_items'] > 0 ? '' : 'display: none;' ?>">
                        <?= (int)$cartTotals['total_items'] ?>
                    </span>
                </a>

                <!-- Account -->
                <?php if ($currentUser): ?>
                    <div class="dropdown">
                        <button class="btn btn-outline-custom dropdown-toggle d-flex align-items-center gap-2 py-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle fs-5 text-primary"></i>
                            <span class="d-none d-sm-inline fw-semibold"><?= e(explode(' ', $currentUser['name'])[0]) ?></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end border-0 shadow-sm rounded-3 mt-2">
                            <li><h6 class="dropdown-header"><?= e($currentUser['email']) ?></h6></li>
                            <li><a class="dropdown-item py-2" href="<?= base_url('/account/orders') ?>"><i class="bi bi-box-seam me-2"></i> My Orders</a></li>
                            <li><a class="dropdown-item py-2" href="<?= base_url('/account/profile') ?>"><i class="bi bi-person me-2"></i> Profile & Password</a></li>
                            <li><a class="dropdown-item py-2" href="<?= base_url('/account/addresses') ?>"><i class="bi bi-geo-alt me-2"></i> Address Book</a></li>
                            <li><a class="dropdown-item py-2" href="<?= base_url('/wishlist') ?>"><i class="bi bi-heart me-2"></i> Saved Wishlist</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="<?= base_url('/logout') ?>" method="POST" class="m-0">
                                    <?= CSRF::field() ?>
                                    <button type="submit" class="dropdown-item text-danger py-2"><i class="bi bi-box-arrow-right me-2"></i> Sign Out</button>
                                </form>
                            </li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="<?= base_url('/login') ?>" class="btn btn-primary-custom px-3 py-2">
                        <i class="bi bi-person me-1"></i> Sign In
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<!-- Global Flash Message Container -->
<?php require __DIR__ . '/alerts.php'; ?>
<main>
