<?php
use App\Models\Setting;
$storeName = Setting::get('store_name', 'ApexStore');
?>
</main>

<!-- Storefront Global Footer -->
<footer class="site-footer">
    <div class="container">
        <div class="row g-4 mb-4">
            <!-- Brand & Mission -->
            <div class="col-lg-4 col-md-6">
                <a class="navbar-brand text-white d-flex align-items-center mb-3" href="<?= base_url('/') ?>">
                    <i class="bi bi-hexagon-fill text-primary me-2 fs-4"></i>
                    <span class="text-white"><?= e($storeName) ?></span><span class="brand-dot">.</span>
                </a>
                <p class="small text-muted mb-3">
                    <?= e(Setting::get('store_tagline', 'Curated Premium Electronics & Lifestyle Essentials.')) ?> Crafted for design perfection and lasting performance.
                </p>
                <div class="small text-muted mb-1"><i class="bi bi-geo-alt me-2 text-primary"></i> <?= e(Setting::get('store_address', '100 Innovation Blvd, San Francisco, CA')) ?></div>
                <div class="small text-muted mb-1"><i class="bi bi-envelope me-2 text-primary"></i> <?= e(Setting::get('store_email', 'support@apexstore.com')) ?></div>
                <div class="small text-muted"><i class="bi bi-telephone me-2 text-primary"></i> <?= e(Setting::get('store_phone', '+1 (800) 555-0199')) ?></div>
            </div>

            <!-- Quick Navigation -->
            <div class="col-lg-2 col-md-6 col-6">
                <h6>Explore</h6>
                <ul class="list-unstyled">
                    <li><a href="<?= base_url('/catalog') ?>">All Products</a></li>
                    <li><a href="<?= base_url('/catalog?sort=newest') ?>">New Arrivals</a></li>
                    <li><a href="<?= base_url('/catalog?sort=popularity') ?>">Best Sellers</a></li>
                    <li><a href="<?= base_url('/cart') ?>">My Cart</a></li>
                    <li><a href="<?= base_url('/wishlist') ?>">Wishlist</a></li>
                </ul>
            </div>

            <!-- Customer Service & Policies -->
            <div class="col-lg-2 col-md-6 col-6">
                <h6>Assistance</h6>
                <ul class="list-unstyled">
                    <li><a href="<?= base_url('/contact') ?>">Customer Support</a></li>
                    <li><a href="<?= base_url('/shipping') ?>">Shipping Policies</a></li>
                    <li><a href="<?= base_url('/returns') ?>">Returns & Refunds</a></li>
                    <li><a href="<?= base_url('/faq') ?>">Frequently Asked Questions</a></li>
                    <li><a href="<?= base_url('/privacy') ?>">Privacy Policy</a></li>
                </ul>
            </div>

            <!-- Newsletter Signup -->
            <div class="col-lg-4 col-md-6">
                <h6>Stay Informed</h6>
                <p class="small text-muted">Join our exclusive private newsletter for early product drops and seasonal promotions.</p>
                <form action="<?= base_url('/newsletter') ?>" method="POST" class="mb-3">
                    <?= \App\Services\CSRF::field() ?>
                    <div class="input-group">
                        <input type="email" name="email" class="form-control bg-dark text-white border-secondary" placeholder="Enter your email" required>
                        <button class="btn btn-primary" type="submit">Subscribe</button>
                    </div>
                </form>
                <div class="d-flex gap-3 fs-5">
                    <a href="#" class="text-secondary"><i class="bi bi-twitter-x"></i></a>
                    <a href="#" class="text-secondary"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="text-secondary"><i class="bi bi-linkedin"></i></a>
                    <a href="#" class="text-secondary"><i class="bi bi-github"></i></a>
                </div>
            </div>
        </div>

        <div class="footer-bottom d-flex flex-column flex-md-row justify-content-between align-items-center">
            <p class="m-0 text-muted">&copy; <?= date('Y') ?> <?= e($storeName) ?> Inc. All rights reserved. Secure 256-bit SSL encrypted.</p>
            <div class="d-flex gap-3 text-muted fs-4 mt-2 mt-md-0">
                <i class="bi bi-credit-card"></i>
                <i class="bi bi-shield-lock"></i>
                <i class="bi bi-cash-coin"></i>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap 5 Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom Storefront JS -->
<script src="<?= asset('js/storefront.js') ?>"></script>
</body>
</html>
