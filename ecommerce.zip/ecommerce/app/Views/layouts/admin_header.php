<?php
use App\Models\Setting;
use App\Services\Auth;
use App\Services\CSRF;

$storeName = Setting::get('store_name', 'ApexStore');
$currentAdmin = Auth::user();
$currentUri = parse_url($_SERVER['REQUEST_URI'] ?? '/admin', PHP_URL_PATH);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= e(CSRF::getToken()) ?>">
    <title><?= e($pageTitle ?? 'Admin Panel') ?> | <?= e($storeName) ?> Admin</title>

    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Bootstrap 5.3 & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <!-- Admin CSS -->
    <link href="<?= asset('css/admin.css') ?>" rel="stylesheet">
</head>
<body class="admin-body">

<div class="admin-wrapper">
    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <a href="<?= base_url('/admin') ?>" class="sidebar-brand d-flex align-items-center">
            <i class="bi bi-hexagon-fill text-primary me-2"></i>
            <span><?= e($storeName) ?></span><span class="text-primary ms-1">Control</span>
        </a>

        <div class="sidebar-nav">
            <div class="text-uppercase small fw-bold px-3 py-2 text-secondary" style="font-size: 0.7rem; letter-spacing: 0.08em;">Operations</div>
            <a href="<?= base_url('/admin') ?>" class="sidebar-link <?= $currentUri === '/admin' ? 'active' : '' ?>">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
            <a href="<?= base_url('/admin/orders') ?>" class="sidebar-link <?= str_starts_with($currentUri, '/admin/orders') ? 'active' : '' ?>">
                <i class="bi bi-box-seam"></i> Orders
            </a>
            <a href="<?= base_url('/admin/products') ?>" class="sidebar-link <?= str_starts_with($currentUri, '/admin/products') ? 'active' : '' ?>">
                <i class="bi bi-tags"></i> Products
            </a>
            <a href="<?= base_url('/admin/categories') ?>" class="sidebar-link <?= str_starts_with($currentUri, '/admin/categories') ? 'active' : '' ?>">
                <i class="bi bi-grid"></i> Categories
            </a>
            <a href="<?= base_url('/admin/customers') ?>" class="sidebar-link <?= str_starts_with($currentUri, '/admin/customers') ? 'active' : '' ?>">
                <i class="bi bi-people"></i> Customers
            </a>

            <div class="text-uppercase small fw-bold px-3 py-2 mt-3 text-secondary" style="font-size: 0.7rem; letter-spacing: 0.08em;">Marketing & Feedback</div>
            <a href="<?= base_url('/admin/coupons') ?>" class="sidebar-link <?= str_starts_with($currentUri, '/admin/coupons') ? 'active' : '' ?>">
                <i class="bi bi-ticket-perforated"></i> Coupons
            </a>
            <a href="<?= base_url('/admin/reviews') ?>" class="sidebar-link <?= str_starts_with($currentUri, '/admin/reviews') ? 'active' : '' ?>">
                <i class="bi bi-star"></i> Reviews
            </a>
            <a href="<?= base_url('/admin/reports') ?>" class="sidebar-link <?= str_starts_with($currentUri, '/admin/reports') ? 'active' : '' ?>">
                <i class="bi bi-bar-chart-line"></i> Analytics & CSV
            </a>

            <div class="text-uppercase small fw-bold px-3 py-2 mt-3 text-secondary" style="font-size: 0.7rem; letter-spacing: 0.08em;">Configuration</div>
            <a href="<?= base_url('/admin/settings') ?>" class="sidebar-link <?= str_starts_with($currentUri, '/admin/settings') ? 'active' : '' ?>">
                <i class="bi bi-gear"></i> Store Settings
            </a>
            <a href="<?= base_url('/') ?>" target="_blank" class="sidebar-link">
                <i class="bi bi-box-arrow-up-right"></i> View Storefront
            </a>
        </div>

        <div class="p-3 border-top border-secondary border-opacity-25">
            <div class="d-flex align-items-center justify-content-between">
                <div class="text-truncate me-2">
                    <div class="small fw-bold text-white text-truncate"><?= e($currentAdmin['name'] ?? 'Admin') ?></div>
                    <div class="text-muted text-truncate" style="font-size: 0.75rem;"><?= e($currentAdmin['email'] ?? '') ?></div>
                </div>
                <form action="<?= base_url('/admin/logout') ?>" method="POST" class="m-0">
                    <?= CSRF::field() ?>
                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Logout">
                        <i class="bi bi-box-arrow-right"></i>
                    </button>
                </form>
            </div>
        </div>
    </aside>

    <!-- Main Content Area -->
    <main class="admin-main">
        <header class="admin-header">
            <div>
                <button class="btn btn-sm btn-outline-secondary d-lg-none me-2" id="sidebarToggle" type="button">
                    <i class="bi bi-list"></i>
                </button>
                <h1 class="h3 d-inline-block align-middle mb-0 fw-bold"><?= e($pageTitle ?? 'Dashboard') ?></h1>
            </div>
            <div class="d-flex align-items-center gap-2">
                <span class="badge bg-primary bg-opacity-10 text-primary py-2 px-3 fw-semibold">
                    <i class="bi bi-shield-check me-1"></i> Admin Privileges
                </span>
            </div>
        </header>

        <!-- Flash alerts inside Admin layout -->
        <?php require __DIR__ . '/alerts.php'; ?>
