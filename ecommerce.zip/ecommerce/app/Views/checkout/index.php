<?php
use App\Models\Setting;
use App\Services\CSRF;
?>

<div class="container py-4">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb small">
            <li class="breadcrumb-item"><a href="<?= base_url('/cart') ?>">Cart</a></li>
            <li class="breadcrumb-item active">Checkout</li>
        </ol>
    </nav>

    <h1 class="h3 fw-bold mb-4">Secure Checkout</h1>

    <form action="<?= base_url('/checkout/process') ?>" method="POST" id="checkoutForm">
        <?= CSRF::field() ?>

        <div class="row g-5">
            <!-- Left Column: Shipping & Payment Details -->
            <div class="col-lg-7">
                <!-- Contact Details -->
                <?php if (!$user): ?>
                    <div class="bg-white p-4 rounded-3 border mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="fw-bold m-0"><i class="bi bi-person me-2 text-primary"></i> Contact Information</h5>
                            <span class="small">Already have an account? <a href="<?= base_url('/login') ?>" class="text-primary fw-semibold">Sign In</a></span>
                        </div>
                        <div class="mb-0">
                            <label class="form-label small fw-bold">Email Address (for order tracking & receipts)</label>
                            <input type="email" name="guest_email" class="form-control" placeholder="name@example.com" required>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Shipping Address Selection -->
                <div class="bg-white p-4 rounded-3 border mb-4">
                    <h5 class="fw-bold mb-3"><i class="bi bi-geo-alt me-2 text-primary"></i> Shipping Destination</h5>

                    <?php if (!empty($addresses)): ?>
                        <div class="mb-4">
                            <label class="form-label small fw-bold text-muted text-uppercase">Choose Saved Address</label>
                            <div class="d-flex flex-column gap-2">
                                <?php foreach ($addresses as $addr): ?>
                                    <div class="form-check p-3 border rounded-3 bg-light">
                                        <input class="form-check-input" type="radio" name="selected_address_id" id="addr_<?= $addr['id'] ?>" value="<?= $addr['id'] ?>" <?= $addr['is_default'] ? 'checked' : '' ?> onchange="autofillAddress(<?= htmlspecialchars(json_encode($addr), ENT_QUOTES, 'UTF-8') ?>)">
                                        <label class="form-check-label w-100 ms-2" for="addr_<?= $addr['id'] ?>">
                                            <div class="d-flex justify-content-between">
                                                <strong><?= e($addr['recipient_name']) ?></strong> (<?= e($addr['phone']) ?>)
                                                <?php if ($addr['is_default']): ?><span class="badge bg-primary">Default</span><?php endif; ?>
                                            </div>
                                            <div class="small text-muted"><?= e($addr['address_line1']) ?>, <?= e($addr['city']) ?>, <?= e($addr['state']) ?> <?= e($addr['postal_code']) ?></div>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <hr class="my-4">
                        <h6 class="fw-bold mb-3 text-muted text-uppercase small">Or Enter Destination Details Below</h6>
                    <?php endif; ?>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Recipient Full Name</label>
                            <input type="text" name="recipient_name" id="ship_recipient_name" class="form-control" value="<?= e($user['name'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Phone Number</label>
                            <input type="tel" name="phone" id="ship_phone" class="form-control" value="<?= e($user['phone'] ?? '') ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Street Address</label>
                            <input type="text" name="address_line1" id="ship_address_line1" class="form-control" placeholder="123 Main Street" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Apartment, Suite, Unit (Optional)</label>
                            <input type="text" name="address_line2" id="ship_address_line2" class="form-control" placeholder="Apt 4B">
                        </div>
                        <div class="col-md-5">
                            <label class="form-label small fw-bold">City</label>
                            <input type="text" name="city" id="ship_city" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">State / Province</label>
                            <input type="text" name="state" id="ship_state" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-bold">Postal Code</label>
                            <input type="text" name="postal_code" id="ship_postal_code" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Country</label>
                            <select name="country" class="form-select">
                                <option value="US" selected>United States</option>
                                <option value="CA">Canada</option>
                                <option value="GB">United Kingdom</option>
                                <option value="AU">Australia</option>
                                <option value="IN">India</option>
                            </select>
                        </div>
                        <?php if ($user): ?>
                            <div class="col-12">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="save_address" value="1" id="saveAddrCheck" checked>
                                    <label class="form-check-label small" for="saveAddrCheck">
                                        Save this address to my profile address book
                                    </label>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Payment Method Selection -->
                <div class="bg-white p-4 rounded-3 border mb-4">
                    <h5 class="fw-bold mb-3"><i class="bi bi-credit-card me-2 text-primary"></i> Payment Method</h5>

                    <div class="d-flex flex-column gap-3">
                        <!-- Cash on Delivery -->
                        <?php if ($enableCod): ?>
                            <div class="form-check p-3 border rounded-3 bg-light">
                                <input class="form-check-input" type="radio" name="payment_method" id="pay_cod" value="cod" checked>
                                <label class="form-check-label ms-2 w-100" for="pay_cod">
                                    <div class="fw-bold text-dark"><i class="bi bi-cash-stack text-success me-1"></i> Cash on Delivery (COD)</div>
                                    <div class="small text-muted">Pay securely with cash upon courier delivery at your doorstep.</div>
                                </label>
                            </div>
                        <?php endif; ?>

                        <!-- Razorpay Online -->
                        <?php if ($enableRazorpay): ?>
                            <div class="form-check p-3 border rounded-3 bg-light">
                                <input class="form-check-input" type="radio" name="payment_method" id="pay_razorpay" value="razorpay" <?= !$enableCod ? 'checked' : '' ?>>
                                <label class="form-check-label ms-2 w-100" for="pay_razorpay">
                                    <div class="fw-bold text-dark"><i class="bi bi-credit-card-2-front text-primary me-1"></i> Razorpay (Cards, UPI, NetBanking)</div>
                                    <div class="small text-muted">Instant online settlement via credit cards, debit cards, or UPI.</div>
                                </label>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Delivery Instructions -->
                <div class="bg-white p-4 rounded-3 border">
                    <h5 class="fw-bold mb-2"><i class="bi bi-chat-left-text me-2 text-primary"></i> Order Notes (Optional)</h5>
                    <textarea name="customer_notes" rows="2" class="form-control" placeholder="Special delivery gate instructions, buzzer code, etc."></textarea>
                </div>
            </div>

            <!-- Right Column: Order Summary Review -->
            <div class="col-lg-5">
                <div class="bg-white p-4 rounded-3 border position-sticky" style="top: 90px;">
                    <h5 class="fw-bold mb-3 border-bottom pb-2">Order Review (<?= $cart['total_items'] ?> items)</h5>

                    <div class="d-flex flex-column gap-2 mb-3 overflow-auto" style="max-height: 250px;">
                        <?php foreach ($cart['items'] as $item): ?>
                            <div class="d-flex justify-content-between align-items-center py-1">
                                <div class="d-flex align-items-center gap-2 text-truncate me-2">
                                    <img src="<?= e($item['primary_image'] ?: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=60&q=80') ?>" alt="<?= e($item['name']) ?>" class="rounded-1" style="width: 40px; height: 40px; object-fit: cover;">
                                    <div class="text-truncate">
                                        <div class="small fw-semibold text-truncate"><?= e($item['name']) ?></div>
                                        <div class="small text-muted">Qty: <?= (int)$item['quantity'] ?> &times; <?= format_currency($item['unit_price']) ?></div>
                                    </div>
                                </div>
                                <span class="fw-semibold small text-nowrap"><?= format_currency($item['line_total']) ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <hr>

                    <div class="d-flex justify-content-between mb-2 small">
                        <span class="text-muted">Subtotal</span>
                        <span class="fw-semibold"><?= format_currency($cart['subtotal']) ?></span>
                    </div>

                    <?php if ($cart['discount'] > 0): ?>
                        <div class="d-flex justify-content-between mb-2 small text-success">
                            <span>Coupon Discount (<?= e($cart['coupon']['code']) ?>)</span>
                            <span>-<?= format_currency($cart['discount']) ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="d-flex justify-content-between mb-2 small">
                        <span class="text-muted">Courier Shipping</span>
                        <span class="fw-semibold">
                            <?= $cart['shipping'] == 0 ? '<span class="text-success">Complimentary</span>' : format_currency($cart['shipping']) ?>
                        </span>
                    </div>

                    <div class="d-flex justify-content-between mb-3 small">
                        <span class="text-muted">Estimated Tax (<?= $cart['tax_percent'] ?>%)</span>
                        <span class="fw-semibold"><?= format_currency($cart['tax']) ?></span>
                    </div>

                    <div class="border-top pt-3 mb-4 d-flex justify-content-between align-items-baseline">
                        <span class="h5 fw-bold m-0">Final Total</span>
                        <span class="h4 fw-bold text-primary m-0"><?= format_currency($cart['grand_total']) ?></span>
                    </div>

                    <button type="submit" class="btn btn-primary-custom w-100 py-3 fw-bold fs-6 d-flex align-items-center justify-content-center gap-2" id="submitOrderBtn">
                        <i class="bi bi-shield-lock-fill"></i> Place Order Now
                    </button>

                    <p class="text-muted small text-center mt-3 mb-0">
                        <i class="bi bi-shield-check text-success me-1"></i> Your transaction is secured by end-to-end 256-bit encryption.
                    </p>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
function autofillAddress(addr) {
    if (!addr) return;
    document.getElementById('ship_recipient_name').value = addr.recipient_name || '';
    document.getElementById('ship_phone').value = addr.phone || '';
    document.getElementById('ship_address_line1').value = addr.address_line1 || '';
    document.getElementById('ship_address_line2').value = addr.address_line2 || '';
    document.getElementById('ship_city').value = addr.city || '';
    document.getElementById('ship_state').value = addr.state || '';
    document.getElementById('ship_postal_code').value = addr.postal_code || '';
}

// Auto-populate with default address on load if radio exists
document.addEventListener('DOMContentLoaded', () => {
    const checkedRadio = document.querySelector('input[name="selected_address_id"]:checked');
    if (checkedRadio) {
        checkedRadio.dispatchEvent(new Event('change'));
    }
});
</script>
