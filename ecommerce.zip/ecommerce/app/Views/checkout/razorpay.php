<?php
use App\Models\Setting;
use App\Services\CSRF;
?>

<div class="container py-5 text-center">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="bg-white p-5 rounded-3 border shadow-sm">
                <i class="bi bi-shield-lock-fill fs-1 text-primary mb-3 d-block"></i>
                <h3 class="fw-bold mb-2">Connecting to Secure Gateway</h3>
                <p class="text-muted mb-4">Please do not refresh this page or close your browser window while we initiate your secure payment session.</p>

                <div class="spinner-border text-primary my-3" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>

                <div class="mt-4">
                    <button type="button" class="btn btn-primary-custom px-4" id="rzp-button">
                        Open Payment Gateway Window
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Razorpay Official Checkout SDK -->
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<form name='razorpayform' action="<?= base_url('/checkout/verify-payment') ?>" method="POST">
    <?= CSRF::field() ?>
    <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
    <input type="hidden" name="razorpay_order_id" id="razorpay_order_id">
    <input type="hidden" name="razorpay_signature" id="razorpay_signature">
</form>

<script>
const options = {
    "key": "<?= e($payment['key_id']) ?>",
    "amount": "<?= (int)$payment['amount'] ?>",
    "currency": "<?= e($payment['currency']) ?>",
    "name": "<?= e(Setting::get('store_name', 'ApexStore')) ?>",
    "description": "Order #<?= e($payment['order_number']) ?> Payment",
    "order_id": "<?= e($payment['gateway_order_id']) ?>",
    "handler": function (response){
        document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
        document.getElementById('razorpay_order_id').value = response.razorpay_order_id;
        document.getElementById('razorpay_signature').value = response.razorpay_signature;
        document.razorpayform.submit();
    },
    "prefill": {
        "name": "<?= e($order['shipping_address']['recipient_name'] ?? '') ?>",
        "email": "<?= e($order['shipping_address']['email'] ?? '') ?>",
        "contact": "<?= e($order['shipping_address']['phone'] ?? '') ?>"
    },
    "theme": {
        "color": "#2563eb"
    }
};

const rzp = new Razorpay(options);

document.getElementById('rzp-button').onclick = function(e){
    rzp.open();
    e.preventDefault();
}

// Automatically trigger modal
window.addEventListener('load', () => {
    rzp.open();
});
</script>
