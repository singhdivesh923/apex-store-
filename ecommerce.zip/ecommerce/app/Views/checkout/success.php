<?php
use App\Models\Setting;
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="bg-white p-4 p-md-5 rounded-3 border text-center shadow-sm">
                <!-- Success Icon -->
                <div class="d-inline-flex p-3 bg-success bg-opacity-10 text-success rounded-circle mb-3">
                    <i class="bi bi-check-circle-fill fs-1"></i>
                </div>

                <h1 class="h3 fw-bold mb-2">Order Confirmed!</h1>
                <p class="text-muted mb-4">
                    Thank you for your order. We have received your order details and our fulfillment team is preparing your package.
                </p>

                <!-- Order Reference Card -->
                <div class="bg-light p-3 rounded-3 border mb-4 d-inline-block text-start w-100" style="max-width: 500px;">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted small">Order Reference:</span>
                        <strong class="text-primary font-monospace"><?= e($order['order_number']) ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted small">Date Placed:</span>
                        <span class="small"><?= date('F d, Y \a\t h:i A', strtotime($order['created_at'])) ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted small">Payment Method:</span>
                        <span class="badge bg-secondary text-uppercase"><?= e($order['payment_method']) ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted small">Payment Status:</span>
                        <span class="badge <?= $order['payment_status'] === 'paid' ? 'bg-success' : 'bg-warning text-dark' ?> text-uppercase">
                            <?= e($order['payment_status']) ?>
                        </span>
                    </div>
                    <div class="d-flex justify-content-between border-top pt-2">
                        <span class="fw-bold">Total Paid / Payable:</span>
                        <span class="fw-bold text-dark fs-5"><?= format_currency($order['total_amount']) ?></span>
                    </div>
                </div>

                <!-- Destination Summary -->
                <div class="text-start bg-light p-3 rounded-3 border mb-4 mx-auto" style="max-width: 500px;">
                    <h6 class="fw-bold small text-uppercase text-muted mb-2"><i class="bi bi-truck me-1"></i> Shipping Address</h6>
                    <div class="fw-semibold text-dark"><?= e($order['shipping_address']['recipient_name'] ?? '') ?></div>
                    <div class="small text-muted"><?= e($order['shipping_address']['address_line1'] ?? '') ?></div>
                    <?php if (!empty($order['shipping_address']['address_line2'])): ?>
                        <div class="small text-muted"><?= e($order['shipping_address']['address_line2']) ?></div>
                    <?php endif; ?>
                    <div class="small text-muted">
                        <?= e($order['shipping_address']['city'] ?? '') ?>, <?= e($order['shipping_address']['state'] ?? '') ?> <?= e($order['shipping_address']['postal_code'] ?? '') ?>
                    </div>
                    <div class="small text-muted">Phone: <?= e($order['shipping_address']['phone'] ?? '') ?></div>
                </div>

                <!-- Actions -->
                <div class="d-flex justify-content-center gap-3">
                    <?php if (!empty($order['user_id'])): ?>
                        <a href="<?= base_url('/account/orders/' . urlencode($order['order_number'])) ?>" class="btn btn-outline-custom">
                            View Order Status
                        </a>
                    <?php endif; ?>
                    <a href="<?= base_url('/catalog') ?>" class="btn btn-primary-custom px-4">
                        Continue Shopping
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
