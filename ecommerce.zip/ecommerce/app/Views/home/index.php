<?php
use App\Models\Setting;
use App\Services\CSRF;
?>

<div class="container">
    <!-- Hero Section -->
    <div class="hero-banner p-4 p-md-5">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <span class="hero-tag"><i class="bi bi-stars me-1"></i> New Season Arrivals</span>
                <h1 class="hero-title mb-3">Engineered Elegance. Timeless Precision.</h1>
                <p class="hero-subtitle mb-4">Discover our curated collection of audiophile gear, titanium smart wearables, and sustainable everyday garments designed for enduring luxury.</p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="<?= base_url('/catalog') ?>" class="btn btn-primary-custom btn-lg px-4">
                        Shop Collection <i class="bi bi-arrow-right ms-2"></i>
                    </a>
                    <a href="<?= base_url('/catalog?sort=popularity') ?>" class="btn btn-outline-light btn-lg px-4">
                        Best Sellers
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Category Strip -->
    <section class="mb-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="h4 mb-1">Browse Categories</h2>
                <p class="text-muted small m-0">Handpicked collections suited for modern life</p>
            </div>
            <a href="<?= base_url('/catalog') ?>" class="text-primary fw-semibold small">View All &rarr;</a>
        </div>
        <div class="row g-3">
            <?php foreach ($categories as $cat): ?>
                <div class="col-6 col-md-3">
                    <a href="<?= base_url('/catalog?category=' . urlencode($cat['slug'])) ?>" class="category-card">
                        <?php if (!empty($cat['image_url'])): ?>
                            <img src="<?= e($cat['image_url']) ?>" alt="<?= e($cat['name']) ?>" class="category-img">
                        <?php else: ?>
                            <div class="category-img bg-light d-flex align-items-center justify-content-center text-secondary">
                                <i class="bi bi-collection fs-4"></i>
                            </div>
                        <?php endif; ?>
                        <h6 class="fw-bold mb-1 text-dark"><?= e($cat['name']) ?></h6>
                        <span class="text-muted small"><?= (int)($cat['product_count'] ?? 0) ?> items</span>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Featured Products -->
    <section class="mb-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="h4 mb-1">Featured Products</h2>
                <p class="text-muted small m-0">Signature products recognized for exceptional engineering</p>
            </div>
            <a href="<?= base_url('/catalog') ?>" class="text-primary fw-semibold small">See Entire Catalog &rarr;</a>
        </div>

        <div class="row g-4">
            <?php foreach ($featuredProducts as $product): ?>
                <div class="col-6 col-lg-3">
                    <div class="product-card">
                        <!-- Image Wrap -->
                        <div class="product-image-wrap">
                            <a href="<?= base_url('/product/' . urlencode($product['slug'])) ?>">
                                <img src="<?= e($product['primary_image'] ?: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80') ?>" alt="<?= e($product['name']) ?>" loading="lazy">
                            </a>

                            <?php if (!empty($product['discount_price'])): ?>
                                <span class="badge bg-danger product-badge">Sale</span>
                            <?php elseif ($product['is_new_arrival']): ?>
                                <span class="badge bg-primary product-badge">New</span>
                            <?php endif; ?>

                            <button type="button" class="btn-wishlist-toggle" data-product-id="<?= (int)$product['id'] ?>" title="Save to wishlist">
                                <i class="bi bi-heart-fill"></i>
                            </button>
                        </div>

                        <!-- Card Body -->
                        <div class="product-card-body">
                            <span class="product-category-name"><?= e($product['category_name']) ?></span>
                            <a href="<?= base_url('/product/' . urlencode($product['slug'])) ?>" class="product-title">
                                <?= e($product['name']) ?>
                            </a>

                            <!-- Rating -->
                            <div class="d-flex align-items-center my-2">
                                <div class="rating-stars">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <i class="bi <?= $i <= round((float)$product['rating_avg']) ? 'bi-star-fill' : 'bi-star' ?>"></i>
                                    <?php endfor; ?>
                                </div>
                                <span class="rating-count">(<?= (int)$product['rating_count'] ?>)</span>
                            </div>

                            <!-- Price & Add -->
                            <div class="product-price-row mb-3">
                                <span class="price-current">
                                    <?= format_currency($product['discount_price'] ?: $product['price']) ?>
                                </span>
                                <?php if (!empty($product['discount_price'])): ?>
                                    <span class="price-original"><?= format_currency($product['price']) ?></span>
                                <?php endif; ?>
                            </div>

                            <form action="<?= base_url('/cart/add') ?>" method="POST" class="form-add-to-cart m-0">
                                <?= CSRF::field() ?>
                                <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
                                <input type="hidden" name="quantity" value="1">
                                <button type="submit" class="btn btn-outline-custom w-100 py-2 d-flex align-items-center justify-content-center gap-2">
                                    <i class="bi bi-bag-plus"></i> Add to Cart
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Promotional Trust Strip -->
    <section class="py-4 my-5 bg-white rounded-3 border">
        <div class="row g-4 text-center">
            <div class="col-md-3 col-6">
                <i class="bi bi-truck fs-2 text-primary mb-2"></i>
                <h6 class="fw-bold mb-1">Complimentary Delivery</h6>
                <p class="text-muted small m-0">On all orders over <?= format_currency(Setting::get('free_shipping_threshold', 150)) ?></p>
            </div>
            <div class="col-md-3 col-6">
                <i class="bi bi-shield-check fs-2 text-primary mb-2"></i>
                <h6 class="fw-bold mb-1">Encrypted Security</h6>
                <p class="text-muted small m-0">256-Bit SSL level transaction protection</p>
            </div>
            <div class="col-md-3 col-6">
                <i class="bi bi-arrow-repeat fs-2 text-primary mb-2"></i>
                <h6 class="fw-bold mb-1">30-Day Guarantee</h6>
                <p class="text-muted small m-0">Hassle-free return policy on all hardware</p>
            </div>
            <div class="col-md-3 col-6">
                <i class="bi bi-headset fs-2 text-primary mb-2"></i>
                <h6 class="fw-bold mb-1">Dedicated Concierge</h6>
                <p class="text-muted small m-0">Direct 24/7 client support assistance</p>
            </div>
        </div>
    </section>
</div>
