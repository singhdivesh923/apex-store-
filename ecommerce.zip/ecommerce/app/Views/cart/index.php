<?php
use App\Models\Setting;
use App\Services\CSRF;
?>

<div class="container py-4">
    <h1 class="h3 fw-bold mb-4">Your Shopping Cart</h1>

    <?php if (empty($cart['items'])): ?>
        <div class="bg-white p-5 rounded-3 border text-center my-4">
            <i class="bi bi-bag-x fs-1 text-muted mb-3 d-block"></i>
            <h3 class="fw-bold">Your cart is currently empty</h3>
            <p class="text-muted">Explore our curated collections and add your favorite items to your cart.</p>
            <a href="<?= base_url('/catalog') ?>" class="btn btn-primary-custom mt-2 px-4">Start Shopping</a>
        </div>
    <?php else: ?>
        <div class="row g-4">
            <!-- Line Items Table -->
            <div class="col-lg-8">
                <div class="bg-white rounded-3 border overflow-hidden p-3 p-md-4 mb-4">
                    <div class="table-responsive">
                        <table class="table align-middle m-0">
                            <thead>
                                <tr class="text-uppercase small text-muted border-bottom">
                                    <th scope="col" style="min-width: 260px;">Product</th>
                                    <th scope="col" class="text-center">Price</th>
                                    <th scope="col" class="text-center" style="width: 140px;">Quantity</th>
                                    <th scope="col" class="text-end">Subtotal</th>
                                    <th scope="col" class="text-end" style="width: 50px;"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cart['items'] as $item): ?>
                                    <tr>
                                        <!-- Product Info -->
                                        <td>
                                            <div class="d-flex align-items-center gap-3">
                                                <img src="<?= e($item['primary_image'] ?: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=150&q=80') ?>" alt="<?= e($item['name']) ?>" class="rounded-2 border" style="width: 64px; height: 64px; object-fit: cover;">
                                                <div>
                                                    <a href="<?= base_url('/product/' . urlencode($item['slug'])) ?>" class="fw-bold text-dark text-decoration-none">
                                                        <?= e($item['name']) ?>
                                                    </a>
                                                    <div class="text-muted small">SKU: <?= e($item['sku']) ?></div>
                                                    <?php if ($item['exceeds_stock']): ?>
                                                        <span class="badge bg-danger small">Only <?= (int)$item['stock_quantity'] ?> in stock</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>

                                        <!-- Unit Price -->
                                        <td class="text-center fw-semibold text-secondary">
                                            <?= format_currency($item['unit_price']) ?>
                                        </td>

                                        <!-- Quantity Controls -->
                                        <td class="text-center">
                                            <form action="<?= base_url('/cart/update') ?>" method="POST" class="d-flex justify-content-center m-0">
                                                <?= CSRF::field() ?>
                                                <input type="hidden" name="product_id" value="<?= (int)$item['product_id'] ?>">
                                                <input type="number" name="quantity" class="form-control form-control-sm text-center cart-qty-input" style="width: 75px;" value="<?= (int)$item['quantity'] ?>" min="1" max="<?= (int)$item['stock_quantity'] ?>">
                                            </form>
                                        </td>

                                        <!-- Line Total -->
                                        <td class="text-end fw-bold text-dark">
                                            <?= format_currency($item['line_total']) ?>
                                        </td>

                                        <!-- Remove Item -->
                                        <td class="text-end">
                                            <form action="<?= base_url('/cart/remove') ?>" method="POST" class="m-0">
                                                <?= CSRF::field() ?>
                                                <input type="hidden" name="product_id" value="<?= (int)$item['product_id'] ?>">
                                                <button type="submit" class="btn btn-sm btn-link text-danger p-0" title="Remove Item">
                                                    <i class="bi bi-trash fs-5"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Coupon Box -->
                <div class="bg-white p-4 rounded-3 border">
                    <h5 class="fw-bold mb-3"><i class="bi bi-tag me-2 text-primary"></i> Promotion or Coupon Code</h5>
                    <?php if (!empty($cart['coupon'])): ?>
                        <div class="alert alert-success d-flex justify-content-between align-items-center m-0 py-2">
                            <div>
                                <i class="bi bi-check-circle-fill me-2"></i>
                                Code <strong><?= e($cart['coupon']['code']) ?></strong> applied:
                                <?= $cart['coupon']['type'] === 'percentage' ? (float)$cart['coupon']['discount_value'] . '% off' : format_currency($cart['coupon']['discount_value']) . ' off' ?>
                            </div>
                            <form action="<?= base_url('/cart/coupon/remove') ?>" method="POST" class="m-0">
                                <?= CSRF::field() ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger">Remove</button>
                            </form>
                        </div>
                    <?php else: ?>
                        <form action="<?= base_url('/cart/coupon') ?>" method="POST" class="d-flex gap-2">
                            <?= CSRF::field() ?>
                            <input type="text" name="coupon_code" class="form-control text-uppercase" placeholder="Enter coupon code (e.g. WELCOME10)" required style="max-width: 300px;">
                            <button type="submit" class="btn btn-outline-custom">Apply Code</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Order Financial Summary -->
            <div class="col-lg-4">
                <div class="bg-white p-4 rounded-3 border position-sticky" style="top: 90px;">
                    <h5 class="fw-bold mb-3 border-bottom pb-2">Order Summary</h5>

                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Subtotal</span>
                        <span class="fw-semibold text-dark"><?= format_currency($cart['subtotal']) ?></span>
                    </div>

                    <?php if ($cart['discount'] > 0): ?>
                        <div class="d-flex justify-content-between mb-2 text-success">
                            <span>Promotion Discount</span>
                            <span>-<?= format_currency($cart['discount']) ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Shipping</span>
                        <span class="fw-semibold text-dark">
                            <?= $cart['shipping'] == 0 ? '<span class="text-success">Complimentary</span>' : format_currency($cart['shipping']) ?>
                        </span>
                    </div>

                    <div class="d-flex justify-content-between mb-3">
                        <span class="text-muted">Estimated Tax (<?= $cart['tax_percent'] ?>%)</span>
                        <span class="fw-semibold text-dark"><?= format_currency($cart['tax']) ?></span>
                    </div>

                    <div class="border-top pt-3 mb-4 d-flex justify-content-between align-items-baseline">
                        <span class="h5 fw-bold m-0">Total</span>
                        <span class="h4 fw-bold text-primary m-0"><?= format_currency($cart['grand_total']) ?></span>
                    </div>

                    <a href="<?= base_url('/checkout') ?>" class="btn btn-primary-custom w-100 py-3 fw-bold d-flex align-items-center justify-content-center gap-2">
                        <i class="bi bi-lock-fill"></i> Proceed to Checkout
                    </a>

                    <div class="text-center mt-3">
                        <a href="<?= base_url('/catalog') ?>" class="small text-muted text-decoration-none">
                            <i class="bi bi-arrow-left me-1"></i> Continue Shopping
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
