<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="h3 fw-bold mb-3">Returns & Refund Policy</h1>
            <p class="text-muted mb-4">Last revised: October 2026</p>

            <div class="bg-white p-4 p-md-5 rounded-3 border lh-lg text-secondary">
                <h5 class="fw-bold text-dark">1. 30-Day Money-Back Guarantee</h5>
                <p>We believe wholeheartedly in the build quality of our products. If you are not entirely satisfied with your purchase, you may initiate a return within 30 calendar days of delivery for a complete refund or exchange.</p>

                <h5 class="fw-bold text-dark mt-4">2. Eligible Item Condition</h5>
                <p>Merchandise must be returned in like-new physical condition, including original product packaging, documentation, cables, and bundled accessories.</p>

                <h5 class="fw-bold text-dark mt-4">3. Refund Processing</h5>
                <p>Once your returned item is received and inspected at our fulfillment depot, your refund is credited back to the original method of payment within 3 business days.</p>
            </div>
        </div>
    </div>
</div>
