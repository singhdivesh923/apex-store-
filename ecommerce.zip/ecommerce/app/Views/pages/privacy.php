<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="h3 fw-bold mb-3">Privacy & Data Protection Policy</h1>
            <p class="text-muted mb-4">Last revised: October 2026</p>

            <div class="bg-white p-4 p-md-5 rounded-3 border lh-lg text-secondary">
                <h5 class="fw-bold text-dark">1. Privacy Commitment</h5>
                <p>We respect customer privacy and are committed to safeguarding personal information. We never sell, monetize, or lease your private data to third-party brokers.</p>

                <h5 class="fw-bold text-dark mt-4">2. Payment Security & Zero Card Storage</h5>
                <p>We do not store or process raw debit or credit card numbers, CVVs, or bank credentials on our servers. All sensitive financial transactions are securely tokenized through certified, PCI-DSS compliant payment gateways.</p>

                <h5 class="fw-bold text-dark mt-4">3. Cookie & Session Policy</h5>
                <p>We utilize secure, HttpOnly, SameSite session cookies solely to preserve your active login session, cart contents, and protect forms against cross-site request forgery (CSRF).</p>
            </div>
        </div>
    </div>
</div>
