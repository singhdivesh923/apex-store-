<?php
use App\Models\Setting;
?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="h3 fw-bold mb-3">Shipping & Delivery Information</h1>
            <p class="text-muted mb-4">Last revised: October 2026</p>

            <div class="bg-white p-4 p-md-5 rounded-3 border lh-lg text-secondary">
                <h5 class="fw-bold text-dark">1. Complimentary Shipping</h5>
                <p>We provide complimentary priority courier delivery on all orders with a subtotal exceeding <strong><?= format_currency(Setting::get('free_shipping_threshold', 150)) ?></strong>. Standard orders below this threshold incur a flat delivery charge of <?= format_currency(Setting::get('flat_shipping_rate', 15)) ?>.</p>

                <h5 class="fw-bold text-dark mt-4">2. Dispatch & Order Handling</h5>
                <p>Orders received before 2:00 PM EST Monday through Friday are dispatched on the same business day from our primary fulfillment centers. Orders placed over weekends or observed national holidays are processed on the subsequent business morning.</p>

                <h5 class="fw-bold text-dark mt-4">3. Courier Partners & Tracking</h5>
                <p>Shipments are dispatched with full transit insurance via DHL Express, FedEx, or UPS Priority. A tracked shipment reference is provided to you as soon as the courier scans your parcel.</p>
            </div>
        </div>
    </div>
</div>
