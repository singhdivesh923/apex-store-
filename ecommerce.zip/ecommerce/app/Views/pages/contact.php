<?php
use App\Models\Setting;
use App\Services\CSRF;
?>

<div class="container py-5">
    <div class="row g-5">
        <div class="col-lg-5">
            <h1 class="h3 fw-bold mb-3">Customer Support & Concierge</h1>
            <p class="text-secondary mb-4">
                Have questions regarding orders, product compatibility, or corporate partnerships? Our dedicated support team is available Monday through Saturday.
            </p>

            <div class="d-flex flex-column gap-3 mb-4">
                <div class="d-flex align-items-start gap-3">
                    <div class="p-2 bg-primary bg-opacity-10 text-primary rounded-circle"><i class="bi bi-geo-alt fs-5"></i></div>
                    <div>
                        <div class="fw-bold">Headquarters</div>
                        <div class="small text-muted"><?= e(Setting::get('store_address', '100 Innovation Blvd, Suite 400, San Francisco, CA')) ?></div>
                    </div>
                </div>

                <div class="d-flex align-items-start gap-3">
                    <div class="p-2 bg-primary bg-opacity-10 text-primary rounded-circle"><i class="bi bi-envelope fs-5"></i></div>
                    <div>
                        <div class="fw-bold">Client Support Email</div>
                        <div class="small text-muted"><?= e(Setting::get('store_email', 'support@apexstore.com')) ?></div>
                    </div>
                </div>

                <div class="d-flex align-items-start gap-3">
                    <div class="p-2 bg-primary bg-opacity-10 text-primary rounded-circle"><i class="bi bi-telephone fs-5"></i></div>
                    <div>
                        <div class="fw-bold">Telephone Inquiries</div>
                        <div class="small text-muted"><?= e(Setting::get('store_phone', '+1 (800) 555-0199')) ?> (9am - 6pm PST)</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-7">
            <div class="bg-white p-4 p-md-5 rounded-3 border shadow-sm">
                <h4 class="fw-bold mb-3">Send Us a Direct Message</h4>
                <form action="<?= base_url('/contact') ?>" method="POST">
                    <?= CSRF::field() ?>

                    <!-- Anti-spam Honeypot (hidden from human users) -->
                    <div style="display:none !important;" aria-hidden="true">
                        <input type="text" name="website_hp" tabindex="-1" autocomplete="off">
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Your Name</label>
                            <input type="text" name="name" class="form-control" placeholder="John Doe" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="john@example.com" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Subject</label>
                            <input type="text" name="subject" class="form-control" placeholder="e.g. Order Inquiry / Shipping Status" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Your Message</label>
                            <textarea name="message" rows="5" class="form-control" placeholder="How can we assist you today?" required></textarea>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary-custom px-4 py-2">
                        <i class="bi bi-send me-1"></i> Send Message
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
