<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>500 - Server Error</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="/assets/css/storefront.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center min-vh-100">
<div class="container text-center py-5">
    <div class="p-4 p-md-5 bg-white rounded-4 border shadow-sm mx-auto" style="max-width: 600px;">
        <i class="bi bi-exclamation-octagon fs-1 text-danger mb-3 d-block" style="font-size: 4rem !important;"></i>
        <h1 class="display-4 fw-bold mb-2">500</h1>
        <h2 class="h4 fw-bold mb-3">Internal Server Error</h2>
        <p class="text-muted mb-4">
            An unexpected error occurred while processing your request. Our technical staff has been automatically alerted to this incident.
        </p>
        <div class="d-flex justify-content-center gap-3">
            <a href="/" class="btn btn-primary-custom px-4">Return to Homepage</a>
            <a href="/contact" class="btn btn-outline-custom px-4">Contact Support</a>
        </div>
    </div>
</div>
</body>
</html>
