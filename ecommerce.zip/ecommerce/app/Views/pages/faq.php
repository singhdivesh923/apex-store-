<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <h1 class="h3 fw-bold mb-3 text-center">Frequently Asked Questions</h1>
            <p class="text-muted text-center mb-5">Find rapid answers to common questions about shipping, warranties, returns, and order fulfillment.</p>

            <div class="accordion border rounded-3 overflow-hidden" id="faqAccordion">
                <div class="accordion-item border-0 border-bottom">
                    <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                            How long does shipping take?
                        </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary">
                            Standard priority courier transit typically takes 2 to 4 business days within the continental United States. International shipments arrive within 5 to 8 business days depending on customs clearance.
                        </div>
                    </div>
                </div>

                <div class="accordion-item border-0 border-bottom">
                    <h2 class="accordion-header" id="headingTwo">
                        <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
                            What is your return and exchange policy?
                        </button>
                    </h2>
                    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary">
                            We offer a 30-day money-back guarantee on all undamaged merchandise in its original packaging. Once we inspect the returned item, your full refund is processed within 3 business days.
                        </div>
                    </div>
                </div>

                <div class="accordion-item border-0 border-bottom">
                    <h2 class="accordion-header" id="headingThree">
                        <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree">
                            What payment methods do you support?
                        </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary">
                            We accept Cash on Delivery (COD) in eligible regions, along with major credit and debit cards (Visa, MasterCard, American Express), NetBanking, and UPI through our encrypted payment gateway.
                        </div>
                    </div>
                </div>

                <div class="accordion-item border-0">
                    <h2 class="accordion-header" id="headingFour">
                        <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour">
                            How can I track my order status?
                        </button>
                    </h2>
                    <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body text-secondary">
                            Registered customers can navigate to "My Orders" in the user account menu at any time to monitor dispatch status. For guest checkouts, tracking updates are sent directly to the email provided during checkout.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
