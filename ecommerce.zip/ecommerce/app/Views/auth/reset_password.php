<?php
use App\Services\CSRF;
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="bg-white p-4 p-md-5 rounded-3 border shadow-sm">
                <div class="text-center mb-4">
                    <i class="bi bi-shield-lock fs-1 text-primary mb-2 d-block"></i>
                    <h1 class="h3 fw-bold">Set New Password</h1>
                    <p class="text-muted small">Choose a strong password with at least 8 characters.</p>
                </div>

                <form action="<?= base_url('/reset-password') ?>" method="POST">
                    <?= CSRF::field() ?>
                    <input type="hidden" name="token" value="<?= e($token) ?>">
                    <input type="hidden" name="email" value="<?= e($email) ?>">

                    <div class="mb-3">
                        <label for="newPass" class="form-label small fw-bold">New Password</label>
                        <input type="password" id="newPass" name="password" class="form-control" placeholder="Minimum 8 characters" minlength="8" required autofocus>
                    </div>

                    <div class="mb-3">
                        <label for="newPassConfirm" class="form-label small fw-bold">Confirm New Password</label>
                        <input type="password" id="newPassConfirm" name="password_confirmation" class="form-control" placeholder="Repeat new password" minlength="8" required>
                    </div>

                    <button type="submit" class="btn btn-primary-custom w-100 py-2 fw-semibold mt-2">
                        Update Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
