<?php
use App\Services\CSRF;
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="bg-white p-4 p-md-5 rounded-3 border shadow-sm">
                <div class="text-center mb-4">
                    <i class="bi bi-person-circle fs-1 text-primary mb-2 d-block"></i>
                    <h1 class="h3 fw-bold">Sign In</h1>
                    <p class="text-muted small">Access your account, track orders, and manage wishlist.</p>
                </div>

                <form action="<?= base_url('/login') ?>" method="POST">
                    <?= CSRF::field() ?>

                    <div class="mb-3">
                        <label for="loginEmail" class="form-label small fw-bold">Email Address</label>
                        <input type="email" id="loginEmail" name="email" class="form-control" placeholder="name@example.com" value="<?= e($_POST['email'] ?? '') ?>" required autofocus>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <label for="loginPassword" class="form-label small fw-bold m-0">Password</label>
                            <a href="<?= base_url('/forgot-password') ?>" class="small text-primary text-decoration-none">Forgot password?</a>
                        </div>
                        <input type="password" id="loginPassword" name="password" class="form-control mt-1" placeholder="Enter your password" required>
                    </div>

                    <button type="submit" class="btn btn-primary-custom w-100 py-2 fw-semibold mt-3">
                        Sign In to Account
                    </button>
                </form>

                <hr class="my-4">

                <div class="text-center small text-muted">
                    Don't have an account yet? 
                    <a href="<?= base_url('/register') ?>" class="text-primary fw-bold text-decoration-none">Create Account</a>
                </div>

                <?php if (env('APP_ENV') !== 'production' && env('APP_DEBUG')): ?>
                <div class="mt-4 p-3 bg-light rounded-2 border small text-muted">
                    <strong>Demo Customer Credentials (Development Only):</strong><br>
                    Email: <code>customer@apexstore.com</code><br>
                    Password: <code>Customer@12345</code>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
