<?php
use App\Services\CSRF;
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-6">
            <div class="bg-white p-4 p-md-5 rounded-3 border shadow-sm">
                <div class="text-center mb-4">
                    <i class="bi bi-person-plus fs-1 text-primary mb-2 d-block"></i>
                    <h1 class="h3 fw-bold">Create Account</h1>
                    <p class="text-muted small">Sign up to enjoy express checkout, order history, and exclusive benefits.</p>
                </div>

                <form action="<?= base_url('/register') ?>" method="POST">
                    <?= CSRF::field() ?>

                    <div class="mb-3">
                        <label for="regName" class="form-label small fw-bold">Full Name</label>
                        <input type="text" id="regName" name="name" class="form-control" placeholder="John Doe" value="<?= e($_POST['name'] ?? '') ?>" required autofocus>
                    </div>

                    <div class="mb-3">
                        <label for="regEmail" class="form-label small fw-bold">Email Address</label>
                        <input type="email" id="regEmail" name="email" class="form-control" placeholder="name@example.com" value="<?= e($_POST['email'] ?? '') ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="regPhone" class="form-label small fw-bold">Phone Number (Optional)</label>
                        <input type="tel" id="regPhone" name="phone" class="form-control" placeholder="+1 (555) 000-0000" value="<?= e($_POST['phone'] ?? '') ?>">
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label for="regPassword" class="form-label small fw-bold">Password (min 8 chars)</label>
                            <input type="password" id="regPassword" name="password" class="form-control" placeholder="Create password" minlength="8" required>
                        </div>
                        <div class="col-md-6">
                            <label for="regPasswordConfirm" class="form-label small fw-bold">Confirm Password</label>
                            <input type="password" id="regPasswordConfirm" name="password_confirmation" class="form-control" placeholder="Repeat password" minlength="8" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary-custom w-100 py-2 fw-semibold mt-3">
                        Create Account
                    </button>
                </form>

                <hr class="my-4">

                <div class="text-center small text-muted">
                    Already registered? 
                    <a href="<?= base_url('/login') ?>" class="text-primary fw-bold text-decoration-none">Sign In Here</a>
                </div>
            </div>
        </div>
    </div>
</div>
