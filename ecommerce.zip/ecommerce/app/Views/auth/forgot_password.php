<?php
use App\Services\CSRF;
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="bg-white p-4 p-md-5 rounded-3 border shadow-sm">
                <div class="text-center mb-4">
                    <i class="bi bi-key fs-1 text-primary mb-2 d-block"></i>
                    <h1 class="h3 fw-bold">Reset Password</h1>
                    <p class="text-muted small">Enter your account email address and we'll send a secure password reset link.</p>
                </div>

                <form action="<?= base_url('/forgot-password') ?>" method="POST">
                    <?= CSRF::field() ?>

                    <div class="mb-3">
                        <label for="resetEmail" class="form-label small fw-bold">Email Address</label>
                        <input type="email" id="resetEmail" name="email" class="form-control" placeholder="name@example.com" required autofocus>
                    </div>

                    <button type="submit" class="btn btn-primary-custom w-100 py-2 fw-semibold mt-2">
                        Send Reset Link
                    </button>
                </form>

                <hr class="my-4">

                <div class="text-center small">
                    <a href="<?= base_url('/login') ?>" class="text-secondary text-decoration-none">&larr; Return to Sign In</a>
                </div>
            </div>
        </div>
    </div>
</div>
