<?php
use App\Services\CSRF;

$isCancellable = in_array($order['status'], ['pending', 'confirmed'], true);
?>

<div class="container py-4">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb small">
            <li class="breadcrumb-item"><a href="<?= base_url('/account/orders') ?>">My Orders</a></li>
            <li class="breadcrumb-item active"><?= e($order['order_number']) ?></li>
        </ol>
    </nav>

    <div class="bg-white p-4 p-md-5 rounded-3 border mb-4">
        <!-- Header -->
        <div class="d-flex flex-wrap justify-content-between align-items-center border-bottom pb-4 mb-4">
            <div>
                <span class="small text-muted text-uppercase fw-bold">Order Details</span>
                <h1 class="h3 fw-bold font-monospace text-primary mb-1">#<?= e($order['order_number']) ?></h1>
                <span class="small text-muted">Placed on <?= date('F d, Y \a\t h:i A', strtotime($order['created_at'])) ?></span>
            </div>
            <div class="d-flex align-items-center gap-2 mt-3 mt-sm-0">
                <span class="badge badge-status badge-status-<?= e($order['status']) ?> fs-6 py-2 px-3">
                    Status: <?= ucfirst(e($order['status'])) ?>
                </span>
                <?php if ($isCancellable): ?>
                    <form action="<?= base_url('/account/orders/' . urlencode($order['order_number']) . '/cancel') ?>" method="POST" class="m-0" onsubmit="return confirm('Are you sure you wish to cancel this order? Any reserved inventory will be restored.');">
                        <?= CSRF::field() ?>
                        <button type="submit" class="btn btn-outline-danger btn-sm">Cancel Order</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>

        <div class="row g-4 mb-4">
            <!-- Delivery Destination -->
            <div class="col-md-6">
                <div class="p-3 bg-light rounded-3 border h-100">
                    <h6 class="fw-bold small text-uppercase text-muted mb-2"><i class="bi bi-geo-alt text-primary me-1"></i> Shipping Address</h6>
                    <div class="fw-bold"><?= e($order['shipping_address']['recipient_name'] ?? '') ?></div>
                    <div class="small text-muted"><?= e($order['shipping_address']['address_line1'] ?? '') ?></div>
                    <?php if (!empty($order['shipping_address']['address_line2'])): ?>
                        <div class="small text-muted"><?= e($order['shipping_address']['address_line2']) ?></div>
                    <?php endif; ?>
                    <div class="small text-muted"><?= e($order['shipping_address']['city'] ?? '') ?>, <?= e($order['shipping_address']['state'] ?? '') ?> <?= e($order['shipping_address']['postal_code'] ?? '') ?></div>
                    <div class="small text-muted">Phone: <?= e($order['shipping_address']['phone'] ?? '') ?></div>
                </div>
            </div>

            <!-- Payment Summary -->
            <div class="col-md-6">
                <div class="p-3 bg-light rounded-3 border h-100">
                    <h6 class="fw-bold small text-uppercase text-muted mb-2"><i class="bi bi-credit-card text-primary me-1"></i> Payment Information</h6>
                    <div class="d-flex justify-content-between mb-1 small">
                        <span class="text-muted">Method:</span>
                        <span class="fw-semibold text-uppercase"><?= e($order['payment_method']) ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-1 small">
                        <span class="text-muted">Payment Status:</span>
                        <span class="badge badge-status badge-status-<?= e($order['payment_status']) ?>">
                            <?= ucfirst(e($order['payment_status'])) ?>
                        </span>
                    </div>
                    <?php if (!empty($order['customer_notes'])): ?>
                        <div class="mt-2 pt-2 border-top small text-muted">
                            <strong>Order Notes:</strong> <?= e($order['customer_notes']) ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Order Items Table -->
        <h5 class="fw-bold mb-3">Purchased Items</h5>
        <div class="table-responsive border rounded-3 mb-4">
            <table class="table align-middle m-0">
                <thead class="bg-light">
                    <tr class="small text-uppercase text-muted">
                        <th>Product Details</th>
                        <th class="text-center">SKU</th>
                        <th class="text-center">Unit Price Snapshot</th>
                        <th class="text-center">Quantity</th>
                        <th class="text-end">Line Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($order['items'] as $item): ?>
                        <tr>
                            <td class="fw-semibold"><?= e($item['product_name']) ?></td>
                            <td class="text-center small font-monospace text-muted"><?= e($item['product_sku']) ?></td>
                            <td class="text-center small"><?= format_currency($item['unit_price']) ?></td>
                            <td class="text-center small"><?= (int)$item['quantity'] ?></td>
                            <td class="text-end fw-bold"><?= format_currency($item['subtotal']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Totals Calculation -->
        <div class="row justify-content-end">
            <div class="col-md-5">
                <div class="d-flex justify-content-between mb-2 small">
                    <span class="text-muted">Subtotal:</span>
                    <span><?= format_currency($order['subtotal']) ?></span>
                </div>
                <?php if ($order['discount_amount'] > 0): ?>
                    <div class="d-flex justify-content-between mb-2 small text-success">
                        <span>Coupon Discount (<?= e($order['coupon_code'] ?? 'PROMO') ?>):</span>
                        <span>-<?= format_currency($order['discount_amount']) ?></span>
                    </div>
                <?php endif; ?>
                <div class="d-flex justify-content-between mb-2 small">
                    <span class="text-muted">Shipping Fee:</span>
                    <span><?= (float)$order['shipping_amount'] == 0 ? '<span class="text-success">Free</span>' : format_currency($order['shipping_amount']) ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2 small">
                    <span class="text-muted">Tax Amount:</span>
                    <span><?= format_currency($order['tax_amount']) ?></span>
                </div>
                <div class="d-flex justify-content-between border-top pt-2">
                    <span class="h5 fw-bold m-0">Order Total:</span>
                    <span class="h5 fw-bold text-primary m-0"><?= format_currency($order['total_amount']) ?></span>
                </div>
            </div>
        </div>
    </div>
</div>
