<?php
use App\Services\CSRF;
?>

<div class="container py-4">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb small">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Home</a></li>
            <li class="breadcrumb-item active">My Orders</li>
        </ol>
    </nav>

    <div class="row g-4">
        <!-- Account Sidebar -->
        <div class="col-lg-3">
            <div class="bg-white p-3 rounded-3 border">
                <div class="nav flex-column nav-pills gap-1">
                    <a class="nav-link active" href="<?= base_url('/account/orders') ?>"><i class="bi bi-box-seam me-2"></i> My Orders</a>
                    <a class="nav-link" href="<?= base_url('/account/profile') ?>"><i class="bi bi-person me-2"></i> Profile & Password</a>
                    <a class="nav-link" href="<?= base_url('/account/addresses') ?>"><i class="bi bi-geo-alt me-2"></i> Address Book</a>
                    <a class="nav-link" href="<?= base_url('/wishlist') ?>"><i class="bi bi-heart me-2"></i> Saved Wishlist</a>
                </div>
            </div>
        </div>

        <!-- Orders List -->
        <div class="col-lg-9">
            <div class="bg-white p-4 rounded-3 border">
                <h1 class="h4 fw-bold mb-3">Order History & Tracking</h1>

                <?php if (empty($orders)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-bag-check fs-1 text-muted mb-2 d-block"></i>
                        <h5 class="fw-bold">No orders placed yet</h5>
                        <p class="text-muted small">When you complete an order, its fulfillment status will appear here.</p>
                        <a href="<?= base_url('/catalog') ?>" class="btn btn-primary-custom btn-sm px-3 mt-2">Explore Products</a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table align-middle m-0">
                            <thead>
                                <tr class="text-uppercase small text-muted border-bottom">
                                    <th scope="col">Order Reference</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Payment</th>
                                    <th scope="col" class="text-end">Total</th>
                                    <th scope="col" class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td>
                                            <a href="<?= base_url('/account/orders/' . urlencode($order['order_number'])) ?>" class="fw-bold text-primary font-monospace text-decoration-none">
                                                <?= e($order['order_number']) ?>
                                            </a>
                                            <div class="small text-muted"><?= (int)$order['item_count'] ?> item(s)</div>
                                        </td>
                                        <td class="small text-muted">
                                            <?= date('M d, Y', strtotime($order['created_at'])) ?>
                                        </td>
                                        <td>
                                            <span class="badge badge-status badge-status-<?= e($order['status']) ?>">
                                                <?= ucfirst(e($order['status'])) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge badge-status badge-status-<?= e($order['payment_status']) ?>">
                                                <?= ucfirst(e($order['payment_status'])) ?>
                                            </span>
                                        </td>
                                        <td class="text-end fw-bold text-dark">
                                            <?= format_currency($order['total_amount']) ?>
                                        </td>
                                        <td class="text-end">
                                            <a href="<?= base_url('/account/orders/' . urlencode($order['order_number'])) ?>" class="btn btn-sm btn-outline-custom">
                                                Details &rarr;
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
