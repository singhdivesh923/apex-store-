<?php
use App\Services\CSRF;
?>

<div class="container py-4">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb small">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Home</a></li>
            <li class="breadcrumb-item active">My Wishlist</li>
        </ol>
    </nav>

    <div class="row g-4">
        <!-- Account Sidebar -->
        <div class="col-lg-3">
            <div class="bg-white p-3 rounded-3 border">
                <div class="nav flex-column nav-pills gap-1">
                    <a class="nav-link" href="<?= base_url('/account/orders') ?>"><i class="bi bi-box-seam me-2"></i> My Orders</a>
                    <a class="nav-link" href="<?= base_url('/account/profile') ?>"><i class="bi bi-person me-2"></i> Profile & Password</a>
                    <a class="nav-link" href="<?= base_url('/account/addresses') ?>"><i class="bi bi-geo-alt me-2"></i> Address Book</a>
                    <a class="nav-link active" href="<?= base_url('/wishlist') ?>"><i class="bi bi-heart me-2"></i> Saved Wishlist</a>
                </div>
            </div>
        </div>

        <div class="col-lg-9">
            <div class="bg-white p-4 rounded-3 border">
                <h1 class="h4 fw-bold mb-4">Saved Wishlist Items</h1>

                <?php if (empty($items)): ?>
                    <div class="text-center py-5 text-muted">
                        <i class="bi bi-heart fs-1 d-block mb-2"></i>
                        <h5>Your wishlist is currently empty</h5>
                        <p class="small">Tap the heart icon on any product to bookmark items for later.</p>
                        <a href="<?= base_url('/catalog') ?>" class="btn btn-primary-custom btn-sm mt-2">Explore Catalog</a>
                    </div>
                <?php else: ?>
                    <div class="row g-3">
                        <?php foreach ($items as $item): ?>
                            <div class="col-md-6">
                                <div class="product-card">
                                    <div class="product-image-wrap">
                                        <a href="<?= base_url('/product/' . urlencode($item['slug'])) ?>">
                                            <img src="<?= e($item['primary_image'] ?: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80') ?>" alt="<?= e($item['name']) ?>">
                                        </a>
                                        <form action="<?= base_url('/wishlist/remove') ?>" method="POST" class="m-0">
                                            <?= CSRF::field() ?>
                                            <input type="hidden" name="product_id" value="<?= (int)$item['product_id'] ?>">
                                            <button type="submit" class="btn-wishlist-toggle active" title="Remove from wishlist">
                                                <i class="bi bi-x-lg"></i>
                                            </button>
                                        </form>
                                    </div>
                                    <div class="product-card-body">
                                        <a href="<?= base_url('/product/' . urlencode($item['slug'])) ?>" class="product-title">
                                            <?= e($item['name']) ?>
                                        </a>
                                        <div class="product-price-row mb-3">
                                            <span class="price-current"><?= format_currency($item['discount_price'] ?: $item['price']) ?></span>
                                        </div>
                                        <form action="<?= base_url('/cart/add') ?>" method="POST" class="form-add-to-cart m-0">
                                            <?= CSRF::field() ?>
                                            <input type="hidden" name="product_id" value="<?= (int)$item['product_id'] ?>">
                                            <input type="hidden" name="quantity" value="1">
                                            <button type="submit" class="btn btn-primary-custom w-100 py-2 d-flex align-items-center justify-content-center gap-2">
                                                <i class="bi bi-bag-plus"></i> Move to Cart
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
