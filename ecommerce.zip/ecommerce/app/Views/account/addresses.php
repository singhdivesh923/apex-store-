<?php
use App\Services\CSRF;
?>

<div class="container py-4">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb small">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('/account/orders') ?>">Account</a></li>
            <li class="breadcrumb-item active">Addresses</li>
        </ol>
    </nav>

    <div class="row g-4">
        <!-- Account Sidebar -->
        <div class="col-lg-3">
            <div class="bg-white p-3 rounded-3 border">
                <div class="nav flex-column nav-pills gap-1">
                    <a class="nav-link" href="<?= base_url('/account/orders') ?>"><i class="bi bi-box-seam me-2"></i> My Orders</a>
                    <a class="nav-link" href="<?= base_url('/account/profile') ?>"><i class="bi bi-person me-2"></i> Profile & Password</a>
                    <a class="nav-link active" href="<?= base_url('/account/addresses') ?>"><i class="bi bi-geo-alt me-2"></i> Address Book</a>
                    <a class="nav-link" href="<?= base_url('/wishlist') ?>"><i class="bi bi-heart me-2"></i> Saved Wishlist</a>
                </div>
            </div>
        </div>

        <div class="col-lg-9">
            <div class="bg-white p-4 rounded-3 border">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h4 fw-bold m-0">Saved Address Book</h1>
                    <button class="btn btn-primary-custom btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#newAddressCollapse">
                        <i class="bi bi-plus-lg me-1"></i> Add New Address
                    </button>
                </div>

                <!-- Add New Address Form -->
                <div class="collapse mb-4" id="newAddressCollapse">
                    <div class="card card-body bg-light border p-4">
                        <h5 class="fw-bold mb-3">Add Shipping / Billing Address</h5>
                        <form action="<?= base_url('/account/addresses') ?>" method="POST">
                            <?= CSRF::field() ?>

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Recipient Name</label>
                                    <input type="text" name="recipient_name" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">Phone Number</label>
                                    <input type="tel" name="phone" class="form-control" required>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold">Street Address</label>
                                    <input type="text" name="address_line1" class="form-control" placeholder="123 Main St" required>
                                </div>
                                <div class="col-12">
                                    <label class="form-label small fw-bold">Address Line 2 (Optional)</label>
                                    <input type="text" name="address_line2" class="form-control" placeholder="Suite, Apt #">
                                </div>
                                <div class="col-md-5">
                                    <label class="form-label small fw-bold">City</label>
                                    <input type="text" name="city" class="form-control" required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label small fw-bold">State / Province</label>
                                    <input type="text" name="state" class="form-control" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold">Postal Code</label>
                                    <input type="text" name="postal_code" class="form-control" required>
                                </div>
                                <div class="col-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="is_default" value="1" id="isDefCheck">
                                        <label class="form-check-label small" for="isDefCheck">Set as primary default address</label>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary-custom btn-sm mt-3 px-4">Save Address</button>
                        </form>
                    </div>
                </div>

                <!-- Addresses Cards Grid -->
                <?php if (empty($addresses)): ?>
                    <p class="text-muted text-center py-4">You have no saved addresses yet.</p>
                <?php else: ?>
                    <div class="row g-3">
                        <?php foreach ($addresses as $addr): ?>
                            <div class="col-md-6">
                                <div class="p-3 bg-light rounded-3 border h-100 position-relative">
                                    <?php if ($addr['is_default']): ?>
                                        <span class="badge bg-primary position-absolute top-0 end-0 m-3">Default</span>
                                    <?php endif; ?>
                                    <h6 class="fw-bold mb-1"><?= e($addr['recipient_name']) ?></h6>
                                    <div class="small text-muted mb-2"><?= e($addr['phone']) ?></div>
                                    <div class="small text-secondary mb-3">
                                        <?= e($addr['address_line1']) ?><br>
                                        <?php if (!empty($addr['address_line2'])): ?>
                                            <?= e($addr['address_line2']) ?><br>
                                        <?php endif; ?>
                                        <?= e($addr['city']) ?>, <?= e($addr['state']) ?> <?= e($addr['postal_code']) ?><br>
                                        <?= e($addr['country']) ?>
                                    </div>

                                    <form action="<?= base_url('/account/addresses/delete/' . (int)$addr['id']) ?>" method="POST" class="m-0" onsubmit="return confirm('Delete this address?');">
                                        <?= CSRF::field() ?>
                                        <button type="submit" class="btn btn-sm btn-link text-danger p-0 small">
                                            <i class="bi bi-trash me-1"></i> Delete Address
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
