<?php
use App\Services\CSRF;
?>

<div class="container py-4">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb small">
            <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url('/account/orders') ?>">Account</a></li>
            <li class="breadcrumb-item active">Profile</li>
        </ol>
    </nav>

    <div class="row g-4">
        <!-- Account Sidebar -->
        <div class="col-lg-3">
            <div class="bg-white p-3 rounded-3 border">
                <div class="nav flex-column nav-pills gap-1">
                    <a class="nav-link" href="<?= base_url('/account/orders') ?>"><i class="bi bi-box-seam me-2"></i> My Orders</a>
                    <a class="nav-link active" href="<?= base_url('/account/profile') ?>"><i class="bi bi-person me-2"></i> Profile & Password</a>
                    <a class="nav-link" href="<?= base_url('/account/addresses') ?>"><i class="bi bi-geo-alt me-2"></i> Address Book</a>
                    <a class="nav-link" href="<?= base_url('/wishlist') ?>"><i class="bi bi-heart me-2"></i> Saved Wishlist</a>
                </div>
            </div>
        </div>

        <div class="col-lg-9">
            <div class="bg-white p-4 rounded-3 border">
                <h1 class="h4 fw-bold mb-4">Account Profile Information</h1>

                <form action="<?= base_url('/account/profile') ?>" method="POST">
                    <?= CSRF::field() ?>

                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Full Name</label>
                            <input type="text" name="name" class="form-control" value="<?= e($user['name']) ?>" required>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Email Address</label>
                            <input type="email" class="form-control bg-light" value="<?= e($user['email']) ?>" disabled>
                            <div class="form-text small">Email cannot be changed directly for security verification.</div>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Phone Number</label>
                            <input type="tel" name="phone" class="form-control" value="<?= e($user['phone'] ?? '') ?>">
                        </div>
                    </div>

                    <hr class="my-4">

                    <h5 class="fw-bold mb-3">Change Account Password</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Current Password</label>
                            <input type="password" name="current_password" class="form-control" placeholder="Enter current password">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">New Password (min 8 characters)</label>
                            <input type="password" name="new_password" class="form-control" placeholder="Leave blank to keep unchanged">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary-custom px-4">
                        Save Profile Changes
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
