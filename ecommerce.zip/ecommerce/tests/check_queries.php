<?php
declare(strict_types=1);

$dir = dirname(__DIR__) . '/app';
$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));

foreach ($iterator as $file) {
    if (!$file->isFile() || $file->getExtension() !== 'php') {
        continue;
    }

    $filePath = $file->getPathname();
    $content = file_get_contents($filePath);
    $relPath = str_replace(dirname(__DIR__) . DIRECTORY_SEPARATOR, '', $filePath);

    // Look for Database::(fetchOne|fetchAll|execute) calls
    $tokens = token_get_all($content);
    $count = count($tokens);

    for ($i = 0; $i < $count; $i++) {
        if (
            is_array($tokens[$i]) && $tokens[$i][0] === T_STRING && $tokens[$i][1] === 'Database' &&
            isset($tokens[$i+1]) && is_array($tokens[$i+1]) && $tokens[$i+1][0] === T_DOUBLE_COLON &&
            isset($tokens[$i+2]) && is_array($tokens[$i+2]) && in_array($tokens[$i+2][1], ['fetchOne', 'fetchAll', 'execute'])
        ) {
            $method = $tokens[$i+2][1];
            $line = $tokens[$i][2];

            $j = $i + 3;
            while ($j < $count && $tokens[$j] !== '(') $j++;
            if ($j >= $count) continue;

            $parenDepth = 1;
            $argTokens = [];
            $k = $j + 1;
            while ($k < $count && $parenDepth > 0) {
                if ($tokens[$k] === '(') $parenDepth++;
                elseif ($tokens[$k] === ')') $parenDepth--;
                if ($parenDepth > 0) {
                    $argTokens[] = $tokens[$k];
                }
                $k++;
            }

            // Split arguments by top-level comma
            $args = [];
            $currentArg = '';
            $pDepth = 0;
            $bDepth = 0;
            foreach ($argTokens as $t) {
                $str = is_array($t) ? $t[1] : $t;
                if ($str === '(') $pDepth++;
                elseif ($str === ')') $pDepth--;
                elseif ($str === '[') $bDepth++;
                elseif ($str === ']') $bDepth--;
                elseif ($str === ',' && $pDepth === 0 && $bDepth === 0) {
                    $args[] = trim($currentArg);
                    $currentArg = '';
                    continue;
                }
                $currentArg .= $str;
            }
            if (trim($currentArg) !== '') {
                $args[] = trim($currentArg);
            }

            $sqlArg = $args[0] ?? '';
            $paramsArg = $args[1] ?? '[]';

            // Find placeholders in SQL: :foo
            preg_match_all('/:([a-zA-Z0-9_]+)/', $sqlArg, $sqlMatches);
            $sqlPlaceholders = $sqlMatches[1];

            // Find keys in params: ':foo' => or 'foo' => or [':foo']
            preg_match_all('/[\'"](?::)?([a-zA-Z0-9_]+)[\'"]\s*=>/', $paramsArg, $paramMatches);
            $paramKeys = $paramMatches[1];

            // Check duplicate placeholders in SQL
            $sqlCounts = array_count_values($sqlPlaceholders);
            $duplicates = [];
            foreach ($sqlCounts as $ph => $c) {
                if ($c > 1) {
                    $duplicates[] = "$ph ($c times)";
                }
            }

            // Check mismatches if literal query and literal params array
            $missingInParams = array_diff(array_unique($sqlPlaceholders), $paramKeys);
            $extraInParams = array_diff(array_unique($paramKeys), $sqlPlaceholders);

            $hasIssue = false;
            $issueMsg = [];
            if (!empty($duplicates)) {
                $hasIssue = true;
                $issueMsg[] = "DUPLICATE SQL PLACEHOLDERS (breaks when emulate prepares is false): " . implode(', ', $duplicates);
            }
            if (!empty($missingInParams) && $paramsArg !== '[]' && strpos($paramsArg, '$') === false) {
                $hasIssue = true;
                $issueMsg[] = "PLACEHOLDER IN SQL MISSING IN PARAMS: " . implode(', ', $missingInParams);
            }
            if (!empty($extraInParams) && strpos($sqlArg, '$') === false) {
                $hasIssue = true;
                $issueMsg[] = "EXTRA KEY IN PARAMS NOT IN SQL: " . implode(', ', $extraInParams);
            }

            if ($hasIssue) {
                echo "ISSUE in $relPath:$line Database::$method\n";
                echo "  SQL: $sqlArg\n";
                echo "  PARAMS: $paramsArg\n";
                foreach ($issueMsg as $msg) {
                    echo "  -> $msg\n";
                }
                echo "\n";
            }
        }
    }
}
