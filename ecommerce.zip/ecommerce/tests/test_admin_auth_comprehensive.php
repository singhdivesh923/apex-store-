<?php
declare(strict_types=1);

/**
 * End-to-End HTTP Test for ApexStore Admin Authentication Flow
 */

class HttpAuthTest
{
    private string $baseUrl = 'http://localhost:8000';
    private ?string $cookie = null;

    public function run(): void
    {
        echo "\n=======================================================\n";
        echo "  Running ApexStore Admin Authentication HTTP Tests\n";
        echo "=======================================================\n\n";

        $this->testUnauthorizedDashboardAccess();
        $this->testFailedLoginWithInvalidPassword();
        $this->testCustomerAttemptingAdminLogin();
        $this->testSuccessfulAdminLoginAndDashboardAccess();
        $this->testAdminLogout();

        echo "\n=======================================================\n";
        echo "  All Authentication & Security Tests Passed!\n";
        echo "=======================================================\n\n";
    }

    private function request(string $method, string $path, array $data = [], bool $sendCookie = true): array
    {
        $ch = curl_init($this->baseUrl . $path);
        $headers = [];
        if ($sendCookie && $this->cookie) {
            $headers[] = 'Cookie: ' . $this->cookie;
        }

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $headers,
        ]);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        }

        $rawResponse = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        [$rawHeaders, $body] = explode("\r\n\r\n", $rawResponse, 2);

        // Update cookie if Set-Cookie header present
        if (preg_match('/Set-Cookie:\s*([^;]+);/i', $rawHeaders, $m)) {
            $this->cookie = $m[1];
        }

        // Extract Location header if redirect
        $location = null;
        if (preg_match('/Location:\s*([^\r\n]+)/i', $rawHeaders, $m)) {
            $location = trim($m[1]);
        }

        return [
            'code' => $httpCode,
            'headers' => $rawHeaders,
            'body' => $body,
            'location' => $location
        ];
    }

    private function getCsrfToken(string $body): string
    {
        if (preg_match('/name="csrf_token"\s+value="([^"]+)"/', $body, $m)) {
            return $m[1];
        }
        throw new RuntimeException("CSRF token not found in response body");
    }

    private function testUnauthorizedDashboardAccess(): void
    {
        echo "1. Testing Unauthenticated Access to /admin...\n";
        $this->cookie = null; // Clean session
        $res = $this->request('GET', '/admin', [], false);
        
        assert($res['code'] === 302, "Expected 302 redirect for unauthorized /admin access, got {$res['code']}");
        assert(str_contains($res['location'] ?? '', '/admin/login'), "Expected redirect to /admin/login");
        echo "  ✔ PASS: Unauthenticated access blocked and redirected to /admin/login\n\n";
    }

    private function testFailedLoginWithInvalidPassword(): void
    {
        echo "2. Testing Admin Login with Invalid Password...\n";
        $this->cookie = null; // Clean session
        $getRes = $this->request('GET', '/admin/login');
        $csrfToken = $this->getCsrfToken($getRes['body']);

        $postRes = $this->request('POST', '/admin/login', [
            'csrf_token' => $csrfToken,
            'email' => 'admin@apexstore.com',
            'password' => 'WrongPassword999!'
        ]);

        assert($postRes['code'] === 302, "Expected 302 redirect on failed login, got {$postRes['code']}");
        assert(str_contains($postRes['location'] ?? '', '/admin/login'), "Expected redirect back to /admin/login");

        // Follow redirect to see error alert
        $followRes = $this->request('GET', '/admin/login');
        assert(str_contains($followRes['body'], 'Invalid email address or password'), "Expected error flash message on login page");
        echo "  ✔ PASS: Invalid credentials rejected and flash error displayed on login page\n\n";
    }

    private function testCustomerAttemptingAdminLogin(): void
    {
        echo "3. Testing Non-Admin (Customer) Login into Admin Portal...\n";
        $this->cookie = null;
        $getRes = $this->request('GET', '/admin/login');
        $csrfToken = $this->getCsrfToken($getRes['body']);

        $postRes = $this->request('POST', '/admin/login', [
            'csrf_token' => $csrfToken,
            'email' => 'customer@apexstore.com',
            'password' => 'Customer@12345'
        ]);

        assert($postRes['code'] === 302, "Expected 302 redirect when non-admin attempts login");

        $followRes = $this->request('GET', '/admin/login');
        assert(str_contains($followRes['body'], 'Access denied') || str_contains($followRes['body'], 'permission'), "Expected Access Denied error");
        echo "  ✔ PASS: Customer account forbidden from admin portal with access denied message\n\n";
    }

    private function testSuccessfulAdminLoginAndDashboardAccess(): void
    {
        echo "4. Testing Valid Admin Login and Dashboard Session Persistence...\n";
        $this->cookie = null;
        $getRes = $this->request('GET', '/admin/login');
        $csrfToken = $this->getCsrfToken($getRes['body']);

        $postRes = $this->request('POST', '/admin/login', [
            'csrf_token' => $csrfToken,
            'email' => 'admin@apexstore.com',
            'password' => 'Admin@12345'
        ]);

        assert($postRes['code'] === 302, "Expected 302 redirect on successful login, got {$postRes['code']}");
        assert(str_contains($postRes['location'] ?? '', '/admin'), "Expected redirect to /admin");

        // Follow redirect to /admin dashboard
        $dashRes = $this->request('GET', '/admin');
        assert($dashRes['code'] === 200, "Expected 200 OK for admin dashboard, got {$dashRes['code']}");
        assert(str_contains($dashRes['body'], 'Dashboard') || str_contains($dashRes['body'], 'Overview') || str_contains($dashRes['body'], 'Administrator'), "Expected admin dashboard content");
        echo "  ✔ PASS: Successfully authenticated and accessed protected Admin Dashboard!\n\n";
    }

    private function testAdminLogout(): void
    {
        echo "5. Testing Admin Logout Flow...\n";
        $logoutRes = $this->request('GET', '/admin/logout');
        assert($logoutRes['code'] === 302, "Expected 302 redirect on logout");

        // After logout, accessing /admin should redirect back to /admin/login
        $dashRes = $this->request('GET', '/admin');
        assert($dashRes['code'] === 302, "Expected 302 redirect after logout when accessing /admin");
        assert(str_contains($dashRes['location'] ?? '', '/admin/login'), "Expected redirect to /admin/login");
        echo "  ✔ PASS: Session destroyed on logout, re-accessing dashboard properly rejected\n\n";
    }
}

(new HttpAuthTest())->run();
