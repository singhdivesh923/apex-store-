<?php
declare(strict_types=1);

/**
 * Automated Test Runner for ApexStore E-Commerce Suite
 * Run via CLI: php tests/run_tests.php
 */

define('ROOT_DIR', dirname(__DIR__));

require_once ROOT_DIR . '/app/helpers.php';
load_env(ROOT_DIR . '/.env');

// Autoloader
spl_autoload_register(function (string $class) {
    $prefix = 'App\\';
    $baseDir = ROOT_DIR . '/app/';
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) return;
    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
    if (file_exists($file)) require_once $file;
});

use App\Models\Coupon;
use App\Models\Order;
use App\Services\CSRF;
use App\Services\Session;

class TestRunner
{
    private int $passed = 0;
    private int $failed = 0;
    private array $errors = [];

    public function assert(bool $condition, string $testName): void
    {
        if ($condition) {
            $this->passed++;
            echo "  \033[32m✔ PASS\033[0m: {$testName}\n";
        } else {
            $this->failed++;
            $this->errors[] = $testName;
            echo "  \033[31m✖ FAIL\033[0m: {$testName}\n";
        }
    }

    public function run(): void
    {
        echo "\n=======================================================\n";
        echo "  ApexStore Automated Test Suite (PHP " . phpversion() . ")\n";
        echo "=======================================================\n\n";

        $this->testCoupons();
        $this->testSecurityAndCSRF();
        $this->testOrderStateTransitions();
        $this->testPaymentSignatures();
        $this->testEscapingAndHelpers();
        $this->testSecurityEnhancements();

        echo "\n-------------------------------------------------------\n";
        echo "Results: {$this->passed} Passed, {$this->failed} Failed\n";
        echo "=======================================================\n";

        if ($this->failed > 0) {
            echo "\nFailed Tests:\n";
            foreach ($this->errors as $err) {
                echo "  - {$err}\n";
            }
            exit(1);
        } else {
            echo "\n\033[32mAll business logic & security tests passed successfully!\033[0m\n\n";
            exit(0);
        }
    }

    private function testCoupons(): void
    {
        echo "Testing Coupon Discount Business Logic...\n";

        // Test 1: Percentage coupon calculation
        $percentCoupon = [
            'type' => 'percentage',
            'discount_value' => '10.00',
            'max_discount_amount' => null,
            'min_order_amount' => '50.00'
        ];
        $disc1 = Coupon::calculateDiscount($percentCoupon, 200.00);
        $this->assert($disc1 === 20.00, "10% discount on $200 should equal $20.00");

        // Test 2: Percentage coupon with max cap
        $cappedCoupon = [
            'type' => 'percentage',
            'discount_value' => '20.00',
            'max_discount_amount' => '30.00',
            'min_order_amount' => '50.00'
        ];
        $disc2 = Coupon::calculateDiscount($cappedCoupon, 300.00);
        $this->assert($disc2 === 30.00, "20% on $300 ($60) capped at $30 should return $30.00");

        // Test 3: Fixed amount coupon
        $fixedCoupon = [
            'type' => 'fixed',
            'discount_value' => '25.00',
            'max_discount_amount' => null,
            'min_order_amount' => '100.00'
        ];
        $disc3 = Coupon::calculateDiscount($fixedCoupon, 150.00);
        $this->assert($disc3 === 25.00, "Fixed $25 coupon should return $25.00");

        // Test 4: Fixed coupon exceeding cart subtotal (prevent negative subtotal)
        $disc4 = Coupon::calculateDiscount($fixedCoupon, 20.00);
        $this->assert($disc4 === 20.00, "Fixed discount cannot exceed cart subtotal");
    }

    private function testSecurityAndCSRF(): void
    {
        echo "\nTesting Security, Sessions, & CSRF Validation...\n";

        Session::start();
        $token = CSRF::getToken();
        $this->assert(is_string($token) && strlen($token) === 64, "CSRF token generated with 64 hex characters (32 bytes entropy)");

        // Validate token
        $isValid = CSRF::validate($token);
        $this->assert($isValid === true, "Valid CSRF token passes verification");

        // Validate invalid token
        $isInvalid = CSRF::validate('tampered_invalid_token_123');
        $this->assert($isInvalid === false, "Tampered CSRF token is rejected");

        // Password hashing & verification
        $password = 'Admin@12345';
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $this->assert(password_verify($password, $hash), "Bcrypt password verification succeeds with correct password");
        $this->assert(!password_verify('WrongPassword', $hash), "Bcrypt password verification fails with incorrect password");
    }

    private function testOrderStateTransitions(): void
    {
        echo "\nTesting Order State Transitions & Terminal Conditions...\n";

        // Pending transitions
        $pendingAllowed = Order::ALLOWED_TRANSITIONS['pending'] ?? [];
        $this->assert(in_array('confirmed', $pendingAllowed, true) && in_array('cancelled', $pendingAllowed, true), "Pending orders can transition to confirmed or cancelled");

        // Delivered transitions
        $deliveredAllowed = Order::ALLOWED_TRANSITIONS['delivered'] ?? [];
        $this->assert($deliveredAllowed === ['refunded'], "Delivered orders can only transition to refunded");

        // Cancelled orders cannot transition further
        $cancelledAllowed = Order::ALLOWED_TRANSITIONS['cancelled'] ?? [];
        $this->assert(empty($cancelledAllowed), "Cancelled orders are terminal and cannot transition to any other state");
    }

    private function testPaymentSignatures(): void
    {
        echo "\nTesting Payment Cryptographic Signatures...\n";

        $orderId = 'order_DAvL1234567890';
        $paymentId = 'pay_29QQoUBcxrhErF';
        $secret = 'EnLsTek1JbvpsdQETszErnH2';

        // Official Razorpay formula: HMAC-SHA256(order_id + "|" + payment_id, secret)
        $expectedSignature = hash_hmac('sha256', "{$orderId}|{$paymentId}", $secret);
        $this->assert(is_string($expectedSignature) && strlen($expectedSignature) === 64, "Generated HMAC-SHA256 signature matches expected 64-char hex format");

        // Tamper test
        $tamperedSignature = hash_hmac('sha256', "{$orderId}|pay_TAMPERED", $secret);
        $this->assert(!hash_equals($expectedSignature, $tamperedSignature), "Tampered payment ID yields signature mismatch");
    }

    private function testEscapingAndHelpers(): void
    {
        echo "\nTesting HTML Escaping & Formatting Helpers...\n";

        $maliciousString = '<script>alert("XSS")</script>';
        $escaped = e($maliciousString);
        $this->assert($escaped === '&lt;script&gt;alert(&quot;XSS&quot;)&lt;/script&gt;', "HTML characters correctly escaped against Cross-Site Scripting (XSS)");

        $currency = format_currency(1234.5, '$');
        $this->assert($currency === '$1,234.50', "Currency formatted with decimal precision and thousands separator");

        $orderNumber = generate_order_number();
        $this->assert(str_starts_with($orderNumber, 'APX-') && strlen($orderNumber) >= 15, "Unique order reference has valid APX- prefix and entropy");
    }

    private function testSecurityEnhancements(): void
    {
        echo "\nTesting Security Regression Enhancements...\n";

        // 1. clean_html XSS sanitization
        $xssPayload = '<p>Description</p><script>alert("XSS")</script><span onerror="alert(1)">Text</span>';
        $cleaned = clean_html($xssPayload);
        $this->assert(!str_contains($cleaned, '<script>') && !str_contains($cleaned, 'onerror'), "clean_html removes script tags and event handlers");
        $this->assert(str_contains($cleaned, '<p>Description</p>') && str_contains($cleaned, 'Text'), "clean_html preserves safe semantic tags and text");

        // 2. Persistent Rate Limiting
        $testKey = 'test_regression_key_' . bin2hex(random_bytes(4));
        \App\Services\Auth::clearRateLimit($testKey);
        $this->assert(!\App\Services\Auth::isRateLimited($testKey), "New rate limit key is not limited");

        for ($i = 0; $i < 5; $i++) {
            \App\Services\Auth::incrementRateLimit($testKey, 5, 60);
        }
        $this->assert(\App\Services\Auth::isRateLimited($testKey), "Key is rate limited after 5 failed increments");
        \App\Services\Auth::clearRateLimit($testKey);
        $this->assert(!\App\Services\Auth::isRateLimited($testKey), "Rate limit key is cleared successfully");

        // 3. Email Header Injection neutralization
        $injectedTo = "victim@example.com\r\nBcc: spy@evil.com";
        $cleanTo = str_replace(["\r", "\n"], '', trim($injectedTo));
        $this->assert(!str_contains($cleanTo, "\r") && !str_contains($cleanTo, "\n") && !str_contains($cleanTo, "Bcc: spy@evil.com\r"), "Email address sanitization strips CRLF characters");

        // 4. FileUploader path traversal protection
        $subDir = '../../etc';
        $safeSubDir = basename(trim($subDir, '/\\'));
        $allowedSubDirs = ['products', 'categories', 'avatars', 'general'];
        if (!in_array($safeSubDir, $allowedSubDirs, true)) {
            $safeSubDir = 'products';
        }
        $this->assert($safeSubDir === 'products', "Path traversal directory input falls back to safe allowlisted subdirectory");
    }
}

$runner = new TestRunner();
$runner->run();
