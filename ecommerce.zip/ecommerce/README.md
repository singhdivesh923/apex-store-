# ApexStore - Advanced Production E-Commerce Platform

A production-oriented, secure, high-performance E-Commerce platform engineered with **PHP 8.x+**, **MySQL (InnoDB / PDO)**, **HTML5**, **CSS3**, **Vanilla JavaScript**, and **Bootstrap 5**.

---

## Table of Contents

1. [Architectural Overview](#1-architectural-overview)
2. [Server & System Requirements](#2-server--system-requirements)
3. [Folder Structure](#3-folder-structure)
4. [Installation & Setup Guide](#4-installation--setup-guide)
5. [Database Architecture & Schema](#5-database-architecture--schema)
6. [Security Engineering & IDOR Defenses](#6-security-engineering--idor-defenses)
7. [Payment Gateways & Webhooks](#7-payment-gateways--webhooks)
8. [Automated Test Suite](#8-automated-test-suite)
9. [Database Backup & Restoration](#9-database-backup--restoration)
10. [Troubleshooting Guide](#10-troubleshooting-guide)

---

## 1. Architectural Overview

ApexStore adheres to a modular **MVC-inspired architecture** designed for maintainability, high testability, and auditability:

- **Strict Server-Side Validation**: Never trusts prices, totals, or stock counts provided by client JavaScript. All calculations (subtotal, percentage/fixed coupons, taxes, courier rates) are calculated on the server.
- **Transactional Consistency**: Multi-step checkout, atomic inventory decrements, and order cancellations execute inside ACID-compliant database transactions (`Database::transaction()`).
- **Cryptographic Security**: Bcrypt password hashing (`password_hash`), constant-time token comparison (`hash_equals`), CSRF tokens on every state-changing request, and HMAC-SHA256 signature verification for payment callbacks.
- **Safe Archival**: Deleting a product referenced by historical orders archives the product instead of breaking order item audit trails.

---

## 2. Server & System Requirements

| Component | Minimum Version | Recommended Version |
| :--- | :--- | :--- |
| **PHP** | 8.1.0+ | **8.3.x+** |
| **MySQL / MariaDB** | MySQL 8.0+ / MariaDB 10.5+ | **MySQL 8.4 LTS** |
| **Web Server** | Apache 2.4+ (`mod_rewrite`, `mod_headers`) or Nginx | **Apache 2.4 with HTTP/2 & SSL** |
| **PHP Extensions** | `pdo`, `pdo_mysql`, `mbstring`, `openssl`, `fileinfo`, `curl` | All enabled |
| **Operating System** | Linux (Ubuntu 22.04 / 24.04 LTS), macOS, or Windows | Linux VPS / Cloud Host |

---

## 3. Folder Structure

```text
ecommerce/
├── app/
│   ├── Controllers/             # Storefront Controllers
│   │   ├── HomeController.php
│   │   ├── ProductController.php
│   │   ├── CartController.php
│   │   ├── WishlistController.php
│   │   ├── CheckoutController.php
│   │   ├── OrderController.php
│   │   ├── AuthController.php
│   │   ├── AccountController.php
│   │   ├── ReviewController.php
│   │   ├── ContactController.php
│   │   ├── WebhookController.php
│   │   └── Admin/               # Administrative Management Controllers
│   │       ├── AdminAuthController.php
│   │       ├── DashboardController.php
│   │       ├── ProductController.php
│   │       ├── CategoryController.php
│   │       ├── OrderController.php
│   │       ├── CustomerController.php
│   │       ├── CouponController.php
│   │       ├── ReviewController.php
│   │       ├── ReportController.php
│   │       └── SettingController.php
│   ├── Models/                  # PDO Data Access Models (20 tables)
│   ├── Services/                # Core Services (Database, Session, CSRF, Auth, Uploader, Mailer)
│   │   └── Payment/             # Payment Provider Gateway Abstraction & Razorpay
│   ├── Middleware/              # Route Protection (Auth, Admin, CSRF)
│   ├── Views/                   # Clean Bootstrap 5 Responsive Templates
│   ├── Router.php               # Front-Controller Dynamic HTTP Router
│   └── helpers.php              # Global Security & Formatting Helpers
├── config/                      # Isolated Environment Configurations (app, database, mail)
├── database/                    # schema.sql, seed.sql, setup.php
├── public/                      # Web-Accessible Document Root (index.php, CSS, JS, uploads)
├── storage/logs/                # Private application & mail logs
├── tests/                       # Automated Standalone Test Suite (run_tests.php)
├── .env.example                 # Production Environment Template
├── .env                         # Active Local Environment Configuration
├── .htaccess                    # Root Web Access Protection
└── README.md                    # Deployment & Architecture Documentation
```

---

## 4. Installation & Setup Guide

### Step 1: Environment File Configuration
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```

Edit `.env` to configure your MySQL database credentials:
```ini
APP_NAME=ApexStore
APP_ENV=production
APP_DEBUG=false
APP_URL=https://yourstore.com

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=apexstore_db
DB_USERNAME=apex_user
DB_PASSWORD=YourStrongDatabasePassword123!
```

### Step 2: Create MySQL Database & Restricted User
Log in to MySQL as root and execute:
```sql
CREATE DATABASE `apexstore_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER 'apex_user'@'localhost' IDENTIFIED BY 'YourStrongDatabasePassword123!';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER, LOCK TABLES ON `apexstore_db`.* TO 'apex_user'@'localhost';
FLUSH PRIVILEGES;
```

### Step 3: Run Database Migrations & Seed Data
You can initialize the schema using our automated CLI setup tool:
```bash
php database/setup.php
```
Or manually import via MySQL CLI:
```bash
mysql -u apex_user -p apexstore_db < database/schema.sql
mysql -u apex_user -p apexstore_db < database/seed.sql
```

### Step 4: Web Server Configuration (Apache Virtual Host)
Configure Apache's `DocumentRoot` to point directly to the `/public` directory:
```apache
<VirtualHost *:80>
    ServerName yourstore.com
    DocumentRoot /var/www/ecommerce/public

    <Directory /var/www/ecommerce/public>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/apexstore_error.log
    CustomLog ${APACHE_LOG_DIR}/apexstore_access.log combined
</VirtualHost>
```
*Note: If hosted on shared hosting where changing the DocumentRoot is restricted, our included root `.htaccess` automatically routes all web traffic to `/public` while denying direct access to `.env`, `app/`, `config/`, and `database/`.*

### Step 5: Directory Permissions
Ensure upload and log directories have write permissions:
```bash
chmod -R 755 public/uploads
chmod -R 755 storage/logs
```

### Step 6: Default Pre-Seeded Accounts
The seed data provisions two initial verified accounts:
- **System Administrator**: `admin@apexstore.com` / `Admin@12345` (Admin Dashboard: `/admin`)
- **Sample Customer**: `customer@apexstore.com` / `Customer@12345`

---

## 5. Database Architecture & Schema

The schema (`database/schema.sql`) implements all 20 tables with InnoDB storage engines, foreign key cascades, and compound indexes:

1. `users`: Customers and administrators with role-based segregation and email verification.
2. `addresses`: Customer shipping and billing address book with default selection.
3. `categories`: Nested self-referencing category tree with URL slugs.
4. `products`: Full product records with DECIMAL money columns and low-stock threshold triggers.
5. `product_images`: Multi-image gallery with primary thumbnail flags.
6. `carts`: Guest session and logged-in user cart container.
7. `cart_items`: Cart items linked to products with quantity limits.
8. `wishlists`: Account-linked customer wishlist items.
9. `orders`: Orders with public non-sequential references (e.g. `APX-20261027-E8A1F4`).
10. `order_items`: **Immutable snapshots** of product name, SKU, and unit price at time of purchase.
11. `payments`: Payment gateway references, statuses, and payload dumps.
12. `coupons`: Percentage and fixed promotional codes with minimum order values and caps.
13. `coupon_usages`: Audit trail tracking customer coupon redemption.
14. `reviews`: Customer ratings (1-5 stars) with moderation status.
15. `inventory_logs`: Real-time stock audit trail recording every decrement, return, or manual adjustment.
16. `admin_logs`: Complete security audit log tracking administrative modifications with client IP.
17. `settings`: Key-value store configuration (store name, currency, tax rates, gateway keys).
18. `newsletter_subscribers`: Newsletter subscriptions.
19. `password_reset_tokens`: Cryptographic password reset tokens with 1-hour expiry.
20. `email_verification_tokens`: Customer email verification tokens.

---

## 6. Security Engineering & IDOR Defenses

- **Insecure Direct Object Reference (IDOR) Defenses**: All customer order inspections (`/account/orders/{orderNumber}`) and address modifications verify that `orders.user_id === Auth::id()`. Unauthorized attempts trigger immediate 403 / redirection.
- **CSRF Defense**: Constant-time `hash_equals()` validation on all state-changing requests (`POST`, `PUT`, `DELETE`).
- **Output Escaping**: All dynamic data in templates passes through `e()` (`htmlspecialchars(..., ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')`).
- **File Upload Safety**: Uploaded files in `FileUploader` are verified using `finfo` against strict MIME allowlists (`image/jpeg`, `image/png`, `image/webp`), checked for genuine image dimensions (`getimagesize`), assigned randomized filenames, and saved to a non-executable directory.
- **Safe CSV Generation**: All exported CSV cells are sanitized against CSV Formula Injection (`=`, `+`, `-`, `@`).

---

## 7. Payment Gateways & Webhooks

ApexStore supports a decoupled **Payment Gateway Interface** (`PaymentGatewayInterface`):
- **Cash on Delivery (COD)**: Offline payment workflow.
- **Razorpay**: Official API / Checkout SDK flow.
  - Generates secure order via Razorpay REST API.
  - Verifies HMAC-SHA256 signature server-side (`hash_hmac('sha256', order_id + '|' + payment_id, secret)`).
  - Webhook endpoint (`/api/webhook/razorpay`) processes `payment.captured` idempotently.
  - Explicit configuration error is raised if credentials are empty—**never simulates fake payments**.

---

## 8. Automated Test Suite

ApexStore includes an automated standalone test runner testing critical business rules and security controls:

To execute the test suite:
```bash
php tests/run_tests.php
```

Tests cover:
- Coupon calculations (percentage, fixed, minimum subtotal, maximum caps)
- CSRF token generation, entropy, and constant-time validation
- Bcrypt password verification
- Order state transition rules (preventing invalid state jumps)
- HMAC-SHA256 cryptographic payment signature validation
- XSS escaping and currency formatting

---

## 9. Database Backup & Restoration

### Backup Database:
```bash
mysqldump -u apex_user -p --single-transaction --quick --routines apexstore_db > storage/backup_$(date +%Y%m%d_%H%M%S).sql
```

### Restore Database:
```bash
mysql -u apex_user -p apexstore_db < storage/backup_YYYYMMDD_HHMMSS.sql
```

---

## 10. Troubleshooting Guide

| Issue | Cause | Solution |
| :--- | :--- | :--- |
| **HTTP 404 on Subpages** | Apache `mod_rewrite` is disabled or `.htaccess` is ignored | Run `sudo a2enmod rewrite` and set `AllowOverride All` in your VirtualHost directory block. |
| **HTTP 403 Forbidden on Uploads** | File permissions are not writable by web server | Execute `chmod -R 755 public/uploads` and `chown -R www-data:www-data public/uploads`. |
| **HTTP 500 Database Connection Failed** | Incorrect credentials or MySQL is stopped | Check `.env` settings (`DB_HOST`, `DB_USERNAME`, `DB_PASSWORD`) and ensure MySQL service is active. |
| **CSRF Verification Failed** | Session cookie expired or domain mismatch | Verify `SESSION_SECURE_COOKIE` in `.env` is set to `false` if testing over plain HTTP (localhost). |
