<?php
declare(strict_types=1);

return [
    'default' => env('MAIL_MAILER', 'log'),

    'mailers' => [
        'smtp' => [
            'host' => env('MAIL_HOST', '127.0.0.1'),
            'port' => (int) env('MAIL_PORT', 587),
            'encryption' => env('MAIL_ENCRYPTION', 'tls'),
            'username' => env('MAIL_USERNAME', null),
            'password' => env('MAIL_PASSWORD', null),
        ],
        'log' => [
            'path' => dirname(__DIR__) . '/storage/logs/mail.log',
        ],
    ],

    'from' => [
        'address' => env('MAIL_FROM_ADDRESS', 'support@apexstore.com'),
        'name' => env('MAIL_FROM_NAME', 'ApexStore Notifications'),
    ],
];
