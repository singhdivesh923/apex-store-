<?php
declare(strict_types=1);

return [
    'name' => env('APP_NAME', 'ApexStore'),
    'env' => env('APP_ENV', 'production'),
    'debug' => (bool) env('APP_DEBUG', false),
    'url' => env('APP_URL', 'http://localhost:8000'),
    'timezone' => env('APP_TIMEZONE', 'UTC'),
    'locale' => env('APP_LOCALE', 'en'),

    'session' => [
        'lifetime' => (int) env('SESSION_LIFETIME', 7200),
        'secure' => (bool) env('SESSION_SECURE_COOKIE', false),
        'httponly' => (bool) env('SESSION_HTTPONLY', true),
        'samesite' => env('SESSION_SAMESITE', 'Lax'),
    ],

    'rate_limit' => [
        'max_attempts' => (int) env('MAX_LOGIN_ATTEMPTS', 5),
        'lockout_minutes' => (int) env('LOGIN_LOCKOUT_MINUTES', 15),
    ],
];
