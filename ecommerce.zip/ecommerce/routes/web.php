<?php
declare(strict_types=1);

/**
 * Web Application Route Declarations
 */

use App\Controllers\HomeController;
use App\Controllers\ProductController;
use App\Controllers\CartController;
use App\Controllers\WishlistController;
use App\Controllers\CheckoutController;
use App\Controllers\OrderController;
use App\Controllers\AuthController;
use App\Controllers\AccountController;
use App\Controllers\ReviewController;
use App\Controllers\ContactController;
use App\Controllers\WebhookController;

use App\Controllers\Admin\AdminAuthController;
use App\Controllers\Admin\DashboardController;
use App\Controllers\Admin\ProductController as AdminProductController;
use App\Controllers\Admin\CategoryController as AdminCategoryController;
use App\Controllers\Admin\OrderController as AdminOrderController;
use App\Controllers\Admin\CustomerController as AdminCustomerController;
use App\Controllers\Admin\CouponController as AdminCouponController;
use App\Controllers\Admin\ReviewController as AdminReviewController;
use App\Controllers\Admin\ReportController as AdminReportController;
use App\Controllers\Admin\SettingController as AdminSettingController;

use App\Middleware\AuthMiddleware;
use App\Middleware\AdminMiddleware;

/** @var \App\Router $router */

// -------------------------------------------------------------
// Storefront Public Routes
// -------------------------------------------------------------
$router->get('/', [HomeController::class, 'index']);
$router->get('/catalog', [ProductController::class, 'index']);
$router->get('/product/{slug}', [ProductController::class, 'show']);

// Cart
$router->get('/cart', [CartController::class, 'index']);
$router->post('/cart/add', [CartController::class, 'add']);
$router->post('/cart/update', [CartController::class, 'update']);
$router->post('/cart/remove', [CartController::class, 'remove']);
$router->post('/cart/coupon', [CartController::class, 'applyCoupon']);
$router->post('/cart/coupon/remove', [CartController::class, 'removeCoupon']);

// Wishlist
$router->get('/wishlist', [WishlistController::class, 'index'], [AuthMiddleware::class]);
$router->post('/wishlist/toggle', [WishlistController::class, 'toggle']);
$router->post('/wishlist/remove', [WishlistController::class, 'remove'], [AuthMiddleware::class]);

// Checkout
$router->get('/checkout', [CheckoutController::class, 'index']);
$router->post('/checkout/process', [CheckoutController::class, 'process']);
$router->get('/checkout/success', [CheckoutController::class, 'success']);
$router->post('/checkout/verify-payment', [CheckoutController::class, 'verifyPayment']);

// Customer Auth
$router->get('/login', [AuthController::class, 'showLogin']);
$router->post('/login', [AuthController::class, 'login']);
$router->get('/register', [AuthController::class, 'showRegister']);
$router->post('/register', [AuthController::class, 'register']);
$router->get('/logout', [AuthController::class, 'logout']);
$router->post('/logout', [AuthController::class, 'logout']);
$router->get('/forgot-password', [AuthController::class, 'showForgotPassword']);
$router->post('/forgot-password', [AuthController::class, 'forgotPassword']);
$router->get('/reset-password', [AuthController::class, 'showResetPassword']);
$router->post('/reset-password', [AuthController::class, 'resetPassword']);

// Protected Customer Account Routes
$router->get('/account/orders', [OrderController::class, 'index'], [AuthMiddleware::class]);
$router->get('/account/orders/{orderNumber}', [OrderController::class, 'show'], [AuthMiddleware::class]);
$router->post('/account/orders/{orderNumber}/cancel', [OrderController::class, 'cancel'], [AuthMiddleware::class]);
$router->get('/account/profile', [AccountController::class, 'profile'], [AuthMiddleware::class]);
$router->post('/account/profile', [AccountController::class, 'updateProfile'], [AuthMiddleware::class]);
$router->get('/account/addresses', [AccountController::class, 'addresses'], [AuthMiddleware::class]);
$router->post('/account/addresses', [AccountController::class, 'storeAddress'], [AuthMiddleware::class]);
$router->post('/account/addresses/delete/{id}', [AccountController::class, 'deleteAddress'], [AuthMiddleware::class]);

// Reviews & Store Pages
$router->post('/product/review', [ReviewController::class, 'store'], [AuthMiddleware::class]);
$router->get('/contact', [ContactController::class, 'show']);
$router->post('/contact', [ContactController::class, 'submit']);
$router->post('/newsletter', [ContactController::class, 'newsletter']);
$router->get('/faq', [ContactController::class, 'faq']);
$router->get('/shipping', [ContactController::class, 'shipping']);
$router->get('/returns', [ContactController::class, 'returns']);
$router->get('/privacy', [ContactController::class, 'privacy']);

// Webhook
$router->post('/api/webhook/razorpay', [WebhookController::class, 'razorpay']);

// -------------------------------------------------------------
// Administrator Panel Routes (/admin)
// -------------------------------------------------------------
$router->get('/admin/login', [AdminAuthController::class, 'showLogin']);
$router->post('/admin/login', [AdminAuthController::class, 'login']);
$router->get('/admin/logout', [AdminAuthController::class, 'logout']);
$router->post('/admin/logout', [AdminAuthController::class, 'logout']);

// Dashboard
$router->get('/admin', [DashboardController::class, 'index'], [AdminMiddleware::class]);

// Admin Products CRUD
$router->get('/admin/products', [AdminProductController::class, 'index'], [AdminMiddleware::class]);
$router->get('/admin/products/create', [AdminProductController::class, 'create'], [AdminMiddleware::class]);
$router->post('/admin/products/create', [AdminProductController::class, 'store'], [AdminMiddleware::class]);
$router->get('/admin/products/edit/{id}', [AdminProductController::class, 'edit'], [AdminMiddleware::class]);
$router->post('/admin/products/edit/{id}', [AdminProductController::class, 'update'], [AdminMiddleware::class]);
$router->post('/admin/products/delete/{id}', [AdminProductController::class, 'delete'], [AdminMiddleware::class]);

// Admin Categories CRUD
$router->get('/admin/categories', [AdminCategoryController::class, 'index'], [AdminMiddleware::class]);
$router->get('/admin/categories/create', [AdminCategoryController::class, 'create'], [AdminMiddleware::class]);
$router->post('/admin/categories/create', [AdminCategoryController::class, 'store'], [AdminMiddleware::class]);
$router->get('/admin/categories/edit/{id}', [AdminCategoryController::class, 'edit'], [AdminMiddleware::class]);
$router->post('/admin/categories/edit/{id}', [AdminCategoryController::class, 'update'], [AdminMiddleware::class]);
$router->post('/admin/categories/delete/{id}', [AdminCategoryController::class, 'delete'], [AdminMiddleware::class]);

// Admin Orders
$router->get('/admin/orders', [AdminOrderController::class, 'index'], [AdminMiddleware::class]);
$router->get('/admin/orders/{id}', [AdminOrderController::class, 'show'], [AdminMiddleware::class]);
$router->post('/admin/orders/{id}/status', [AdminOrderController::class, 'updateStatus'], [AdminMiddleware::class]);

// Admin Customers
$router->get('/admin/customers', [AdminCustomerController::class, 'index'], [AdminMiddleware::class]);
$router->get('/admin/customers/{id}', [AdminCustomerController::class, 'show'], [AdminMiddleware::class]);
$router->post('/admin/customers/{id}/toggle-status', [AdminCustomerController::class, 'toggleStatus'], [AdminMiddleware::class]);

// Admin Coupons
$router->get('/admin/coupons', [AdminCouponController::class, 'index'], [AdminMiddleware::class]);
$router->get('/admin/coupons/create', [AdminCouponController::class, 'create'], [AdminMiddleware::class]);
$router->post('/admin/coupons/create', [AdminCouponController::class, 'store'], [AdminMiddleware::class]);
$router->get('/admin/coupons/edit/{id}', [AdminCouponController::class, 'edit'], [AdminMiddleware::class]);
$router->post('/admin/coupons/edit/{id}', [AdminCouponController::class, 'update'], [AdminMiddleware::class]);
$router->post('/admin/coupons/delete/{id}', [AdminCouponController::class, 'delete'], [AdminMiddleware::class]);

// Admin Reviews
$router->get('/admin/reviews', [AdminReviewController::class, 'index'], [AdminMiddleware::class]);
$router->post('/admin/reviews/{id}/status', [AdminReviewController::class, 'updateStatus'], [AdminMiddleware::class]);

// Admin Reports & Export
$router->get('/admin/reports', [AdminReportController::class, 'index'], [AdminMiddleware::class]);
$router->get('/admin/reports/export-csv', [AdminReportController::class, 'exportCsv'], [AdminMiddleware::class]);

// Admin Settings
$router->get('/admin/settings', [AdminSettingController::class, 'index'], [AdminMiddleware::class]);
$router->post('/admin/settings', [AdminSettingController::class, 'update'], [AdminMiddleware::class]);
